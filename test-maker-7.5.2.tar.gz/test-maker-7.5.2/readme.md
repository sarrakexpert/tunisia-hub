## Introduction

**Test Maker** is an all around test automation framework that simplifies the process of testing Driven by a structured BDD style, writing code in Typescript/Javascript and other great features.

## Features

* E2E Test Automation
* Super Fast
* Multiple Adapters
* BDD
* Simple API
* Page Model
* Live reload
* Parallelism
* Retries
* Filtering
* Suites
* Reporting
* Typescript
* Assertion
* CLI
* Plugins
* Jira Integration

## What is Test Maker

**Test Maker** is a future proof high level abstraction Test Automation Framework that aims to left the pain of setting up, installation of dependencies and allows the developer to focus on writing
tests with
ease.

**Test Maker** Follows the model of `convension over configuration` which means that there is a set of predefined rules for everything and if the developer follow those rules, then minimum to no
configuration is required!

**Test Maker** offers novel concepts like Adapters, Live reload, integration with Jira, Accessibility check, etc...

## How it works

Under the hood **Test Maker** utilizes lots of technologies and tools ranging from compilers, optimizers to test runner.

**Test Maker** fuses all of these technologies under a very simple and concise API.

When we say **Test Maker** is future proof, we mean that it was developed with the philosophy that no matter how the technology behind it or new tools change, the API and workflow should not. in
simple words, the developer does not need to care about what happens behind, he/she would keep writing test with the same structure and code.

## Documentation 
[http://documentation.testmaker.io/](http://documentation.testmaker.io/)

## Semantic Versioning

**Test Maker** follows Semantic Versioning in all its official projects for documented features and behavior. For undocumented behavior or exposed internals, changes are described in release notes.


## Detailed release notes

All release notes for each version are available on [GitHub](https://github.com/KnowledgeExpert/test-maker/releases).

## requirements

* [Nodejs](https://nodejs.org/) 12.0.0 or higher
* Windows, OSX or Linux
* [Git](https://git-scm.com/)


