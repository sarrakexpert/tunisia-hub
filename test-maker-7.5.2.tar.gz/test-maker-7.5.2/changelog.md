# Changelog

All notable changes to this project will be documented in this file.

## [7.5.2] - 2022-8-15

### Features

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix missing `I.setGeoLocation()` rogue console.log #315
- [Public] Fix `I.setGeoLocation()` wrong GeoLocation #316
- [Public] Fix Terminal reporter is failing to get terminal size while running docker with -t parameter #317
- [Public] Fix The Eye dashboard fonts to being served #321

## [7.5.1] - 2022-7-8

### Features

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix missing `I.handleRoute()` #313

## [7.5.0] - 2022-6-28

### Features
- [Public] Add `packReportFiles` to `Allure` reporter #304
- [Public] Add `packResultsFiles` to `Allure` reporter #304
- [Public] Add `I.startTracing()` action to capture client performance metrics (When applicable, currency Chromium based clients) #303
- [Public] Add `afterInstall` function to the `on demand module installer` #301
- [Public] Add `I.handleRoute` Action #289
- [Public] Add Video Recording  in `Appium` adapter #278
- [Public] Add `screenshots` to `XRay` plugin options to control uploading #306
- [Public] Add `I.getOrientation()` in `Appium` adapter #307
- [Public] Add `I.setOrientation()` in `Appium` adapter #307
- [Public] Add `I.getGeoLocation()` in `Appium` adapter #308
- [Public] Add `I.setGeoLocation()` in `Appium` adapter #308

### Changes
- [Public] Update the EU dialog Selector for the example spec #297
- [Public] Disable `Chromium` `--no-proxy-server` by default #298
- [Public] Disable `Chromium` `--proxy-server='direct://'` by default #298
- [Public] Disable `Chromium` `--proxy-bypass-list=*` by default #298
- [Internal] Add `license-report-config.json`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `Selenium` Adapter not respecting `configuration.runner.headless` #299
- [Public] Fix `Selenium` Adapter should install the client dependencies while installing the Adapter and not on first launch of the client #300
- [Public] Fix `I.sendMail()` typing #302
- [Public] Fix `Appium` Driver recorded videos location #295
- [Public] Fix `I.expect()` `or` condition #285
- [Public] Fix native Dialog with a hack as it appears twice due to a bug in the driver in `Appium` adapter for `IOS` `Safari` #284
- [Internal] Fix injecting TM default client side script not working in `Appium` adapter
- [Public] Fix `I.switchContext()` not working correctly in `Appium` adapter #283
- [Public] Fix `I.blur()` not working correctly in `Appium` adapter for `IOS` `Safari` #280

## [7.5.0-rc.8] - 2022-6-28

### Features

### Changes
- [Internal] Add `license-report-config.json`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

## [7.5.0-rc.7] - 2022-6-22

### Features
- [Public] Add `packReportFiles` to `Allure` reporter #304
- [Public] Add `packResultsFiles` to `Allure` reporter #304

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

## [7.5.0-rc.6] - 2022-6-17

### Features
- [Public] Add `I.startTracing()` action to capture client performance metrics (When applicable, currency Chromium based clients) #303

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

## [7.5.0-rc.5] - 2022-6-16

### Features

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `I.sendMail()` typing #302

## [7.5.0-rc.4] - 2022-6-16

### Features
- [Public] Add `afterInstall` function to the `on demand module installer` #301

### Changes
- [Public] Update the EU dialog Selector for the example spec #297
- [Public] Disable `Chromium` `--no-proxy-server` by default #298
- [Public] Disable `Chromium` `--proxy-server='direct://'` by default #298
- [Public] Disable `Chromium` `--proxy-bypass-list=*` by default #298
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `Selenium` Adapter not respecting `configuration.runner.headless` #299
- [Public] Fix `Selenium` Adapter should install the client dependencies while installing the Adapter and not on first launch of the client #300

## [7.5.0-rc.3] - 2022-6-08

### Features
- [Public] Add `I.handleRoute` Action #289

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `Appium` Driver recorded videos location  #295

## [7.5.0-rc.2] - 2022-5-24

### Features
- [Public] Add Video Recording  in `Appium` adapter #278
- [Public] Add `screenshots` to `XRay` plugin options to control uploading screenshots #198

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `I.expect()` `or` condition  #285
- [Public] Fix native Dialog with a hack as it appears twice due to a bug in the driver in `Appium` adapter for `IOS` `Safari`  #284
- [Internal] Fix injecting TM default client side script not working in `Appium` adapter

## [7.5.0-rc.1] - 2022-5-23

### Features
- [Public] Add `I.getOrientation()` in `Appium` adapter  
- [Public] Add `I.setOrientation()` in `Appium` adapter  
- [Public] Add `I.getGeoLocation()` in `Appium` adapter
- [Public] Add `I.setGeoLocation()` in `Appium` adapter

### Changes
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `I.switchContext()` not working correctly in `Appium` adapter #283
- [Public] Fix `I.blur()` not working correctly in `Appium` adapter for `IOS` `Safari`  #280

## [7.0.0] - 2022-04-19

### Features

- [Public] Update `ketm init` example spec to handle Google's popup for user's consent
- [Public] Add `x,y` options to `I.mouseDown()` for Mobile adapters
- [Public] Add `x,y` options to `I.mouseUp()` for Mobile adapters
- [Public] Add `Unicode` keyboard support to `Appium` Adapter
- [Public] Add type property to Adapter's `ClientInfo` Object
- [Public] Add `I.switchContext()` Action ( works in `Appium` Adapter and other Adapters that supports it)
- [Public] Add `I.getContext()` Action ( works in `Appium` Adapter and other Adapters that supports it)
- [Public] Add `I.getContexts()` Action ( works in `Appium` Adapter and other Adapters that supports it)
- [Public] Add Pointer indicator for `ios:safari` client in `Appium` Adapter
- [Public] Add Pointer indicator for `android:chrome` client in `Appium` Adapter
- [Public] Add Pointer indicator for `chrome` client in `selenium` Adapter
- [Public] Add Pointer indicator for `firefox` client in `selenium` Adapter
- [Public] Add Pointer indicator for `edge` client in `selenium` Adapter
- [Public] Add Pointer indicator for `ie` client in `selenium` Adapter
- [Public] Add `Android` Application testing capability
- [Public] Add `Android` Browser testing capability
- [Public] Add `IOS` Application testing capability
- [Public] Add `IOS` Browser testing capability
- [Public] Add `Appium` Adapter
- [Public] Add `Selenium` Adapter
- [Public] Add `SauceLabs` Adapter
- [Public] Add `android:app` Client to Clients list
- [Public] Add `android:chrome` Client to Clients list
- [Public] Add `ios:app` Client to Clients list
- [Public] Add `ios:safari` Client to Clients list
- [Public] Add `ie` Client to Clients list

### Changes
- [Public] Update `ketm init - PEGA express` Template
- [Public] Add type property to Adapter's Client Object
- [Internal] Enhance catching `WebDriver` Adapter client side execution errors
- [Internal] Add `WebDriver` controller Decorator for actions
- [Internal] Add Unicode key map to `WebDriver` controller
- [Internal] Added process exist cleanup tasks
- [Internal] Add WebDriver shared Adapter
- [Internal] Add WebDriver shared Controller
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `ketm init` example spec not updated to the latest changes
- [Public] Fix `Selector().focused` not returning boolean result in `Appium` Adapter #268
- [Public] Fix `Selector().id` in `Appium` Adapter for `IOS` `App` clients #275
- [Public] Fix `Selector().getBoundingClientRect` not returning boolean result in `Appium` Adapter for `IOS` `App` clients #276
- [Public] Fix `Selector().getBoundingClientRect` not returning boolean result in `Appium` Adapter for `Android` `App` clients #270
- [Public] Fix `Selector().clickable` in `Appium` Adapter for `Android` `App` clients
- [Public] Fix `I.expectSelector().not.toBeDisabled()` in `Appium` Adapter for `Android` `App` clients #273
- [Public] Fix `I.expectSelector().not.toBeEnabled()` in `Appium` Adapter for `Android` `App` clients #274
- [Public] Fix Installation of dependencies in `Selenium` Adapter
- [Public] Fix infinite `executeAsync` for  `Selenium` Adapter
- [Public] Fix infinite `executeAsync` for  `Appium` Adapter
- [Public] Fix `pointerType` in `Appium` Adapter for `Android` `Chrome` clients
- [Public] Fix `I.click()` not clicking within element bounds in `Appium` Adapter for `IOS` `Safari` clients #243
- [Public] Fix `I.selectOption()` double triggering which causes the selection to be lost for `Appium` Adapter for `IOS` `Safari` clients #242 #244
- [Public] Fix `I.select()` for `Appium` Adapter for `IOS` `Safari` clients #231
- [Public] Fix `I.selectContent()` for `Appium` Adapter for `IOS` `Safari` clients #246
- [Public] Fix `I.mouseDown()` for `Appium` Adapter for `Andoird` `Chrome` clients
- [Public] Fix `I.SwitchToFrame` inside `forceSwitchToPage` causing the loss of current frame in `Appium` Adapter
- [Public] Fix `Selector().style` not working in `Appium` Adapter for `IOS` `Safari` clients #245
- [Public] Fix Handling Native dialogs failing if no controller action was called before using Selector for `Appium` Adapter #218
- [Public] Fix Handling Native dialogs failing if no controller action was called before using Selector for `Selenium` Adapter
- [Public] Fix `I.setFilesToUpload()` crashing the page for `Appium` Adapter in `Android` `Chrome` Clients
- [Public] Fix `I.moveCursorToSelector()` is not moving to exact edge of the Element in `Appium` Adapter
- [Public] Fix `I.moveCursorToSelector()` is not moving to exact edge of the Element in `Selenium` Adapter
- [Public] Fix `I.closeWindow()` is crashing when the window is the only window opened in `Selenium` Adapter #267
- [Public] Fix `I.getClientInfo()` for `Appium` Adapter in `Android` `Chrome` Clients
- [Public] Fix `I.waitForSelectActionabilityCheck()` is braking the process for `Appium` Adapter in `Android` `Chrome` Clients
- [Public] Fix `Selector().selected` not returning false when option element is deselected in `Appium` Adapter for `Android` `Chrome` clients
- [Public] Fix `Selector().selected` not returning false when option element is deselected in `Selenium` Adapter
- [Public] Fix `Selector` with name attribute (`[name="somevalue"]`) failing if no space after the name due to bug in WebDriver in `Appium` Adapter for `Android` `Chrome` clients
- [Public] Fix Inconsistent `pointertype` for `Selenium` Adapter
- [Public] Fix Inconsistent `pointertype` for `Appium` Adapter
- [Public] Fix `I.clearUpload` in `Appium` Adapter for IOS Safari clients #241
- [Public] Fix `Selector().selected` not returning `Boolean` in `Appium` Adapter for IOS Safari clients #236
- [Public] Fix `Selector().getAttribute` not returning null when the result is undefined or empty in `Appium` Adapter for `IOS` `Safari` clients #239
- [Public] Fix `Selector().child()` circular error in Appium Adapter
- [Public] Fix passed selector to client side is not correct object in `appium` Adapter for `IOS` `Safari` Clients
- [Public] Fix `Selector.style` not camel cased in `Selenium` Adapter
- [Public] Fix `Selector.style` not camel cased in `appium` Adapter
- [Public] Fix `I.setFilesToUpload()` in `appium` Adapter for IOS `Safari` Clients #237
- [Public] Fix `Test Maker` client js code is broken in `appium` Adapter for IOS `Safari` Clients
- [Public] Fix `null is not an object (evaluating 'document.body.appendChild')` not camel cased in `appium` Adapter
- [Public] Fix `I.selectOption()` in `Appium` Adapter #226
- [Public] Fix `I.deselectOption()` in `Appium` Adapter
- [Public] Fix `I.dragToSelector()` in `selenium` Adapter #254
- [Public] Fix `I.dragToSelector()` in `appium` Adapter for `IOS` #228
- [Public] Fix `I.moveCursorToSelector()` in `selenium` Adapter
- [Public] Fix `I.moveCursorToSelector()` in `Appium` Adapter #229
- [Public] Fix `I.selectText()` in `Appium` Adapter for `IOS` base clients #233
- [Public] Fix `I.selectEditableContent()` in `Appium` Adapter for `IOS` base clients #234
- [Public] Fix `I.selectTextAreaContent()` in `Appium` Adapter for `IOS` base clients #235
- [Public] Fix `I.copy()` in `Appium` Adapter for `IOS` base clients #220
- [Public] Fix `I.paste()` in `Appium` Adapter for `IOS` base clients  #277
- [Public] Fix `I.click()` with `KeyModifiers` in `selenium` Adapter #262
- [Public] Fix `I.pressEnterKey()` in `Appium` Adapter for `IOS` based clients
- [Public] Fix `Selector.classList` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `IOS` Native keyboard not showing up when using any keyboard based controller action in `Appium` Adapter
- [Public] Fix Auto add `appium:automationName` to `Appium` Adapter
- [Public] Fix Cookies operations in `Appium` Adapter #219
- [Public] Fix PressKeys operations in `Appium` Adapter for `IOS Safari` #217
- [Public] Fix Switch to correct window in `selenium` Adapter
- [Public] Fix Unregistering of Native Dialog Handler in `selenium` Adapter #261
- [Public] Fix `I.hover()` in `Appium` Adapter for `IOS Safari`
- [Public] Fix `I.clearUpload()` in `selenium` Adapter
- [Public] Fix `I.switchToParentWindow()` in `selenium` Adapter
- [Public] Fix `I.selectOption()` in `selenium` Adapter #250 #252 #253
- [Public] Fix `I.deselectOption()` in `selenium` Adapter #250
- [Public] Fix `Selector().nodeType` in `Appium` Adapter for `IOS Safari` #222
- [Public] Fix `Selector().scrollToSelector` not returning number as datatype in `Appium` Adapter for `IOS Safari` #230
- [Public] Fix `Selector().clientHeight` not returning number as datatype in `Appium` Adapter for `IOS Safari` #206
- [Public] Fix `Selector().clientWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari` #207
- [Public] Fix `Selector().clientLeft` not returning number as datatype in `Appium` Adapter for `IOS Safari` #208
- [Public] Fix `Selector().clientTop` not returning number as datatype in `Appium` Adapter for `IOS Safari` #205
- [Public] Fix `Selector().offsetWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari` #212
- [Public] Fix `Selector().offsetHeight` not returning number as datatype in `Appium` Adapter for `IOS Safari` #209
- [Public] Fix `Selector().offsetTop` not returning number as datatype in `Appium` Adapter for `IOS Safari` #211
- [Public] Fix `Selector().offsetLeft` not returning number as datatype in `Appium` Adapter for `IOS Safari` #210
- [Public] Fix `Selector().scrollTop` not returning number as datatype in `Appium` Adapter for `IOS Safari` #214
- [Public] Fix `Selector().scrollWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari` #216
- [Public] Fix `Selector().chekced` not returning boolean as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selenium` Adapter `I.selectText()` #248
- [Public] Fix `Appium` Adapter `I.selectText()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.click()` stale element
- [Public] Fix `Appium` Adapter `I.click()` stale element for mobile browsers
- [Public] Fix `Selenium` Adapter `I.getCookie()`
- [Public] Fix `Appium` Adapter `I.getCookie()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.refresh()` #259
- [Public] Fix `Appium` Adapter `I.refresh()` for mobile browsers #240
- [Public] Fix `Selenium` Adapter not auto switching to new Window
- [Public] Fix `Appium` Adapter not auto switching to new Window for mobile browsers
- [Public] Fix `Selenium` Adapter `I.getClientLogs()`
- [Public] Fix `Appium` Adapter `I.getClientLogs()` for mobile browsers #238
- [Public] Fix `Selenium` Adapter `I.getClientInfo()`
- [Public] Fix `Appium` Adapter `I.getClientInfo()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.pressKey()` not using unicode value
- [Public] Fix `Appium` Adapter `I.pressKey()` not using unicode value for mobile browsers
- [Public] Fix `Selenium` Adapter `I.pressDownKey()` not using unicode value #257
- [Public] Fix `Appium` Adapter `I.pressDownKey()` not using unicode value for mobile browsers
- [Public] Fix `Selenium` Adapter `I.pressUpKey()` not using unicode value
- [Public] Fix `Appium` Adapter `I.pressUpKey()` not using unicode value for mobile browsers
- [Public] Fix `Selenium` Adapter `I.mouseMove()`
- [Public] Fix `Appium` Adapter `I.mouseMove()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.mouseDown()`
- [Public] Fix `Appium` Adapter `I.mouseDown()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.mouseUp()`
- [Public] Fix `Appium` Adapter `I.mouseUp()` for mobile browsers
- [Public] Fix `Selenium` Adapter handling of Native Dialogs
- [Public] Fix `Appium` Adapter handling of Native Dialogs for mobile browsers
- [Internal] Fix `Ctrl+C` blocking execution of cleanup tasks
 
## [7.0.0-rc.12] - 2022-04-14

### Features
- [Public] Update `ketm init` example spec to handle Google's popup for user's consent

### Changes

- [Public] Update `ketm init - PEGA express` Template
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `ketm init` example spec not updated to the latest changes 

## [7.0.0-rc.11] - 2022-04-11

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes
- [Public] Fix `Selector().focused` not returning boolean result in `Appium` Adapter 
- [Public] Fix `Selector().id` in `Appium` Adapter for `IOS` `App` clients
- [Public] Fix `Selector().getBoundingClientRect` not returning boolean result in `Appium` Adapter for `IOS` `App` clients
- [Public] Fix `Selector().getBoundingClientRect` not returning boolean result in `Appium` Adapter for `Android` `App` clients
- [Public] Fix `Selector().clickable` in `Appium` Adapter for `Android` `App` clients
- [Public] Fix `I.expectSelector().not.toBeDisabled()` in `Appium` Adapter for `Android` `App` clients
- [Public] Fix `I.expectSelector().not.toBeEnabled()` in `Appium` Adapter for `Android` `App` clients
- [Public] Fix Installation of dependencies in `Selenium` Adapter 

## [7.0.0-rc.10] - 2022-04-05

### Features
- [Public] Add `x,y` options to `I.mouseDown()` for Mobile adapters
- [Public] Add `x,y` options to `I.mouseUp()` for Mobile adapters

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

## [7.0.0-rc.9] - 2022-04-05

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix infinite `executeAsync` for  `Selenium` Adapter
- [Public] Fix infinite `executeAsync` for  `Appium` Adapter

## [7.0.0-rc.8] - 2022-04-04

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `pointerType` in `Appium` Adapter for `Android` `Chrome` clients 
- [Public] Fix `I.click()` not clicking within element bounds in `Appium` Adapter for `IOS` `Safari` clients 
- [Public] Fix `I.selectOption()` double triggering which causes the selection to be lost for `Appium` Adapter for `IOS` `Safari` clients 
- [Public] Fix `I.select()` for `Appium` Adapter for `IOS` `Safari` clients 
- [Public] Fix `I.selectContent()` for `Appium` Adapter for `IOS` `Safari` clients 
- [Public] Fix `I.mouseDown()` for `Appium` Adapter for `Andoird` `Chrome` clients 
- [Public] Fix `I.SwitchToFrame` inside `forceSwitchToPage` causing the loss of current frame in `Appium` Adapter
- [Public] Fix `Selector().style` not working in `Appium` Adapter for `IOS` `Safari` clients 

## [7.0.0-rc.7] - 2022-03-31

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Handling Native dialogs failing if no controller action was called before using Selector for `Appium` Adapter
- [Public] Fix Handling Native dialogs failing if no controller action was called before using Selector for `Selenium` Adapter
- [Public] Fix `I.setFilesToUpload()` crashing the page for `Appium` Adapter in `Android` `Chrome` Clients
- [Public] Fix `I.moveCursorToSelector()` is not moving to exact edge of the Element in `Appium` Adapter 
- [Public] Fix `I.moveCursorToSelector()` is not moving to exact edge of the Element in `Selenium` Adapter 
- [Public] Fix `I.closeWindow()` is crashing when the window is the only window opened in `Selenium` Adapter 
- [Public] Fix `I.getClientInfo()` for `Appium` Adapter in `Android` `Chrome` Clients
- [Public] Fix `I.waitForSelectActionabilityCheck()` is braking the process for `Appium` Adapter in `Android` `Chrome` Clients
- [Public] Fix `Selector().selected` not returning false when option element is deselected in `Appium` Adapter for `Android` `Chrome` clients
- [Public] Fix `Selector().selected` not returning false when option element is deselected in `Selenium` Adapter 
- [Public] Fix `Selector` with name attribute (`[name="somevalue"]`) failing if no space after the name due to bug in WebDriver in `Appium` Adapter for `Android` `Chrome` clients
- [Public] Fix Inconsistent `pointertype` for `Selenium` Adapter 
- [Public] Fix Inconsistent `pointertype` for `Appium` Adapter 

## [7.0.0-rc.6] - 2022-03-28

### Features

### Changes

- [Internal] Update Deps
  - [Internal] Update interfaces
  - [Internal] Code refactoring
  - [Internal] Code cleanup

### Fixes

- [Public] Fix `I.clearUpload` in `Appium` Adapter for IOS Safari clients
  - [Public] Fix `Selector().selected` not returning `Boolean` in `Appium` Adapter for IOS Safari clients
  - [Public] Fix `Selector().getAttribute` not returning null when the result is undefined or empty in `Appium` Adapter for `IOS` `Safari` clients
  - [Public] Fix `Selector().child()` circular error in Appium Adapter 

## [7.0.0-rc.5] - 2022-03-25

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix passed selector to client side is not correct object in `appium` Adapter for `IOS` `Safari` Clients
- [Public] Fix `Selector.style` not camel cased in `Selenium` Adapter
- [Public] Fix `Selector.style` not camel cased in `appium` Adapter
- [Public] Fix `I.setFilesToUpload()` in `appium` Adapter for IOS `Safari` Clients
- [Public] Fix `Test Maker` client js code is broken in `appium` Adapter for IOS `Safari` Clients
- [Public] Fix `null is not an object (evaluating 'document.body.appendChild')` not camel cased in `appium` Adapter

## [7.0.0-rc.4] - 2022-03-21

### Features
- [Public] Add `Unicode` keyboard support to `Appium` Adapter
- [Public] Add type property to Adapter's `ClientInfo` Object

### Changes

- [Public] Add type property to Adapter's Client Object
- [Internal] Enhance catching `WebDriver` Adapter client side execution errors
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.selectOption()` in `Appium` Adapter
- [Public] Fix `I.deselectOption()` in `Appium` Adapter
- [Public] Fix `I.dragToSelector()` in `selenium` Adapter
- [Public] Fix `I.moveCursorToSelector()` in `selenium` Adapter
- [Public] Fix `I.moveCursorToSelector()` in `Appium` Adapter
- [Public] Fix `I.selectText()` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `I.selectEditableContent()` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `I.selectTextAreaContent()` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `I.copy()` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `I.paste()` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `I.click()` with `KeyModifiers` in `selenium` Adapter
- [Public] Fix `I.pressEnterKey()` in `Appium` Adapter for `IOS` based clients
- [Public] Fix `Selector.classList` in `Appium` Adapter for `IOS` base clients
- [Public] Fix `IOS` Native keyboard not showing up when using any keyboard based controller action in `Appium` Adapter 

## [7.0.0-rc.3] - 2022-03-18

### Features
- [Public] Add `I.switchContext()` Action ( works in `Appium` Adapter and other Adapters that supports it)
- [Public] Add `I.getContext()` Action ( works in `Appium` Adapter and other Adapters that supports it)
- [Public] Add `I.getContexts()` Action ( works in `Appium` Adapter and other Adapters that supports it)
- [Public] Add Pointer indicator for `ios:safari` client in `Appium` Adapter 
- [Public] Add Pointer indicator for `android:chrome` client in `Appium` Adapter 
- [Public] Add Pointer indicator for `chrome` client in `selenium` Adapter 
- [Public] Add Pointer indicator for `firefox` client in `selenium` Adapter 
- [Public] Add Pointer indicator for `edge` client in `selenium` Adapter 
- [Public] Add Pointer indicator for `ie` client in `selenium` Adapter 

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Auto add `appium:automationName` to `Appium` Adapter
- [Public] Fix Cookies operations in `Appium` Adapter
- [Public] Fix PressKeys operations in `Appium` Adapter for `IOS Safari`
- [Public] Fix Switch to correct window in `selenium` Adapter
- [Public] Fix Unregistering of Native Dialog Handler in `selenium` Adapter
- [Public] Fix `I.hover()` in `Appium` Adapter for `IOS Safari` #221
- [Public] Fix `I.clearUpload()` in `selenium` Adapter 
- [Public] Fix `I.switchToParentWindow()` in `selenium` Adapter 
- [Public] Fix `I.selectOption()` in `selenium` Adapter 
- [Public] Fix `I.deselectOption()` in `selenium` Adapter 
- [Public] Fix `Selector().nodeType` in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().scrollToSelector` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().clientHeight` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().clientWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().clientLeft` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().clientTop` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().clientWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().clientHeight` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().offsetWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().offsetHeight` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().offsetTop` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().offsetLeft` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().scrollTop` not returning number as datatype in `Appium` Adapter for `IOS Safari` 
- [Public] Fix `Selector().scrollWidth` not returning number as datatype in `Appium` Adapter for `IOS Safari`
- [Public] Fix `Selector().chekced` not returning boolean as datatype in `Appium` Adapter for `IOS Safari`

## [7.0.0-rc.2] - 2022-03-15

### Features

### Changes

- [Internal] Add `WebDriver` controller Decorator for actions
- [Internal] Add Unicode key map to `WebDriver` controller
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Selenium` Adapter `I.selectText()`
- [Public] Fix `Appium` Adapter `I.selectText()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.click()` stale element
- [Public] Fix `Appium` Adapter `I.click()` stale element for mobile browsers
- [Public] Fix `Selenium` Adapter `I.getCookie()`
- [Public] Fix `Appium` Adapter `I.getCookie()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.refresh()`
- [Public] Fix `Appium` Adapter `I.refresh()` for mobile browsers
- [Public] Fix `Selenium` Adapter not auto switching to new Window
- [Public] Fix `Appium` Adapter not auto switching to new Window for mobile browsers
- [Public] Fix `Selenium` Adapter `I.getClientLogs()`
- [Public] Fix `Appium` Adapter `I.getClientLogs()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.getClientInfo()`
- [Public] Fix `Appium` Adapter `I.getClientInfo()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.pressKey()` not using unicode value
- [Public] Fix `Appium` Adapter `I.pressKey()` not using unicode value for mobile browsers
- [Public] Fix `Selenium` Adapter `I.pressDownKey()` not using unicode value
- [Public] Fix `Appium` Adapter `I.pressDownKey()` not using unicode value for mobile browsers
- [Public] Fix `Selenium` Adapter `I.pressUpKey()` not using unicode value
- [Public] Fix `Appium` Adapter `I.pressUpKey()` not using unicode value for mobile browsers
- [Public] Fix `Selenium` Adapter `I.mouseMove()`
- [Public] Fix `Appium` Adapter `I.mouseMove()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.mouseDown()`
- [Public] Fix `Appium` Adapter `I.mouseDown()` for mobile browsers
- [Public] Fix `Selenium` Adapter `I.mouseUp()`
- [Public] Fix `Appium` Adapter `I.mouseUp()` for mobile browsers
- [Public] Fix `Selenium` Adapter handling of Native Dialogs
- [Public] Fix `Appium` Adapter handling of Native Dialogs for mobile browsers

## [7.0.0-rc.1] - 2022-03-07

### Features

- [Public] Add `Android` Application testing capability
- [Public] Add `Android` Browser testing capability
- [Public] Add `IOS` Application testing capability
- [Public] Add `IOS` Browser testing capability
- [Public] Add `Appium` Adapter
- [Public] Add `Selenium` Adapter
- [Public] Add `SauceLabs` Adapter
- [Public] Add `android:app` Client to Clients list
- [Public] Add `android:chrome` Client to Clients list
- [Public] Add `ios:app` Client to Clients list
- [Public] Add `ios:safari` Client to Clients list
- [Public] Add `ie` Client to Clients list

### Changes

- [Internal] Added process exist cleanup tasks
- [Internal] Add WebDriver shared Adapter
- [Internal] Add WebDriver shared Controller
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Internal] Fix `Ctrl+C` blocking execution of cleanup tasks

## [6.0.4] - 2022-02-25

### Features

### Changes

- [Internal] Update Deps bundler
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Typescript checker error when enabling `build.compiler.typescript.check` #203 #204

## [6.0.3] - 2022-02-25

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Selector().clientTop()` Not implemented #202

## [6.0.2] - 2022-02-21

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `JSON` Data Server missing JSONFile Import #201

## [6.0.1] - 2022-02-20

### Features

### Changes

- [Internal] Fix Obfuscator `debugProtectionInterval` option
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Lighthouse` plugin options is not unique per audit #199
- [Public] Fix `Lighthouse` plugin report is not unique per audit #200

## [6.0.0] - 2022-02-01

### Features

- [Public] Add `X-Ray` plugin #178
- [Public] Add `Yellow Lab Tools` plugin #183
- [Public] Add Test Web Server #179
- [Public] Add Test JSON Data Web Server #180
- [Public] Add Data Faker #181
- [Public] Add Microsoft Teams Reporter #184
- [Public] Add Device Emulation #173
- [Public] Add Device Emulation to `Playwirght` adapter #173
- [Public] Add Device Emulation to `testCafe` adapter #173
- [Public] Add `devices` a large List of devices and their properties
- [Public] Add a visual pop up notification to warn about Native Dialog handling for Adapters that don't show native dialogs #192
- [Public] Add `configuration.reporting.nativeDialogsHint.alert` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.prompt` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.confirm` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.onbeforeunload` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.position` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.enabled` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.closeTimeOut` #192
- [Public] Add `useNanoSeconds` to `Cucmber` reporter
- [Public] Add options.disposeAfterHandling to `I.handleNativeDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleAlertDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleConfirmDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleBeforeunloadDialog()` action #188
- [Public] Add `I.handleBeforeunloadDialog()` Controller Action #177
- [Public] Add `I.expectSelector().toHaveExactInnerText()` Assertion Action #69
- [Public] Add `I.fake()` Controller Action #181
- [Public] `I.getCookie()` returns full Cookie Object #150
- [Public] Add `Client.options.device` #173
- [Public] Add `configuration.runner.backoff.adapter` #163
- [Public] Add `configuration.runner.backoff.client` #163
- [Public] Add `configuration.runner.backoff.feature` #163
- [Public] Add `configuration.reporting.notification.onTaskStart` #140
- [Public] Add `configuration.reporting.notification.onTaskDone` #140
- [Public] Add `configuration.reporting.notification.onFeatureStart` #140
- [Public] Add `configuration.reporting.notification.onFeatureDone` #140
- [Public] Add `configuration.reporting.notification.onScenarioStart` #140
- [Public] Add `configuration.reporting.notification.onScenarioDone` #140
- [Public] Add `configuration.reporting.notification.onStepStart` #140
- [Public] Add `configuration.reporting.notification.onStepDone` #140
- [Public] Add more `NetworkConditionPresets`
- [Public] Add `Error.time` to Allure Reporter #174
- [Public] Add `Error.time` to Terminal Reporter
- [Public] Add `Error.time` to Text Reporter
- [Public] Add `Error.time` to JSON Reporter
- [Public] Add `Error.time` to Cucumber Reporter
- [Public] Add `Error.time` to Excel Reporter
- [Public] Add `httpClient` to Test Maker exports to be used as stand-alone without the controller
- [Public] Add `historyFolder` to `Allure` reporter options

### Changes

- [Public] [Breaking] Remove `configuration.reporting.nativeDialogsHint.enabled` #192
- [Public] [Breaking] `configuration.reporting.notification` is now an object
- [Public] [Breaking] `I.getCookie()` returns Cookie object now
- [Public] [Breaking] Rename some of the`NetworkConditionPresets`
- [Public] [Breaking] Rename `I.evalInAllFrames()` `options.onlyMainFrames` to `options.onlyMainFrame`
- [Public] [Breaking] Rename `KeyModifiers.ctrl` option keys are now Capital Case
- [Public] [Breaking] Handling Native dialogs action are now not persisted by default, the handler will be disposed after handling the native dialog unless set otherwise in the options #188
- [Public] [Breaking] `KeyModifiers` now follow the Standards [Modifier keys](developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values)
- [Public] Add default Client's `args` if available
- [Public]  Don't log empty options in asserter if not defined #175
- [Internal] Update `Playwirght` Adapter to handle the persistence of native dialog handling #188
- [Internal] Update `TestCafe` Adapter to handle the persistence of native dialog handling #188
- [Internal] Add `time` to `DetailedError`
- [Internal] Add `historyId` to `Allure` Feature
- [Internal] Add `historyId` to `Allure` Scenario
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Test Maker` websocket CORS issue #196
- [Public] Fix `Selector().clickable()` not giving the correct result #195
- [Public] Fix `Selector().inViewport()` not working correctly #194
- [Public] Fix `Selector().inViewportPartially()` not working correctly #193
- [Public] Fix Allure report is not showing the word "Feature" if only 1 Feature was executed #191
- [Public] Fix Missing `Task Finished` text in Terminal Reporter #187
- [Public] Fix Wrong Score in Terminal Reporter when `Scenario` based score and there is a failure in `before` or `after` hooks #152
- [Public] Fix Double `Task Status` in terminal Reporter #186
- [Public] Fix Regression Wrong Error source line of code due to #171
- [Public] Fix Don't check for plugins if `plugins` store is empty
- [Public] Fix Features zip file `WritableStream` is not built correctly #185
- [Public] Fix Duplicate `max parallel features exceeded` message #109
- [Public] Fix No source code location for Duplicate `Feature` Names in separate File #172
- [Public] Fix Wrong source location for Duplicate `Feature` Names in separate File #171
- [Public] Fix Wrong source location for Duplicate `Feature` Names in same File #171
- [Public] Fix Wrong source location for Duplicate `Scenario` for the Same `Feature` Names in the same File #171
- [Public] Fix Wrong source location for Duplicate `Steps` Names for the same `Scenario` in the same File #171
- [Public] Fix Wrong Task Status in `Terminal` reporter #182
- [Public] Fix NetworkConditionPresets not mapping to real values #176
- [Public] Fix `notificaiotn` not showing on Windows OS
- [Public] Fix NetworkConditionPresets values #176
- [Public] Fix HTTPClientResponse interface is missing the Data type #170
- [Public] Fix not switching to `IFrame` in `I.EvalInAllFrames()` if we could not find any for TestCafe Adapter
- [Public] Fix `I.evalInAllFrames()` not handling all Frames with `TestCafe` Adapter
- [Public] Fix `I.evalInAllFrames()` not working with `TestCafe` Adapter
- [Public] Fix Plugins being initialized twice
- [Public] Fix `Lighthouse` plugin not using default reports directory
- [Public] Fix Plugin not found when using a string as a name for a built-in plugin
- [Public] Fix on demand module installer failing due to `--prefer-offline` argument
- [Public] Fix miss spelling of `therefor` In configuration file have this code and run for only one feature
- [Public] Fix wrong `Total Executed Actions` count in `Terminal` Reporter
- [Public] Fix `Lighthouse` plugin report generator 'not found' error
- [Public] Fix `recursive` error message when installed from Github
- [Public] Fix missing `ms` when Assertion timeout option is provided
- [Public] Fix `HUD` Not hiding due to a small edge detection threshold
- [Public] Fix  `HUD` Not hiding when scrolling
- [Public] Fix `I.parsePDF` Transcoder error
- [Public] Fix  `HUD` for `Playwright` Not appearing after disappearing
- [Public] Fix Selector action done log in Terminal reporter wrong order
- [Public] Fix Don't create Allure Report server if `live mode` is not enabled
- [Public] Fix `I.waitForSelectorToBeInvisible()` undefined timeout
- [Public] Fix `On Demand installer` not installing exact versions
- [Public] Fix `Playwright` adapter not installing correct built-in version after removing `options.customVersion`
- [Public] `Playwright KeyModifiers` not working
- [Public] Fix `Allure` reporter server relative path
- [Public] Fix `Allure` reporter `text/html` attachment not working for `I.addHtmlReporterAttachment()`
- [Public] Fix Error `Cannot read property 'key' of undefined`
- [Public] Fix Native Dialog not handled error not showing
- [Public] Fix `I.setCookie` `sameSite` option not using correct capital Case values
- [Public] Fix `I.setCookie` `expires` not converting the passed date into number which the client expect

## [6.0.0-rc.7] - 2022-01-26

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Selector().clickable()` not giving the correct result #195

## [6.0.0-rc.6] - 2022-01-19

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Selector().inViewport()` not working correctly #194
- [Public] Fix `Selector().inViewportPartially()` not working correctly #193

## [6.0.0-rc.5] - 2022-01-19

### Features

- [Public] Add `configuration.reporting.nativeDialogsHint.alert` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.prompt` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.confirm` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.onbeforeunload` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.position` #192

### Changes

- [Public] [Breaking] Remove `configuration.reporting.nativeDialogsHint.enabled` #192
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

## [6.0.0-rc.4] - 2022-01-18

### Features

- [Public] Add a visual pop up notification to warn about Native Dialog handling for Adapters that don't show native dialogs #192
- [Public] Add `configuration.reporting.nativeDialogsHint.enabled` #192
- [Public] Add `configuration.reporting.nativeDialogsHint.closeTimeOut` #192
- [Public] Add options.disposeAfterHandling to `I.handleNativeDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleAlertDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleConfirmDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleNativeDialog()` action #188
- [Public] Add options.disposeAfterHandling to `I.handleBeforeunloadDialog()` action #188

### Changes

- [Public] [Breaking] Handling Native dialogs action are now not persisted by default, the handler will be disposed after handling the native dialog unless set otherwise in the options #188
- [Internal] Update `Playwirght` Adapter to handle the persistence of native dialog handling #188
- [Internal] Update `TestCafe` Adapter to handle the persistence of native dialog handling #188
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Allure report is not showing the word "Feature" if only 1 Feature was executed #191

## [6.0.0-rc.3] - 2022-01-10

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Missing `Task Finished` text in Terminal Reporter #187
- [Public] Fix Wrong Score in Terminal Reporter when `Scenario` based score and there is a failure in `before` or `after` hooks #152

## [6.0.0-rc.2] - 2022-01-04

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Double `Task Status` in terminal Reporter #186
- [Public] Fix Regression Wrong Error source line of code due to #171

## [6.0.0-rc.1] - 2021-12-31

### Features

- [Public]  Add `X-Ray` plugin #178
- [Public]  Add `Yellow Lab Tools` plugin #183
- [Public]  Add Test Web Server #179
- [Public]  Add Test JSON Data Web Server #180
- [Public]  Add Data Faker #181
- [Public]  Add Microsoft Teams Reporter #184
- [Public]  Add Device Emulation #173
- [Public]  Add Device Emulation to `Playwirght` adapter #173
- [Public]  Add Device Emulation to `testCafe` adapter #173
- [Public]  Add `devices` a large List of devices and their properties
- [Public]  Add `useNanoSeconds` to `Cucmber` reporter
- [Public]  Add `I.fake()` Controller Action #181
- [Public]  Add `I.handleBeforeunloadDialog()` Controller Action #177
- [Public]  Add `I.expectSelector().toHaveExactInnerText()` Assertion Action #69
- [Public]  Add `Client.options.device` #173
- [Public]  Add `configuration.runner.backoff.adapter` #163
- [Public]  Add `configuration.runner.backoff.client` #163
- [Public]  Add `configuration.runner.backoff.feature` #163
- [Public]  Add `configuration.reporting.notification.onTaskStart` #140
- [Public]  Add `configuration.reporting.notification.onTaskDone` #140
- [Public]  Add `configuration.reporting.notification.onFeatureStart` #140
- [Public]  Add `configuration.reporting.notification.onFeatureDone` #140
- [Public]  Add `configuration.reporting.notification.onScenarioStart` #140
- [Public]  Add `configuration.reporting.notification.onScenarioDone` #140
- [Public]  Add `configuration.reporting.notification.onStepStart` #140
- [Public]  Add `configuration.reporting.notification.onStepDone` #140
- [Public]  `I.getCookie()` returns full Cookie Object #150

### Changes

- [Public] [Breaking] `I.getCookie()` returns Cookie object now
- [Public] Add default Client's `args` if available
- [Internal] Use CookieStore when possible
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Don't check for plugins if `plugins` store is empty
- [Public] Fix Features zip file `WritableStream` is not built correctly #185
- [Public] Fix Duplicate `max parallel features exceeded` message #109
- [Public] Fix No source code location for Duplicate `Feature` Names in separate File #172
- [Public] Fix Wrong source location for Duplicate `Feature` Names in separate File #171
- [Public] Fix Wrong source location for Duplicate `Feature` Names in same File #171
- [Public] Fix Wrong source location for Duplicate `Scenario` for the Same `Feature` Names in the same File #171
- [Public] Fix Wrong source location for Duplicate `Steps` Names for the same `Scenario` in the same File #171
- [Public] Fix Wrong Task Status in `Terminal` reporter #182

## [5.1.0-rc.13] - 2021-12-20

### Features

- [Public]  Add `X-Ray` plugin #178
- [Public]  Add `Yellow Lab Tools` plugin #183
- [Public]  Add Test Web Server #179
- [Public]  Add Test JSON Data Web Server #180
- [Public]  Add Data Faker #181
- [Public]  Add Microsoft Teams Reporter #184
- [Public]  Add Device Emulation #173
- [Public]  Add Device Emulation to `Playwirght` adapter #173
- [Public]  Add Device Emulation to `testCafe` adapter #173
- [Public]  Add `devices` a large List of devices and their properties
- [Public]  Add `useNanoSeconds` to `Cucmber` reporter
- [Public]  Add `I.fake()` Controller Action #181
- [Public]  Add `I.handleBeforeunloadDialog()` Controller Action #177
- [Public]  Add `I.expectSelector().toHaveExactInnerText()` Assertion Action #69
- [Public]  Add `Client.options.device` #173
- [Public]  Add `configuration.runner.backoff.adapter` #163
- [Public]  Add `configuration.runner.backoff.client` #163
- [Public]  Add `configuration.runner.backoff.feature` #163
- [Public]  Add `configuration.reporting.notification.onTaskStart` #140
- [Public]  Add `configuration.reporting.notification.onTaskDone` #140
- [Public]  Add `configuration.reporting.notification.onFeatureStart` #140
- [Public]  Add `configuration.reporting.notification.onFeatureDone` #140
- [Public]  Add `configuration.reporting.notification.onScenarioStart` #140
- [Public]  Add `configuration.reporting.notification.onScenarioDone` #140
- [Public]  Add `configuration.reporting.notification.onStepStart` #140
- [Public]  Add `configuration.reporting.notification.onStepDone` #140
- [Public]  `I.getCookie()` returns full Cookie Object #150

### Changes

- [Public] [Breaking] `configuration.reporting.notification` is now an object
- [Public] [Breaking] `I.getCookie()` returns Cookie object now
- [Public] Add default Client's `args` if available
- [Internal] Use CookieStore when possible
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix NetworkConditionPresets not mapping to real values #176
- [Public] Fix `notificaiotn` not showing on Windows OS
- [Public] Fix Don't check for plugins if `plugins` store is empty
- [Public] Fix Features zip file `WritableStream` is not built correctly #185
- [Public] Fix Duplicate `max parallel features exceeded` message #109
- [Public] Fix No source code location for Duplicate `Feature` Names in separate File #172
- [Public] Fix Wrong source location for Duplicate `Feature` Names in separate File #171
- [Public] Fix Wrong source location for Duplicate `Feature` Names in same File #171
- [Public] Fix Wrong source location for Duplicate `Scenario` for the Same `Feature` Names in the same File #171
- [Public] Fix Wrong source location for Duplicate `Steps` Names for the same `Scenario` in the same File #171
- [Public] Fix Wrong Task Status in `Terminal` reporter #182

## [5.1.0-rc.12] - 2021-12-20

### Features

### Changes

- [Public] [Breaking] `configuration.reporting.notification` is now an object
- [Internal] Update Deps
- [Internal]  `time` to `DetailedError`
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix NetworkConditionPresets not mapping to real values #176
- [Public] Fix `notificaiotn` not showing on Windows OS

## [5.1.0-rc.12] - 2021-12-20

### Features

- [Public] Add more `NetworkConditionPresets`
- [Public] Add `Error.time` to Allure Reporter #174
- [Public] Add `Error.time` to Terminal Reporter
- [Public] Add `Error.time` to Text Reporter
- [Public] Add `Error.time` to JSON Reporter
- [Public] Add `Error.time` to Cucumber Reporter
- [Public] Add `Error.time` to Excel Reporter

### Changes

- [Public] [Breaking] Rename some of the`NetworkConditionPresets`
- [Public]  Don't log empty options in asserter if not defined #175
- [Internal] Update Deps
- [Internal] Add `time` to `DetailedError`
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix NetworkConditionPresets values #176

## [5.1.0-rc.11] - 2021-12-14

### Features

### Changes

- [Public] [Breaking] Rename `I.evalInAllFrames()` `options.onlyMainFrames` to `options.onlyMainFrame`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix HTTPClientResponse interface is missing the Data type #170
- [Public] Fix not switching to `IFrame` in `I.EvalInAllFrames()` if we could not find any for TestCafe Adapter

## [5.1.0-rc.10] - 2021-12-13

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.evalInAllFrames()` not handling all Frames with `TestCafe` Adapter

## [5.1.0-rc.9] - 2021-12-13

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.evalInAllFrames()` not working with `TestCafe` Adapter

## [5.1.0-rc.8] - 2021-12-13

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Plugins being initialized twice
- [Public] Fix `Lighthouse` plugin not using default reports directory
- [Public] Fix Plugin not found when using a string as a name for a built-in plugin
- [Public] Fix on demand module installer failing due to `--prefer-offline` argument
- [Public] Fix miss spelling of `therefor` In configuration file have this code and run for only one feature

## [5.1.0-rc.7] - 2021-12-06

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix wrong `Total Executed Actions` count in `Terminal` Reporter
- [Public] Fix `Lighthouse` plugin report generator 'not found' error

## [5.1.0-rc.6] - 2021-11-30

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `recursive` error message when installed from Github
- [Public] Fix missing `ms` when Assertion timeout option is provided

## [5.1.0-rc.5] - 2021-11-26

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `HUD` Not hiding due to a small edge detection threshold
- [Public] Fix  `HUD` Not hiding when scrolling

## [5.1.0-rc.4] - 2021-11-25

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.parsePDF` Transcoder error
- [Public] Fix  `HUD` for `Playwright` Not appearing after disappearing

## [5.1.0-rc.3] - 2021-11-19

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Selector action done log in Terminal reporter wrong order
- [Public] Fix Don't create Allure Report server if `live mode` is not enabled
- [Public] Fix `I.waitForSelectorToBeInvisible()` undefined timeout
- [Public] Fix `On Demand installer` not installing exact versions
- [Public] Fix `Playwright` adapter not installing correct built-in version after removing `options.customVersion`

## [5.1.0-rc.2] - 2021-11-17

### Features

### Changes

- [Public] [Breaking] `KeyModifiers` now follow the Standards [Modifier keys](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values)
- [Public] [Breaking] Rename `KeyModifiers.ctrl` option keys are now Capital Case
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] `Playwright KeyModifiers` not working

## [5.1.0-rc.1] - 2021-11-16

### Features

- [Public] Add `httpClient` to Test Maker exports to be used as stand-alone without the controller
- [Public] Add `historyFolder` to `Allure` reporter options

### Changes

- [Internal] Add `historyId` to `Allure` Feature
- [Internal] Add `historyId` to `Allure` Scenario
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Allure` reporter server relative path
- [Public] Fix `Allure` reporter `text/html` attachment not working for `I.addHtmlReporterAttachment()`
- [Public] Fix Error `Cannot read property 'key' of undefined`
- [Public] Fix Native Dialog not handled error not showing
- [Public] Fix `I.setCookie` `sameSite` option not using correct capital Case values
- [Public] Fix `I.setCookie` `expires` not converting the passed date into number which the client expect

## [5.0.0] - 2021-10-25

### Features

- [Public] Add `I.sendMail()` Action to send emails
- [Public] Add `I.parseMail()` Action to Parse Emails
- [Public] Add `I.createTestMailAccount()` Action to create Test Email Account
- [Public] Add `I.parsePDF()` Action to Parse PDF Files
- [Public] Add `I.addScreenshotReporterAttachment()` Action
- [Public] Add `I.addImageReporterAttachment()` Action
- [Public] Add `I.addTextReporterAttachment()` Action
- [Public] Add `I.addHtmlReporterAttachment()` Action
- [Public] Add `I.benchmark()` to benchmark multiple operation
- [Public] Add `PEGA express` to `ketm init` to Generate a Default convention Test Maker/PEGA project structure
- [Public] Add `PlaywrightAdapterOptions.browser`
- [Public] Add `PlaywrightAdapterOptions.browser.launch`
- [Public] Add `PlaywrightAdapterOptions.browser.launch.timeout`
- [Public] Add  `PlaywrightAdapterOptions.customVersion`
- [Public] Add `configuration.debugging.enabled` to globally enable/disable the debugger
- [Public] Add `configuration.reporting.hud.opacity` to Control the transparency of the HUD
- [Public] Add press `F` button to continue debugging for `Test Info Hud` in Playwright Adapter
- [Public] Add `configuration.http` to configure the defaults for HTTP Clint
- [Public] Add Support for NodeJs 16.X version
- [Public] Add `I.updateInfoHud()` to Update the `TestInfoHud` with custom extra details
- [Public] Add `I.disableInfoHud()` to disable the `TestInfoHud`
- [Public] Add `I.enableInfoHud()` to enable the `TestInfoHud`
- [Public] Add `Test Info Hud` which will allow each Adapter to show Test Info in realtime inside the client
- [Public] Add `Test Info Hud` to Playwright Adapter
- [Public] Add `Continue` button to `Test Info Hud` to continue paused by debugger
- [Public] Add `configuration.reporting.testInfoHud`
- [Public] Add `Session.continueDebugging()` to be called by Adapter when needed
- [Public] Add `I.prependField()` Action to `Playwright` adapter
- [Public] Add `I.prependField()` Action to `TestCafe` adapter
- [Public] Add `characterByCharacter` option to `I.fillField()`
- [Public] Add `characterByCharacter` option to `I.appendField()`
- [Public] Add `I.selectContent()
- [Public] Add Scenario Stats to Terminal Reporter
- [Public] Add Steps Stats to Terminal Reporter
- [Public] Add executed Actions Stats to Terminal Reporter
- [Public] Add `configuration.runner.process.successExitMessage` config
- [Public] Add `configuration.runner.process.successThreshhold` config
- [Public] Add `configuration.runner.process.failureExitCode` config
- [Public] Add `configuration.runner.process.failureExitMessage` config
- [Public] Add `configuration.runner.process.exitOnUnhandledErrors` config
- [Public] Add `TerminalReporterOptions.stats.table`
- [Public] Add `TerminalReporterOptions.stats.features`
- [Public] Add `TerminalReporterOptions.stats.scenarios`
- [Public] Add `TerminalReporterOptions.stats.steps`
- [Public] Add `TerminalReporterOptions.stats.actions`
- [Public] Auto install `fluent-ffmpeg` if video is enabled
- [Public] Use `Playwright` 1.15.z

### Changes

- [Public] [Breaking] Minimum NodeJs version is now `14.14.0`
- [Public] [Breaking] Rename `configuration.reporting.error.allFrames` to `configuration.reporting.error.allCodeFrames`
- [Public] [Breaking] Remove `PlaywrightAdapterOptions.chromiumVersion`
- [Public] [Breaking] Remove `PlaywrightAdapterOptions.firefoxVersion`
- [Public] [Breaking] Remove `PlaywrightAdapterOptions.webkitVersion`
- [Public] [Breaking] Rename `configuration.reporting.testInfoHud` to `configuration.reporting.hud`
- [Public] [Breaking] Change `configuration.reporting.hud` to object
- [Public] [Breaking] Move `configuration.runner.failure.process` to `configuration.runner.process`
- [Public] [Breaking] Move `TerminalReporterOptions.table` to `TerminalReporterOptions.stats.table`
- [Public] Add `I.wait()` to isAppBusyEvaluator` black list
- [Public] Add `handleNativeDialog` to `isAppBusyEvaluator` black list
- [Public] Add `handleConfirmDialog` to `isAppBusyEvaluator` black list
- [Public] Add `handlePromptDialog` to `isAppBusyEvaluator` black list
- [Public] Add `handleAlertDialog` to `isAppBusyEvaluator` black list
- [Public] Install `Modules Installer` dependencies into package.json `dependencies` section
- [Public] `configuration.reporting.hud.enabled` defaults to `false`
- [Public] Update `Modules Installer` to accept option `restart`
- [Public] Only `.mp4` video format is allowed for `I.recordVideo()`
- [Internal] Add `stateManager.state.runner.successPercentage` config
- [Internal] Update `CLI` init to take PEGA Template
- [Internal] Update `CLI` init text
- [Internal] Add `Session.currentAction`
- [Internal] Add `ControllerProxy.extraHudInfo`
- [Internal] Add `ControllerProxy.updateInfoHudInternal()`
- [Internal] Add `debugger:statusChanged` to `ControllerProxy`
- [Internal] Add `debugger:statusChanged` to `Debugger`
- [Internal] Update Controller Logger to update HUD Info
- [Internal] Update Selector Logger to update HUD Info
- [Internal] Update Asserter Logger to update HUD Info
- [Internal] Remove `playwright-chromium` from `modulesInfo`
- [Internal] Remove `playwright-firefox` from `modulesInfo`
- [Internal] Remove `playwright-webkit` from `modulesInfo`
- [Internal] Add hidden `--pnpm`option to `CLI`
- [Internal] Bubble none existing actions errors
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix PDF Parser not showing id property on the field
- [Public] Fix PDF Parser not showing v property on the field
- [Public] Fix Action source log
- [Public] Fix `pnpm` error
- [Public] Fix `Steps` wrong duration in Allure reporter
- [Public] Fix `Hooks` wrong duration in Allure reporter
- [Public] Fix Video recordings not Saved
- [Public] Fix Video recordings not attached to Allure Reporter
- [Public] Fix missing `Undefined Scenarios` in Terminal reporter
- [Public] Fix `HUD` blocking clicking when there is a need to scrolling
- [Public] Fix `HUD` is preventing clicking on elements when there is a need for scrolling
- [Public] Fix `HUD` default opacity is not set to 1
- [Public] Fix `HUD` is still clickable when is not visible in PW
- [Public] Fix `HUD` causing the test to fail if an error happened
- [Public] Fix `HUD` `Sub Step` is undefined
- [Public] Fix `HUD` causing stale error due to sometimes emitting error the event after the session is over
- [Public] Fix `KETM` commands not existing the process correctly when done
- [Public] Fix `Playwright` Adapter mouse indicator not working correctly with IFrame
- [Public] Fix `Playwright` Adapter HUD not working correctly with IFrame
- [Public] Fix `Playwright` not able to launch high number of browser because of the default timeout
- [Public] Fix `Playwright` not installing custom version
- [Public] Fix `HUD` in `Playwright` Adapter still clickable when invisible
- [Public] Fix `I.maximizwWindow()` not working on `Mac OS` for `Playwright` `Chrome`
- [Public] Fix `configuration.runner.timeout.pageLoad` is not working with `Playwright` adapter
- [Public] Fix automatically closed window and its frames is not cleaned up with `Playwright` Adapter
- [Public] Fix `CLI --extra` not working correctly when passing multiple params
- [Public] Fix `I.appendField()` not appending in correct order
- [Public] Fix `I.clearCookies()` not clearing cookies
- [Public] Fix `I.waitForSelectorToBeInvisible()` wrong error message
- [Public] Fix `I.clearCookies()`
- [Public] Fix `expect.toContain()` error on undefined values
- [Public] Fix `Selector` actions not cleared after being used in assertion
- [Public] Fix `lighthouse` plugin reporting
- [Public] Fix slow performance due to wrong action source file
- [Public] Fix Action source not pointing to correct file and location
- [Public] Fix `mapping.wasm` error
- [Public] Fix failure exit message is showing when the process succeeds
- [Public] Fix Remove`replace` from `I.filField()` options
- [Internal] Fix `node_modules` path for installation validation for copy items
- [Internal] Fix missing dash for `no-audit` in module installer
- [Internal] Fix empty stack frames if error is coming from client
- [Internal] Fix `testRunInfo.phase` was not initialized correctly

## [5.0.0-rc.21] - 2021-10-19

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix HUD blocking clicking when there is a need to scrolling

## [5.0.0-rc.20] - 2021-10-11

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix PDF Parser not showing id property on the field

## [5.0.0-rc.19] - 2021-10-11

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix PDF Parser not showing v property on the field

## [5.0.0-rc.18] - 2021-10-11

### Features

- [Public] Add `I.parseMail()` Action to Parse Emails
- [Public] Add `I.parsePDF()` Action to Parse PDF Files

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Playwright Adapter mouse indicator not working correctly with IFrame
- [Public] Fix Playwright Adapter HUD not working correctly with IFrame

## [5.0.0-rc.17] - 2021-10-04

### Features

- [Public] Add `I.addScreenshotReporterAttachment()` Action
- [Public] Add `I.addImageReporterAttachment()` Action
- [Public] Add `I.addTextReporterAttachment()` Action
- [Public] Add `I.addHtmlReporterAttachment()` Action

### Changes

- [Internal] Bubble none existing actions errors
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

## [5.0.0-rc.16] - 2021-09-28

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix Action source log

## [5.0.0-rc.15] - 2021-09-28

### Features

- [Public] Add `PlaywrightAdapterOptions.browser`
- [Public] Add `PlaywrightAdapterOptions.browser.launch`
- [Public] Add `PlaywrightAdapterOptions.browser.launch.timeout`

### Changes

- [Public] Install `Modules Installer` dependencies into package.json `dependencies` section
- [Public] `configuration.reporting.hud.enabled` defaults to `false`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Playwright` not able to launch high number of browser because of the default timeout

## [5.0.0-rc.14] - 2021-09-26

### Features

### Changes

- [Internal] Add hidden `--pnpm`option to `CLI`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `pnpm` error
- [Public] Fix `Steps` wrong duration in Allure reporter

## [5.0.0-rc.13] - 2021-09-24

### Features

- [Public] Add  `PlaywrightAdapterOptions.customVersion`
- [Public] Use `Playwright` 1.15.z

### Changes

- [Public] [Breaking] Remove `PlaywrightAdapterOptions.chromiumVersion`
- [Public] [Breaking] Remove `PlaywrightAdapterOptions.firefoxVersion`
- [Public] [Breaking] Remove `PlaywrightAdapterOptions.webkitVersion`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Playwright` not installing custom version

## [5.0.0-rc.12] - 2021-09-18

### Features

### Changes

- [Internal] Remove `playwright-chromium` from `modulesInfo`
- [Internal] Remove `playwright-firefox` from `modulesInfo`
- [Internal] Remove `playwright-webkit` from `modulesInfo`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Hooks` wrong duration in Allure reporter

## [5.0.0-rc.11] - 2021-09-17

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `HUD` is preventing clicking on elements when there is a need for scrolling
- [Public] Fix Video recordings not Saved
- [Public] Fix Video recordings not attached to Allure Reporter

## [5.0.0-rc.10] - 2021-09-15

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `HUD` default opacity is not set to 1
- [Public] Fix `HUD` is still clickable when is not visible in PW
- [Public] Fix missing `Undefined Scenarios` in Terminal reporter

## [5.0.0-rc.9] - 2021-09-11

### Features

- [Public] Add `configuration.reporting.hud.opacity` to Control the transparency of the HUD

### Changes

- [Public] [Breaking] Rename `configuration.reporting.testInfoHud` to `configuration.reporting.hud`
- [Public] [Breaking] Change `configuration.reporting.hud` to object
- [Public] Add `handleNativeDialog` to `isAppBusyEvaluator` black list
- [Public] Add `handleConfirmDialog` to `isAppBusyEvaluator` black list
- [Public] Add `handlePromptDialog` to `isAppBusyEvaluator` black list
- [Public] Add `handleAlertDialog` to `isAppBusyEvaluator` black list
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `HUD` causing the test to fail if an error happened
- [Public] Fix `HUD` `Sub Step` is undefined

## [5.0.0-rc.8] - 2021-09-10

### Features

- [Public] Add press `F` button to continue debugging for `Test Info Hud` in Playwright Adapter
- [Public] Add `configuration.http` to configure the defaults for HTTP Clint
- [Public] Add Support for NodeJs 16.X version

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `KETM` commands not existing the process correctly when done
- [Public] Fix `Test Info Hud` in Playwright Adapter still clickable when invisible
- [Public] Fix `Test Info Hud` causing stale error due to sometimes emitting error the event after the session is over
- [Internal] Fix missing dash for `no-audit` in module installer

## [5.0.0-rc.7] - 2021-09-09

### Features

- [Public] Add `I.benchmark()` to benchmark multiple operation
- [Public] Add `I.updateInfoHud()` to Update the `TestInfoHud` with custom extra details
- [Public] Add `I.disableInfoHud()` to disable the `TestInfoHud`
- [Public] Add `I.enableInfoHud()` to enable the `TestInfoHud`
- [Public] Add `Test Info Hud` which will allow each Adapter to show Test Info in realtime inside the client
- [Public] Add `Test Info Hud` to Playwright Adapter
- [Public] Add `Continue` button to `Test Info Hud` to continue paused by debugger
- [Public] Add `configuration.reporting.testInfoHud`
- [Public] Add `Session.continueDebugging()` to be called by Adapter when needed

### Changes

- [Internal] Add `Session.currentAction`
- [Internal] Add `ControllerProxy.extraHudInfo`
- [Internal] Add `ControllerProxy.updateInfoHudInternal()`
- [Internal] Add `debugger:statusChanged` to `ControllerProxy`
- [Internal] Add `debugger:statusChanged` to `Debugger`
- [Internal] Update Controller Logger to update HUD Info
- [Internal] Update Selector Logger to update HUD Info
- [Internal] Update Asserter Logger to update HUD Info
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Internal] Fix empty stack frames if error is coming from client
- [Internal] Fix `testRunInfo.phase` was not initialized correctly

## [5.0.0-rc.6] - 2021-09-07

### Features

- [Public] Add `I.prependField()` Action to `Playwright` adapter
- [Public] Add `I.prependField()` Action to `TestCafe` adapter
- [Public] Add `PEGA express` to `ketm init` to Generate a Default convention Test Maker/PEGA project structure
- [Public] Add `configuration.debugging.enabled` to globally enable/disable the debugger

### Changes

- [Public] Update `Modules Installer` to accept option `restart`
- [Internal] Update `CLI` init to take PEGA Template
- [Internal] Update `CLI` init text
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.appendField()` not appending in correct order

## [5.0.0-rc.5] - 2021-09-04

### Features

- [Public] Add `I.sendMail()` Action to send emails
- [Public] Add `I.createTestMailAccount()` Action to create Test Email Account

### Changes

- [Public] [Breaking] Rename `configuration.reporting.error.allFrames` to `configuration.reporting.error.allCodeFrames`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.maximizwWindow()` not working on `Mac OS` for `Playwright` `Chrome`
- [Public] Fix `I.clearCookies()` not clearing cookies
- [Public] Fix `configuration.runner.timeout.pageLoad` is not working with `Playwright` adapter
- [Public] Fix `CLI --extra` not working correctly when passing multiple params

## [5.0.0-rc.4] - 2021-08-28

### Features

- [Public] Add `characterByCharacter` option to `I.fillField()`
- [Public] Add `characterByCharacter` option to `I.appendField()`

### Changes

- [Public] Add `I.wait()` to isAppBusyEvaluator` black list
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.waitForSelectorToBeInvisible()` wrong error message
- [Public] Fix `I.clearCookies()`
- [Public] Fix `Selector` actions not cleared after being used in assertion
- [Public] Fix automatically closed window and its frames is not cleaned up with `Playwright` Adapter
- [Public] Fix `lighthouse` plugin reporting

## [5.0.0-rc.3] - 2021-08-26

### Features

### Changes

- [Public] [Breaking] Minimum NodeJs version is now `14.14.0`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix slow performance due to wrong action source file
- [Public] Fix Action source not pointing to correct file and location
- [Internal] Fix `node_modules` path for installation validation for copy items

## [5.0.0-rc.2] - 2021-08-16

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `mapping.wasm` error

## [5.0.0-rc.1] - 2021-08-16

### Features

- [Public] Add `I.selectContent()
- [Public] Add Scenario Stats to Terminal Reporter
- [Public] Add Steps Stats to Terminal Reporter
- [Public] Add executed Actions Stats to Terminal Reporter
- [Public] Add `configuration.runner.process.successExitMessage` config
- [Public] Add `configuration.runner.process.successThreshhold` config
- [Public] Add `configuration.runner.process.failureExitCode` config
- [Public] Add `configuration.runner.process.failureExitMessage` config
- [Public] Add `configuration.runner.process.exitOnUnhandledErrors` config
- [Public] Add `TerminalReporterOptions.stats.table`
- [Public] Add `TerminalReporterOptions.stats.features`
- [Public] Add `TerminalReporterOptions.stats.scenarios`
- [Public] Add `TerminalReporterOptions.stats.steps`
- [Public] Add `TerminalReporterOptions.stats.actions`
- [Public] Auto install `fluent-ffmpeg` if video is enabled

### Changes

- [Public] [Breaking] Move `configuration.runner.failure.process` to `configuration.runner.process`
- [Public] [Breaking] Move `TerminalReporterOptions.table` to `TerminalReporterOptions.stats.table`
- [Public] Only `.mp4` video format is allowed for `I.recordVideo()`
- [Internal] Add `stateManager.state.runner.successPercentage` config
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix failure exit message is showing when the process succeeds
- [Public] Fix Remove`replace` from `I.filField()` options

## [4.3.0] - 2021-08-10

### Features

- [Public] Add Scenario Stats to Terminal Reporter
- [Public] Add Steps Stats to Terminal Reporter
- [Public] Add executed Actions Stats to Terminal Reporter
- [Public] Add `configuration.runner.process.successExitMessage` config
- [Public] Add `configuration.runner.process.successThreshhold` config
- [Public] Add `configuration.runner.process.failureExitCode` config
- [Public] Add `configuration.runner.process.failureExitMessage` config
- [Public] Add `configuration.runner.process.exitOnUnhandledErrors` config

### Changes

- [Public] [Breaking] Move `configuration.runner.failure.process` to `configuration.runner.process`
- [Internal] Add `stateManager.state.runner.successPercentage` config
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix failure exit message is showing when the process succeeds

## [4.2.2] - 2021-07-29

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `I.addReporterAttachment()` not accepting content only instead of Path
- [Public] Fix Allure Reporter not rendering `I.addReporterAttachment()` attachments

## [4.2.1] - 2021-06-23

### Features

- [Public] `I.selectTextAreaContent()` will now select all lines if no parameters passed

### Changes

- [Public] [Breaking] Remove `I.ResizeWindowToFitDevice()`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix unwanted log before Terminal Reporter Table
- [Public] Fix `Feature.page()` not working
- [Public] Fix `Scenario.page()` not working
- [Public] Fix `Step.page()` not working
- [Public] Fix `I.SelectEditableContent()` should not select if there is no parent with `contentEditable` attribute
- [Public] Fix Feature timeout not working correctly  `Inifinity` or `0` as values
- [Public] Fix Scenario timeout not working correctly  `Inifinity` or `0` as values
- [Public] Fix Step timeout not working correctly  `Inifinity` or `0` as values

## [4.2.0] - 2021-06-12

### Features

- [Public] Improve `Could not inject Test Maker Default Assets.` message
- [Public] Add 3 digits to milliseconds time logging

### Changes

- [Public] [Breaking] Change `configuration.logging.template.pattern` parameter `logMethod` to `logLevel`
- [Public] Change `Could not inject Test Maker Default Assets.` log level to `info`
- [Public] Change `configuration.logging.logLevel` to `configuration.logging.globalLogLevel`

### Fixes

- [Public] Fix Playwright Controller error `jsHandle.evaluate: Evaluation failed` for Mouse Events

## [4.1.0] - 2021-06-09

### Features

- [Public] Add `configuration.logging.terminalSizeFallback` to define a custom terminal window size when it is not available in some environments
- [Public] Enhance TerminalReporter Table output

### Changes

- [Public] [Breaking] Change `configuration.logging.template.pattern` parameter `logLevel` to `logMethod`
- [Public] Redirect `Could not inject Test Maker Default Assets.` to user Logger
- [Public] Default Terminal Window size when not available in the environment is 80 X 24
- [Internal] Create a more complete Selector Cloning util function

### Fixes

- [Public] Fix `I.waitForSelectActionabilityCheck()` is ignoring `Selector`'s actions
- [Public] Fix Terminal Reporter table width
- [Public] Fix Selector actions are empty due to incorrect cloning
- [Public] Fix multi line `Feature` name not parsed correctly

## [4.1.0-rc.2] - 2021-06-08

### Features

### Changes

- [Public] [Breaking] Change `configuration.logging.template.pattern` parameter `logLevel` to `logMethod`

### Fixes

- [Public] Fix `I.waitForSelectActionabilityCheck()` is ignoring `Selector`'s actions

## [4.1.0-rc.1] - 2021-06-08

### Features

- [Public] Add `configuration.logging.terminalSizeFallback` to define a custom terminal window size when it is not available in some environments

### Changes

- [Public] Default Terminal Window size when not available in the environment is 80 X 24
- [Internal] Create a more complete Selector Cloning util function

### Fixes

- [Public] Fix Terminal Reporter table width
- [Public] Fix Selector actions are empty due to incorrect cloning

## [4.0.0] - 2021-06-06

### Features

[Public] Add retryCount a parameter to `WaitForConditionOptions.retryMessage` if a function is passed

- [Public] Add `logger.log` with advanced logging options
- [Public] Add `logger.warn` with advanced logging options
- [Public] Add `logger.info` with advanced logging options
- [Public] Add `logger.trace` with advanced logging options
- [Public] Add `logger.debug` with advanced logging options
- [Public] Add `logger.error` with advanced logging options
- [Public] Add `logLevel` parameter to `configuration.logging.controllerLogger.pattern`
- [Public] Add `I.dragToSelector` Action to Playwright Adapter
- [Public] Add `configuration.installer.addToPackageJson`
- [Public] Add `configuration.logging.controllerLogger.logTypePrefix`
- [Public] Add `configuration.logging.controllerLogger.dateTimePrefix`
- [Public] Add `configuration.logging.controllerLogger.featurePrefix`
- [Public] Add `configuration.logging.controllerLogger.scenarioPrefix`
- [Public] Add `configuration.logging.controllerLogger.stepPrefix`
- [Public] Add `configuration.logging.controllerLogger.subStepPrefix`
- [Public] Add `configuration.logging.controllerLogger.pattern`
- [Public] Add `configuration.reporting.error.codeFrameOrder`
- [Public] Add `configuration.reporting.error.stackTraceOrder`
- [Public] Add `configuration.reporting.error.stackFilter`
- [Public] Add `configuration.build.cache.enabled`
- [Public] Add `configuration.build.cache.path`
- [Public] Add `dateFormat` to `Terminal` Reporter options
- [Public] Add `SelectorActionInfo.meta`
- [Public] Add `antialiasing` option to `odiff` visual testing plugin
- [Public] Add `dependencyType` to `Modules Installer`
- [Public] Add `CPU usage` chart to `The Eye` dashboard
- [Public] Add `Memory usage` chart to `The Eye` dashboard
- [Public] Add `Newman` Plugin to run Postman Collections
- [Public] Add `JMeter` Plugin for Load Testing
- [Public] Add `Artillery` Plugin for Load Testing
- [Public] Add `validate` command to `KETM`
- [Public] Add the defined config's timeout to the timeout error message
- [Public] Add `Selector` Details to `I.waitForSelectorToExist` Action
- [Public] Add `Selector` Details to `I.waitForSelectorToNotExist` Action
- [Public] Add `Selector` Details to `I.waitForSelectorToBeVisible` Action
- [Public] Add `Selector` Details to `I.waitForSelectorToBeInvisible` Action
- [Public] Add `Selector` Details to `I.waitForSelectActionabilityCheck` Action
- [Public] Pass any data type to logger
- [Public] Show error message if retrying condition's timeout option equals or less than interval option
- [Public] bypass `WaitForConditionOptions.retryMessage` if a function is passed
- [Public] `WaitForConditionOptions.errorMessage` accepts a function
- [Public] `WaitForConditionOptions.overrideErrorMessage` accepts a function
- [Public] `WaitForConditionOptions.retryMessage` accepts a function
- [Public] Normalize`Error` object passed to `Logger` methods into a string
- [Public] Reuse the same `Selector` multiple times, without the need to use `Selector.clone()`
- [Public] Expose `modules installer`
- [Public] Improve Selector not found Error message
- [Public] `isAppBusyEvaluator` is executed per `Controller` Action
- [Public] Considerably Faster installation due to surgically optimizing Deps
- [Public] Up to 50% Faster Playwright Launch and close
- [Public] Up to 100% Faster Selector Assertion
- [Public] Faster client Scripts compilation by Auto polyfilling based on need, which will result in Up to 120-170% faster Page ready for actions
- [Public] `I.log,debug,etc..` now can take the new Template Parser format with pipes and placeholders
- [Public] Sync `Feature` color in `Terminal` Reporter Table with the Status

### Changes

- [Public] [Breaking] `WaitForConditionOptions.errorMessage` accepts only a string
- [Public] [Breaking] `WaitForConditionOptions.errorOverrideMessage` accepts only a string
- [Public] [Breaking] Move `configuration.logging.controllerLogger.logTypePrefix` to `configuration.logging.template.logTypePrefix`
- [Public] [Breaking] Move `configuration.logging.controllerLogger.dateTimePrefix` to `configuration.logging.template.dateTimePrefix`
- [Public] [Breaking] Move `configuration.logging.controllerLogger.featurePrefix` to `configuration.logging.template.featurePrefix`
- [Public] [Breaking] Move `configuration.logging.controllerLogger.scenarioPrefix` to `configuration.logging.template.scenarioPrefix`
- [Public] [Breaking] Move `configuration.logging.controllerLogger.stepPrefix` to `configuration.logging.template.stepPrefix`
- [Public] [Breaking] Move `configuration.logging.controllerLogger.subStepPrefix` to `configuration.logging.template.subStepPrefix`
- [Public] [Breaking] Move `configuration.logging.controllerLogger.pattern` to `configuration.logging.template.pattern`
- [Public] [Breaking] Rename `WaitForConditionOptions.message` to `WaitForConditionOptions.errorMessage`
- [Public] [Breaking] Rename `WaitForConditionOptions.overrideMessage` to `WaitForConditionOptions.overrideErrorMessage`
- [Public] [Breaking] Remove `I.log`
- [Public] [Breaking] Remove `I.info`
- [Public] [Breaking] Remove `I.trace`
- [Public] [Breaking] Remove `I.warn`
- [Public] [Breaking] Remove `I.debug`
- [Public] [Breaking] Remove `I.error`
- [Public] [Breaking] `configuration.logging.controllerLogger.pattern` now returns `Promise<{template:string,data?:Record<string,any>}>`
- [Public] Log `Test Maker Dashboard` url
- [Public] Throw an Error when using `Playwright` adapter if `I.emulateNetworkConditions` is used with browser other than chromium based
- [Internal] Remove Babel wrap plugin
- [Internal] Add Typescript sourceMapSupportTransformer transformer
- [Internal] Add Typescript tryCatchWrapTransformer transformer
- [Internal] Disable `babel` for string compilation if no need to polyfill
- [Internal] Update `modules installer` to use `--no-save` option
- [Internal] Move Notification into a built-in plugin
- [Internal] Embed required dependencies to prevent long installation
- [Internal] Rest Selector state after resolving
- [Internal] Resolve actual once before all Assertion Actions
- [Internal] Only clone Selector for assertion when needed
- [Internal] Clone Selector state on each Assertion retry
- [Internal] Change `Playwright` Adapter client instance from new Browser to new Context
- [Internal] Add `TemplateParser`
- [Internal] Add `id` to `Embedding`
- [Internal] Add `browserName` to `Playwright` Adapter Controller
- [Internal] Add retrying for waiting for Client Socket when making a call
- [Internal] Add copyBundledDeps helper
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix unintended log of Selector internal Actions
- [Public] Fix `Logger` formatting for none string values
- [Public] Fix `I.waitForSelectorToExist()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectorToNotExist()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectorToBeVisible()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectorToBeInvisible()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectActionabilityCheck()` not using a cloned `Selector` on each retry
- [Public] Fix `Return value` based Controller Actions do not log Action start in case of error in actions queue occurs
- [Public] Fix Fluent API controller Actions should not execute if a previous action in the queue fails
- [Public] Fix Terminal not logging skipped phases is skipped
- [Public] Fix `isAppBusyEvaluator` is not registered correctly on first run
- [Public] Fix `isAppBusyEvaluator` checks should always be logged before actions
- [Public] Fix Missing `Selector.clickable`
- [Public] Fix `Typescript` typechecking is not checking only source files
- [Public] Fix Assertion `not` operator not chaining actions
- [Public] Fix Assertion should not retry if Primitive/none Promise values are passed
- [Public] Fix Assertion error message is containing Selector Error Message even with not Selector errors
- [Public] Fix `I.addReporterAttachment` not working in hooks
- [Public] Fix `I.maximizeWindow()` not working `Playwright's Firefox and Webkit`
- [Public] Fix `I.resizeWindow()` not working `Playwright's Firefox and Webkit`
- [Public] Fix `safari` client not launching in `Playwright` adapter
- [Public] Fix Client Side script compilation not able to find dependencies
- [Public] Fix Allure report attachment default height is too small
- [Public] Fix Allure report Full screen attachment viewer not taking full page height
- [Public] Fix Allure report error source first line indentation
- [Public] Fix `Webhint` Plugin report empty name
- [Public] Fix node internal stack showing in error details code frames
- [Public] Fix undefined targetFrame causing error `fullFilePath` of undefined
- [Public] Fix undefined targetFrame causing error `lineNumber` of undefined
- [Public] Fix Features Statistics not calculated if `table` option is not enabled in `Terminal` reporter
- [Public] Fix `Test Maker needs to be restarted typo`
- [Public] Fix some `Selector` Actions not logging `done` phase in `Terminal` reporter
- [Public] Fix missing `PLaywright selector.sibling()`
- [Public] Fix missing `PLaywright selector.nextSibling()`
- [Public] Fix missing code frames in Errors not originating from Feature
- [Public] Fix `Selector.with()`
- [Public] Fix `After` Hooks duration of 0
- [Public] Fix `Phase` should be skipped if Session reached a timeout
- [Public] Fix screenshot is not taking on timeout
- [Public] Fix the `Eye` dashboard charts not working
- [Public] Fix the `Eye` dashboard Feature status not updated
- [Public] Fix the `Eye` dashboard log is not in correct format
- [Internal] Fix double compilation of Clients Scripts
- [Internal] Fix calling Test Maker Socket error when call is made before initiating
- [Internal] ErrorParser cached source for specTarget path

## [4.0.0-rc.24] - 2021-06-05

### Features

[Public] Add retryCount a parameter to `WaitForConditionOptions.retryMessage` if a function is passed
[Public] bypass `WaitForConditionOptions.retryMessage` if a function is passed

### Changes

[Public] [Breaking] `WaitForConditionOptions.errorMessage` accepts only a string
[Public] [Breaking] `WaitForConditionOptions.errorOverrideMessage` accepts only a string

### Fixes

- [Public] Fix unintended log of Selector internal Actions
- [Public] Fix `Logger` formatting for none string values

## [4.0.0-rc.23] - 2021-07-02

### Features

[Public] `WaitForConditionOptions.errorMessage` accepts a function
[Public] `WaitForConditionOptions.overrideErrorMessage` accepts a function
[Public] `WaitForConditionOptions.retryMessage` accepts a function
[Public] Normalize`Error` object passed to `Logger` methods into a string

### Changes

[Public] [Breaking] Move `configuration.logging.controllerLogger.logTypePrefix` to `configuration.logging.template.logTypePrefix`
[Public] [Breaking] Move `configuration.logging.controllerLogger.dateTimePrefix` to `configuration.logging.template.dateTimePrefix`
[Public] [Breaking] Move `configuration.logging.controllerLogger.featurePrefix` to `configuration.logging.template.featurePrefix`
[Public] [Breaking] Move `configuration.logging.controllerLogger.scenarioPrefix` to `configuration.logging.template.scenarioPrefix`
[Public] [Breaking] Move `configuration.logging.controllerLogger.stepPrefix` to `configuration.logging.template.stepPrefix`
[Public] [Breaking] Move `configuration.logging.controllerLogger.subStepPrefix` to `configuration.logging.template.subStepPrefix`
[Public] [Breaking] Move `configuration.logging.controllerLogger.pattern` to `configuration.logging.template.pattern`
[Public] [Breaking] Rename `WaitForConditionOptions.message` to `WaitForConditionOptions.errorMessage`
[Public] [Breaking] Rename `WaitForConditionOptions.overrideMessage` to `WaitForConditionOptions.overrideErrorMessage`

### Fixes

- [Public] Fix `I.waitForSelectorToExist()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectorToNotExist()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectorToBeVisible()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectorToBeInvisible()` not using a cloned `Selector` on each retry
- [Public] Fix `I.waitForSelectActionabilityCheck()` not using a cloned `Selector` on each retry
- [Public] Fix `Return value` based Controller Actions do not log Action start in case of error in actions queue occurs
- [Public] Fix `Return value` based Controller Actions do not log Action start in case of error in actions queue occurs
- [Public] Fix Fluent API controller Actions should not execute if a previous action in the queue fails

## [4.0.0-rc.22] - 2021-06-30

### Features

- [Public] Add `logger.log` with advanced logging options
- [Public] Add `logger.warn` with advanced logging options
- [Public] Add `logger.info` with advanced logging options
- [Public] Add `logger.trace` with advanced logging options
- [Public] Add `logger.debug` with advanced logging options
- [Public] Add `logger.error` with advanced logging options
- [Public] Pass any data type to logger
- [Public] Show error message if retrying condition's timeout option equals or less than interval option

### Changes

[Public] [Breaking] Remove `I.log`
[Public] [Breaking] Remove `I.info`
[Public] [Breaking] Remove `I.trace`
[Public] [Breaking] Remove `I.warn`
[Public] [Breaking] Remove `I.debug`
[Public] [Breaking] Remove `I.error`

### Fixes

- [Public] Fix Terminal not logging skipped phases is skipped
- [Public] Fix `isAppBusyEvaluator` is not registered correctly on first run
- [Public] Fix `isAppBusyEvaluator` checks should always be logged before actions

## [4.0.0-rc.21] - 2021-06-25

### Features

- [Public] Add `logLevel` parameter to `configuration.logging.controllerLogger.pattern`

### Changes

- [Public] Disable `isAppBusyEvaluator` for `I.log`
- [Public] Disable `isAppBusyEvaluator` for `I.info`
- [Public] Disable `isAppBusyEvaluator` for `I.trace`
- [Public] Disable `isAppBusyEvaluator` for `I.warn`
- [Public] Disable `isAppBusyEvaluator` for `I.debug`
- [Public] Disable `isAppBusyEvaluator` for `I.error`

### Fixes

## [4.0.0-rc.20] - 2021-06-25

### Features

- [Public] Add `I.dragToSelector` Action to Playwright Adapter
- [Public] Add `logLevel` parameter to `configuration.logging.controllerLogger.pattern`

### Changes

- [Public] [Breaking] `configuration.logging.controllerLogger.pattern` now returns `Promise<{template:string,data?:Record<string,any>}>`
- [Internal] Remove Babel wrap plugin
- [Internal] Add Typescript sourceMapSupportTransformer transformer
- [Internal] Add Typescript tryCatchWrapTransformer transformer

### Fixes

- [Public] Fix Missing `Selector.clickable`

## [4.0.0-rc.19] - 2021-06-22

### Features

- [Public] Add `configuration.installer.addToPackageJson`
- [Public] Add `configuration.logging.controllerLogger.logTypePrefix`
- [Public] Add `configuration.logging.controllerLogger.dateTimePrefix`
- [Public] Add `configuration.logging.controllerLogger.featurePrefix`
- [Public] Add `configuration.logging.controllerLogger.scenarioPrefix`
- [Public] Add `configuration.logging.controllerLogger.stepPrefix`
- [Public] Add `configuration.logging.controllerLogger.subStepPrefix`
- [Public] Add `configuration.logging.controllerLogger.pattern`
- [Public] Add `configuration.reporting.error.codeFrameOrder`
- [Public] Add `configuration.reporting.error.stackTraceOrder`
- [Public] Add `configuration.reporting.error.stackFilter`
- [Public] Add `configuration.build.cache.enabled`
- [Public] Add `configuration.build.cache.path`
- [Public] Add `dateFormat` to `Terminal` Reporter options
- [Public] Add `SelectorActionInfo.meta`
- [Public] Add `antialiasing` option to `odiff` visual testing plugin
- [Public] Add `dependencyType` to `Modules Installer`
- [Public] Add `CPU usage` chart to `The Eye` dashboard
- [Public] Add `Memory usage` chart to `The Eye` dashboard
- [Public] Add `Newman` Plugin to run Postman Collections
- [Public] Add `JMeter` Plugin for Load Testing
- [Public] Add `Artillery` Plugin for Load Testing
- [Public] Add `validate` command to `KETM`
- [Public] Add the defined config's timeout to the timeout error message
- [Public] Reuse the same `Selector` multiple times, without the need to use `Selector.clone()`
- [Public] Expose `modules installer`
- [Public] Improve Selector not found Error message
- [Public] `isAppBusyEvaluator` is executed per `Controller` Action
- [Public] Considerably Faster installation due to surgically optimizing Deps
- [Public] Up to 50% Faster Playwright Launch and close
- [Public] Up to 100% Faster Selector Assertion
- [Public] Faster client Scripts compilation by Auto polyfilling based on need, which will result in Up to 120-170% faster Page ready for actions
- [Public] `I.log,debug,etc..` now can take the new Template Parser format with pipes and placeholders
- [Public] Add `Selector` Details to `I.waitForSelectorToExist` Action
- [Public] Add `Selector` Details to `I.waitForSelectorToNotExist` Action
- [Public] Add `Selector` Details to `I.waitForSelectorToBeVisible` Action
- [Public] Add `Selector` Details to `I.waitForSelectorToBeInvisible` Action
- [Public] Add `Selector` Details to `I.waitForSelectActionabilityCheck` Action
- [Public] Sync `Feature` color in `Terminal` Reporter Table with the Status

### Changes

- [Public] Log `Test Maker Dashboard` url
- [Public] Throw an Error when using `Playwright` adapter if `I.emulateNetworkConditions` is used with browser other than chromium based
- [Internal] Disable `babel` for string compilation if no need to polyfill
- [Internal] Update `modules installer` to use `--no-save` option
- [Internal] Move Notification into a built-in plugin
- [Internal] Embed required dependencies to prevent long installation
- [Internal] Rest Selector state after resolving
- [Internal] Resolve actual once before all Assertion Actions
- [Internal] Only clone Selector for assertion when needed
- [Internal] Clone Selector state on each Assertion retry
- [Internal] Change `Playwright` Adapter client instance from new Browser to new Context
- [Internal] Add `TemplateParser`
- [Internal] Add `id` to `Embedding`
- [Internal] Add `browserName` to `Playwright` Adapter Controller
- [Internal] Add retrying for waiting for Client Socket when making a call
- [Internal] Add copyBundledDeps helper
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] Code refactoring
- [Internal] Code cleanup

### Fixes

- [Public] Fix `Typescript` typechecking is not checking only source files
- [Public] Fix Assertion `not` operator not chaining actions
- [Public] Fix Assertion should not retry if Primitive/none Promise values are passed
- [Public] Fix Assertion error message is containing Selector Error Message even with not Selector errors
- [Public] Fix `I.addReporterAttachment` not working in hooks
- [Public] Fix `I.maximizeWindow()` not working `Playwright's Firefox and Webkit`
- [Public] Fix `I.resizeWindow()` not working `Playwright's Firefox and Webkit`
- [Public] Fix `safari` client not launching in `Playwright` adapter
- [Public] Fix Client Side script compilation not able to find dependencies
- [Public] Fix Allure report attachment default height is too small
- [Public] Fix Allure report Full screen attachment viewer not taking full page height
- [Public] Fix Allure report error source first line indentation
- [Public] Fix `Webhint` Plugin report empty name
- [Public] Fix node internal stack showing in error details code frames
- [Public] Fix undefined targetFrame causing error `fullFilePath` of undefined
- [Public] Fix undefined targetFrame causing error `lineNumber` of undefined
- [Public] Fix Features Statistics not calculated if `table` option is not enabled in `Terminal` reporter
- [Public] Fix `Test Maker needs to be restarted typo`
- [Public] Fix some `Selector` Actions not logging `done` phase in `Terminal` reporter
- [Public] Fix missing `PLaywright selector.sibling()`
- [Public] Fix missing `PLaywright selector.nextSibling()`
- [Public] Fix missing code frames in Errors not originating from Feature
- [Public] Fix `Selector.with()`
- [Public] Fix `After` Hooks duration of 0
- [Public] Fix `Phase` should be skipped if Session reached a timeout
- [Public] Fix screenshot is not taking on timeout
- [Public] Fix the `Eye` dashboard charts not working
- [Public] Fix the `Eye` dashboard Feature status not updated
- [Public] Fix the `Eye` dashboard log is not in correct format
- [Internal] Fix double compilation of Clients Scripts
- [Internal] Fix calling Test Maker Socket error when call is made before initiating
- [Internal] ErrorParser cached source for specTarget path

## [3.0.0] - 2021-04-28

### Features

- [Public] Improve `Test Maker` start by 50%
- [Public] Improve Spec Compilation speed by 20%-50%
- [Public] Improve Page load 50% by serving cached and minified files
- [Public] Run multi Adapters simultaneously
- [Public] Parallel is available in Live Mode now
- [Public] Parallel can be Applied to Adapters
- [Public] Parallel can be Applied to Clients
- [Public] Run only changed Files in Live Mode
- [Public] New Improved clear and Stylish `Terminal` Reporter
- [Public] New `Terminal Eye` Dashboard
- [Public] New `CPU` usage Profiling
- [Public] New `Memory` usage Profiling
- [Public] New `LightHouse` Web Page auditing plugin
- [Public] New `WebHint` Web Page auditing plugin
- [Public] New `oDiff` Visual Testing Plugin
- [Public] New `jimpDiff` Visual Testing Plugin
- [Public] Show `Test Maker` Version on Process Start
- [Public] Show current `Frame`context in Controller Action log
- [Public] Show current `Frame` context in Selector Action log
- [Public] Show all Error `Code Frames`
- [Public] Show Original Source Files in `Stack Trace`
- [Public] Show passed Selector info in selector Error Log
- [Public] Show Selector failed Action in Error Log
- [Public] Show descriptive error and spec file code with line and column for compilation error of empty keyword name
- [Public] Show descriptive error and spec file code with line and column for compilation error of duplicate Feature
- [Public] Show descriptive error and spec file code with line and column for compilation error of duplicate Scenario
- [Public] Show descriptive error and spec file code with line and column for compilation error of duplicate Step
- [Public] Show Error if passed Selector timeout is less than the allowed minimum
- [Public] Show Error if Selector is passed to Assertion with a lager timeout than Assertion's timeout
- [Public] Show the module version being installed when using `Install On Demand`
- [Public] Warn the user if the Parallelism is higher than the number of runnable files
- [Public] Show Selector error details in `I.watirFor...` actions error message
- [Public] Show correct line source for timeout error
- [Public] Show the Action error source if `configuration.runner.isAppBusyEvaluator` fails
- [Public] Export `adapters` to get default Adapters List
- [Public] Prevent Duplicate Scenario names under the same Feature
- [Public] Prevent empty `Feature` name
- [Public] Prevent empty `Scenario` name
- [Public] Prevent empty `Step` name
- [Public] Don't compile or run features filtered by `--filter-feature`
- [Public] Throw an `Error` on calling a Controller Action that does not exist
- [Public] `configuration.suites` now accepts a string array as source path
- [Public] `configuration.runner.failure.feature.skipRemainingScenariosOnScenarioFail` now accepts a function
- [Public] `configuration.runner.failure.feature.skipRemainingStepsOnStepFail` now accepts a function
- [Public] Ability to extend the `Selector` with `Custom` `Actions`
- [Public] Ability to extend the `Assertion` with `Custom` `Actions`
- [Public] Allow system relative local file path as url in `I.goto()`
- [Public] Allow Lazy `Selector` defined out of session scope;
- [Public] File Logging is now stream based
- [Public] Add `video attachments` to `Allure` reporter
- [Public] Add `dateFormat` to `Allure` reporter options
- [Public] Add `scoreBase` to `Allure` reporter options
- [Public] Log Report Path for `Allure` reporter
- [Public] Group by Features in Allure
- [Public] Categorize features in Allure reporter based on Tags
- [Public] Show Each Phase in Allure report and list the phase errors and embeddings under it instead of being scattered
- [Public] `Feature.tags()` now accepts a comma separated string
- [Public] `Scenario.tags()` now accepts a comma separated string
- [Public] `Step.tags()` now accepts a comma separated string
- [Public] `Selector` getters are now lazy executed
- [Public] Throw an error if `KETM` gets passed an unknown argument
- [Public] Add `ketm --profile-memory` to profile Memory
- [Public] Add `ketm --profile-cpu` to profile CPU
- [Public] Add `ketm --parallel-features` to set number of concurrent `Features` to run
- [Public] Add `ketm --parallel-clients` to set number of concurrent `Clients` to run
- [Public] Add `ketm --parallel-adapters` to set number of concurrent `Adapters` to run
- [Public] Add `ketm --filter-feature-tag` with ability to filer based on logical expression
- [Public] Add `ketm --filter-scenario-tag` with ability to filer based on logical expression
- [Public] Add `ketm --filter-step-tag` with ability to filer based on logical expression
- [Public] Add `updateConfiguration` helper function to update `Test Maker` `Configuration` during run-time
- [Public] Add `default` to `Adapter` to set the Default Adapter explicitly
- [Public] Add `files` to `Adapter` to filter by files
- [Public] Add `features` to `Adapter` to filter by features
- [Public] Add `scenarios` to `Adapter` to filter by scenarios
- [Public] Add `steps` to `Adapter` to filter by steps
- [Public] Add `files` to `Client` to filter by files
- [Public] Add `features` to `Client` to filter by features
- [Public] Add `scenarios` to `Client` to filter by scenarios
- [Public] Add `steps` to `Client` to filter by steps
- [Public] Add `Adapter.install` to allow installing required modules before start
- [Public] Add `Reporter.install` to allow installing required modules before start
- [Public] Add `Plugin.install` to allow installing required modules before start
- [Public] Add `Logger` with Logging levels
- [Public] Add `ScenarioTimeout`
- [Public] Add `Scenario.timeout()`
- [Public] Add `StepTimeout`
- [Public] Add `step.timeout()`
- [Public] Add `webkit` to built-in clients
- [Public] Add `cliArgs,configuration` params to `beforeAllHook`
- [Public] Add `cliArgs,configuration` params to `afterAllHook`
- [Public] Add `configuration.restoreIfModified` to reset config after each feature if modified by the developer
- [Public] Add `configuration.reporting.error.allFrames`
- [Public] Add `configuration.logging.level`
- [Public] Add `configuration.logging.overrideConsole`
- [Public] Add `configuration.runner.isAppBusyEvaluator`
- [Public] Add `I`, `testRunInfo` as params to `configuration.runner.isAppBusyEvaluator.condition`
- [Public] Add `testRunInfo.appIsBusy`
- [Public] Add `configuration.runner.scenarioTimeout`
- [Public] Add `configuration.runner.prxoy`
- [Public] Add `configuration.runner.debugging.onControllerActions`
- [Public] Add `configuration.runner.debugging.onSelectorActions`
- [Public] Add `configuration.runner.debugging.onAssertionActions`
- [Public] Add `configuration.runner.keepClientopen` to persist the `Client` during `Live Mode`
- [Public] Add `configuration.runner.throttleActions.controller`
- [Public] Add `configuration.runner.throttleActions.selector`
- [Public] Add `configuration.runner.throttleActions.assertion`
- [Public] Add `configuration.runner.process.exitCode`
- [Public] Add `configuration.runner.process.exitMessage`
- [Public] Add `configuration.runner.process.exitOnUnhandledErrors`
- [Public] Add `configuration.runner.stepTimeout`
- [Public] Add `configuration.runner.nodeVersion` to specify the required NodeJs version to run
- [Public] Add `configuration.runner.failure.feature.exitOnFirstFail` to exit the process on the first occurrence of a failure in the Feature
- [Public] Add `configuration.build.compiler.compileOnly` to only compile the test files and simulate a dry run
- [Public] Add `feature` to `runInfo`
- [Public] Add `scenario` to `runInfo`
- [Public] Add `step` to `runInfo`
- [Public] Add `interval` to `Selector`'s `options`
- [Public] Add `retries` to `Selector`'s `options`
- [Public] Add `backoff` to `Selector`'s `options`
- [Public] Add `maxBackOff` to `Selector`'s `options`
- [Public] Add `message` to `Selector`'s `options`
- [Public] Add `overrideMessage` to `Selector`'s `options`
- [Public] Add `retryMessage` to `Selector`'s `options`
- [Public] Add loading options to `I.waitForframeToLoad` Action
- [Public] Add  `domin, secure, samesite` options to `I.setCookie` Action
- [Public] Add `video` support to `Playwright` Adapter
- [Public] Add `Proxy` support to `Playwright` Adapter
- [Public] Add `Proxy` support to `testCafe` Adapter
- [Public] Add `runInfo.adapter`
- [Public] Add `runInfo.client`
- [Public] Add `Feature.adapters` to run the Feature only in the specified Adapters
- [Public] Add `Feature.clients` to run the Feature only in the specified Clients
- [Public] Add `Scenario.adapters` to run the Scenario only in the specified Adapters
- [Public] Add `Scenario.clients` to run the Scenario only in the specified Clients
- [Public] Add `Step.adapters` to run the Step only in the specified Adapters
- [Public] Add `Step.clients` to run the Step only in the specified Clients
- [Public] Add `I.takeSelectorScreenshot` Action to `Test Cafe` Adapter
- [Public] Add `I.takeSelectorScreenshot` Action to `Playwright` Adapter
- [Public] Add `I.recordvideo` with ability to pause, resume and stop the recording
- [Public] Add `I.addReporterAttachment` to Attach content, paths to files for reporters
- [Public] Add `I.debug` Action to pause and debug code
- [Public] Add `I.drag` Action to `Playwright` Adapter
- [Public] Add `I.I.emulateNetworkConditions` To Emulate Network speed and conditions
- [Public] Add `I.waitForFrameToLoad` Action can accept Iframe child selector (xpath or css) as condition
- [Public] Add `I.log` with advanced logging options
- [Public] Add `I.warn` with advanced logging options
- [Public] Add `I.info` with advanced logging options
- [Public] Add `I.trace` with advanced logging options
- [Public] Add `I.debug` with advanced logging options
- [Public] Add `I.error` with advanced logging options
- [Public] Add `I.selectTextAreaContent` Action to `Playwright` Adapter
- [Public] Add `I.selectEditableContent` Action to `Playwright` Adapter
- [Public] Add `I.evalInMainWindowFrame` Action
- [Public] Add `I.evalInCurrentWindowMainFrame` Action
- [Public] Add `I.evalInAllFrames` Action
- [Public] `I.upload` Action can now accept new options `filesSelector`,`submitSelector` and `delayBeforeSubmit` options to prevent failures if the app is slow in attaching the files.
- [Public] Add `I.selectOption` Action can now accept `{label,value,index} as options
- [Public] Add `I.deselectOption` Action can now accept `{label,value,index} as options
- [Public] Add `I.updateConfiguration` Action
- [Public] Add `I.restorConfiguration` Action
- [Public] Add `I.scrollPage` Action
- [Public] Add `I.waitForSelectorToNotExist` Action
- [Public] Add `I.waitForSelectActionabilityCheck` Action
- [Public] Add `I.mouseUp` Action
- [Public] Add `I.mouseDown` Action
- [Public] Add `I.mouseMove` Action
- [Public] Add `I.pressKeyUp` Action
- [Public] Add `I.pressKeydown` Action
- [Public] Add `I.expectSelector().toHaveInnerText` Matcher
- [Public] Add ability to pass a function to selector
- [Public] Add `Selector.clone` to clone selector with ability to clone or not clone already added Actions
- [Public] Add `Selector.all` Method to get an iterable list of matched Selector
- [Public] Add `Selector.stable` Property
- [Public] Add `Selector.inViewport` Property
- [Public] Add `Selector.inViewportPartially` Property
- [Public] Add `Selector.editable` Property
- [Public] Add `Selector.attached` Property
- [Public] Add `Selector.enabled` Property
- [Public] Add `Selector.disabled` Property
- [Public] Add `retryMessage` option to `waitUntil`
- [Public] Add `overrideMessage` option to `waitUntil`
- [Public] Add `retries` option to `I.waitForCondition`
- [Public] Add `throwOnError` option to `I.waitFor...`
- [Public] Add `maxBackOff` option to `I.waitFor...` Actions
- [Public] Add `mergeAndCompare` helper
- [Public] Add `throwOnError` for `I.waitForCondition` options
- [Public] Add `notRetryableError` for `I.waitForCondition` `option.condition` as parameter, that when used in a throw will exist the wait condition
- [Public] Add `or` to Assertion evaluation
- [Public] Add `string` diff to `Assertion` log
- [Public] Add more details to `Excel` reporter
- [Public] Add Error to `I.selectOption` if not all passed options are set
- [Public] Add Error to `I.desSelectOption` if not all passed options are unset
- [Public] Add `hookStart` to `Reporter`
- [Public] Add `hookDone` to `Reporter`
- [Public] Add `Playwright` adapter `options.version` to install a custom version of Playwright
- [Public] Add `Test Cafe` adapter `options.version` to install a custom version of `Test Cafe`
- [Public] Add `scoreBase` to `Terminal` Reporter options
- [Public] Add `ignoreLogLevel` to `Terminal` Reporter options
- [Public] Add `feature.start` to `Terminal` Reporter options
- [Public] Add `feature.done` to `Terminal` Reporter options
- [Public] Add `scenario.start` to `Terminal` Reporter options
- [Public] Add `scenario.done` to `Terminal` Reporter options
- [Public] Add `step.start` to `Terminal` Reporter options
- [Public] Add `step.done` to `Terminal` Reporter options
- [Public] Add `subStep.start` to `Terminal` Reporter options
- [Public] Add `subStep.done` to `Terminal` Reporter options
- [Public] Add `hook.start` to `Terminal` Reporter options
- [Public] Add `hook.done` to `Terminal` Reporter options
- [Public] Add `bypass` to `Terminal` Reporter options
- [Public] Add `controllerAction.start` to `Terminal` Reporter options
- [Public] Add `controllerAction.done` to `Terminal` Reporter options
- [Public] Add `controllerAction.source` to `Terminal` Reporter options
- [Public] Add `selectorAction.start` to `Terminal` Reporter options
- [Public] Add `selectorAction.done` to `Terminal` Reporter options
- [Public] Add `selectorAction.source` to `Terminal` Reporter options
- [Public] Add `assertionAction.start` to `Terminal` Reporter options
- [Public] Add `assertionAction.done` to `Terminal` Reporter options
- [Public] Add `assertionAction.source` to `Terminal` Reporter options
- [Public] Add `assertionAction.retries` to `Terminal` Reporter options
- [Public] Add `completioncounter` to `Terminal` Reporter options
- [Public] Add `Adapter` to `Terminal` Reporter
- [Public] Add `Client` to `Terminal` Reporter
- [Public] Add `Start Time` to `Terminal` Reporter
- [Public] Add `End Time` to `Terminal` Reporter
- [Public] Add `source` to `Terminal` Reporter action
- [Public] Add `duration` to `Terminal` Reporter table
- [Public] Add `in isAppBusy` to `Terminal` Reporter table
- [Public] Add `phase` to `Reporter.runInfo`
- [Public] Pass `ClientFunction` dependencies as extra arguments to the function
- [Public] Pass `I.eval` dependencies as extra arguments to the function
- [Public] `Playwright` Adapter now installs only used browser, this decreases install and download by a great margin

### Changes

- [Public] [Breaking] Minimum required `NodeJS` version is `14.0.0`
- [Public] [Breaking] Remove `visibilityCheck` from Selector Option
- [Public] [Breaking] Rename `i.debug` to `I.debugger`
- [Public] [Breaking] Rename `i.evalInMainWindowFrame` to `I.evalInMainWindowMainFrame`
- [Public] [Breaking] Rename `i.moveCursorTo` to `I.moveCursorToSelector`
- [Public] [Breaking] Rename `i.dragToElement` to `I.dragToSelector`
- [Public] [Breaking] Rename `i.takeElementScreenshot` to `I.takeSelectorScreenshot`
- [Public] [Breaking] Rename `NodeSnapShot` to `SelectorSnapShot`
- [Public] [Breaking] Rename `i.scrollTo` to `I.scrollToSelector`
- [Public] [Breaking] Rename `I.scrollPage` to `I.scrollTo`
- [Public] [Breaking] Rename `I.scrollPageToBottom` to `I.scrollToBottom`
- [Public] [Breaking] Rename `I.scrollPageToTop` to `I.scrollToTop`
- [Public] [Breaking] Rename `I.scrollPageToSelector` to `I.scrollToSelector`
- [Public] [Breaking] Rename `I.getPageScrollPosition` to `I.getScrollPosition`
- [Public] [Breaking] Rename `I.refreshPage` to `I.refresh`
- [Public] [Breaking] Rename `I.getPageSource` to `I.getSource`
- [Public] [Breaking] Rename `I.pressUpKey` to `I.pressArrowUpKey`
- [Public] [Breaking] Rename `I.pressDownKey` to `I.pressArrowDownKey`
- [Public] [Breaking] Rename `I.pressLeftKey` to `I.pressArrowLeftKey`
- [Public] [Breaking] Rename `I.pressRighttKey` to `I.pressArrowRightKey`
- [Public] [Breaking] Rename `I.updateInfoBar` to `I.getSpecStates`
- [Public] [Breaking] Rename `Adapter.runnerStart` to `Adapter.clientStart`
- [Public] [Breaking] Rename `Adapter.runnerRestart` to `Adapter.clientRestart`
- [Public] [Breaking] Rename `Adapter.runnerStop` to `Adapter.clientStop`
- [Public] [Breaking] Rename `plugins` is now made of categories
- [Public] [Breaking] Rename `configuration.reporting.screenshot...phases` to `configuration.reporting.screenshot.enabledIn`
- [Public] [Breaking] Rename `configuration.specs` to `configuration.gherkin`
- [Public] [Breaking] Rename `configuration.startPage` to `configuration.runner.startPage`
- [Public] [Breaking] Rename `configuration.runner.detectAppIsBusy` to `configuration.runner.isAppBusyEvaluator`
- [Public] [Breaking] Rename `configuration.runner.adapter` to `configuration.runner.adapters`
- [Public] [Breaking] Rename `configuration.runner.parallel` to `configuration.runner.parallel.features`
- [Public] [Breaking] Rename `configuration.runner.parallel` to `configuration.runner.parallel.clients`
- [Public] [Breaking] Rename `configuration.runner.parallel` to `configuration.runner.parallel.adapters`
- [Public] [Breaking] Rename `configuration.runner.debugMode` to `configuration.debugging`
- [Public] [Breaking] Rename `configuration.runner.debugOnFail` to `configuration.debugging.OnFailure`
- [Public] [Breaking] Rename `configuration.runner.throttleActions` to `configuration.runner.throttling`
- [Public] [Breaking] Rename `configuration.runner.skipNextScenarioOnFail` to `configuration.runner.feature.skipNextScenarioOnFail`
- [Public] [Breaking] Rename `configuration.runner.skipNextStepOnFail` to `configuration.runner.feature.skipNextStepOnFail`
- [Public] [Breaking] Rename `configuration.runner.featureTimeout` to `configuration.runner.timeout.feature`
- [Public] [Breaking] Remove `I.isEditable`
- [Public] [Breaking] Remove `Selector.addCustomDOMProperties`
- [Public] [Breaking] Remove `Selector.addCustomMethods`
- [Public] [Breaking] Remove `cli --clients` as we define clients per adapter now
- [Public] [Breaking] Remove `cli --parallel` as we have more control now
- [Public] [Breaking] Remove `cli --star-page`
- [Public] [Breaking] Remove `cli` short version commands which are not valid, like `-s-u`
- [Public] [Breaking] Remove `configuration.mode`
- [Public] [Breaking] Remove `configuration.runner.clients`
- [Public] [Breaking] Remove `configuration.runner.disablePageReload`
- [Public] [Breaking] Remove `configuration.runner.runnerPerFeature`
- [Public] [Breaking] Remove `configuration.runner.skipJsErrors`
- [Public] [Breaking] Remove `configuration.runner.skipUncaughtErrors`
- [Public] [Breaking] Remove `configuration.runner.stopOnFirstFail`
- [Public] [Breaking] Remove `configuration.reporting.feature`
- [Public] [Breaking] Remove `configuration.reporting.scenario`
- [Public] [Breaking] Remove `configuration.reporting.step`
- [Public] [Breaking] Remove `configuration.reporting.selector`
- [Public] [Breaking] Remove `configuration.reporting.controller`
- [Public] [Breaking] Remove `configuration.reporting.assertion`
- [Public] [Breaking] Remove `configuration.reporting.screenshot...phases` to `configuration.reporting.screenshot.enabledInt...phases`
- [Public] [Breaking] Rename `configuration.runner.parallel` is now an Object
- [Public] [Breaking] Rename `configuration.runner.failure.feature.exitOnFirstFail` o `configuration.runner.failure.feature.exitProcessOnFirstFail`
- [Public] [Breaking] Rename `configuration.runner.failure.feature.skipNextScenarioOnFail` o `configuration.runner.failure.feature.skipRemainingScenariosOnScenarioFail`
- [Public] [Breaking] Rename `configuration.runner.failure.feature.skipNextStepOnFail` o `configuration.runner.failure.feature.skipRemainingStepsOnStepFail`
- [Public] [Breaking] child Hierarchy steps will be skipped if parent step fails
- [Public] [Breaking] After hooks will run even if related Step has Failed
- [Public] [Breaking] `I.upload` now takes options object
- [Public] [Breaking] `I.waitForFrameToLoad` now takes an object as param
- [Public] [Breaking] `I.selectTextAreaContent` now takes an object as param
- [Public] [Breaking] `I.waitForSelectorToExist` now takes options from the Selector itself
- [Public] [Breaking] `I.waitForSelectorToNotExist` now takes options from the Selector itself
- [Public] [Breaking] `I.waitForSelectorToBeVisible` now takes options from the Selector itself
- [Public] [Breaking] `I.waitForSelectorToBeInvisible` now takes options from the Selector itself
- [Public] [Breaking] `I.eval` now takes single argument, let it be object, string, array, etc... passing extra arguments will not be parsed
- [Public] [Breaking] `expect` can only be used throw `I.expect`
- [Public] [Breaking] `expectSelector` can only be used throw `I.expectSelector`
- [Public] Better Typescript Typing
- [Public] change the color of Action source line and column markers to green to not single it is an error
- [Public] Required modules to be installed are installed in one go now
- [Public] Change Minimum `Selector` timeout to `100ms`
- [Public] Improve colors on Terminal reporter to be compatible with as much terminals as possible
- [Public] if `configuration.reporting.screenshots.failedOnly` is enabled, Screenshots are taken only at the phase where error occurred
- [Public] auto align properties values in Terminal reporter
- [Public] Change red color logging for none errors
- [Public] Change default `Chromium` based `Client` size to `1280 X 720`
- [Public] Change default `configuration.runner.adapter` to `Playwright`
- [Public] Change default `configuration.runner.pageLoadTimeout` to 5000
- [Public] Change default `configuration.runner.selectorTimeout` to 10000
- [Public] Change default `configuration.runner.assertionTimeout` to 12000
- [Public] Change description for `LiveMode` `ctrl-c`
- [Public] Prevent Controller log on timeout error
- [Public] Prevent Selector log on timeout error
- [Public] Rename `data-test-maker-id` for iframe element to `data-test-maker-frame-id`
- [Public] Update `readme.md`
- [Public] Shorten build files names to avoid Pax headers
- [Public] Improve Terminal Reporter timing format
- [Public] Improve error message for wrong suites configuration
- [Public] Improve error message for wrong source configuration
- [Internal] Remove `babel-loader` from Feature Loader
- [Internal] Remove `babel-plugins` from Feature Loader
- [Internal] Add custom AST parsing for Feature Loader
- [Internal] Restore config if updated after each feature
- [Internal] Prevent overriding Controller action with custom ones
- [Internal] Prevent overriding Selector action with custom ones
- [Internal] Convert `webpack.config` to typescript
- [Internal] Parallel execute operations when possible
- [Internal] Parallel Load imports when possible
- [Internal] Cache files sources
- [Internal] Add `padAllLines` Helpers
- [Internal] Add `ModulesInstaller`
- [Internal] Add `Excel` reporter to the Eye configurator
- [Internal] Add retrier Helper
- [Internal] Add `Session.currentPhaseContext`
- [Internal] Add `PhaseContext.timeout`
- [Internal] Add `FeatureSpec.hooks`
- [Internal] Add `ScenarioSpec.hooks`
- [Internal] Add `StepSpec.hooks`
- [Internal] Add `PhaseContext.timeoutStart`
- [Internal] Add `PhaseContext.exceededTimeout`
- [Internal] Add `babelWrapFunctionInTryCatchPlugin` to Specs Compiler to improve Error catching
- [Internal] Add `TS Parsing` to create Feature AST Tree
- [Internal] Improve `babelWrapFunctionInTryCatchPlugin` parsing and walking performance
- [Internal] Normalize Selector arg for `ClientFunction`
- [Internal] Normalize Selector arg for `I.eval`
- [Internal] Normalize Selector dependency for ClientFunction
- [Internal] Normalize Selector dependency for `I.eval`
- [Internal] Inject default scripts assets only if Adapter Type is `Web`
- [Internal] Automatically inject default scripts assets on each frame or page load
- [Internal] Move `I.select` to be handled by the Adapter
- [Internal] Move to event system for `Engine` and `reporter`
- [Internal] Change Logger Implementation
- [Internal] Abstract `configuration` to `ConfigManger`
- [Internal] Abstract `state` to `StateManger`
- [Internal] Abstract `instanceOptions` to `InstanceManger`
- [Internal] Improve `getSession` logic
- [Internal] Create `Logical Expression Parser`
- [Internal] Remove `Runner Proxy`
- [Internal] Remove `cucumber-tag-expressions` dependency
- [Internal] Remove `cucumber-tag-expressions` dependency
- [Internal] Remove `expr-eval` dependency
- [Internal] Remove quotes escaping in log
- [Internal] Add bundling Optimization to `client-scripts`
- [Internal] Separate source map for `client-scripts`
- [Internal] Cache injected CSS Files
- [Internal] Cache injected JS Files
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix Log Level
- [Public] Fix double log in Test Maker log file
- [Public] Fix Text Reporter Memory leak
- [Public] Fix Assertion wrong Logging
- [Public] Fix not showing Feature error source if `tsconfig.target` is set to `es5`
- [Public] Fix inCorrect parsing of Feature name if there is special characters like comma
- [Public] Fix Process is hanging if `Feature` file is commented
- [Public] Fix `on Demand Installer` not saving exact version of installed modules
- [Public] Fix errors leaking into `isAppBusyEvaluator`
- [Public] Fix `isAppBusyEvaluator` leaking errors
- [Public] Fix `Playwright` screen size is not correct in `headless` mode
- [Public] Fix `Playwright` filter method
- [Public] Fix `Playwright` Dialog Handling
- [Public] Fix `Playwright` wrong window Context when switching to `mainFrame` while using Multi Windows
- [Public] Fix `Playwright` Selector `withAttribute` Regex not matching
- [Public] Fix `Playwright` Selector `ithText` Regex not matching
- [Public] Fix `I.go` wrong parameter passed
- [Public] Fix `I.closeWindow` with `playwright` adapter not switching to the previous window
- [Public] Fix `I.sendPostRequest` not sending correct data structure
- [Public] Fix `I.sendPutRequest` not sending correct data structure
- [Public] Fix `I.sendPatchRequest` not sending correct data structure
- [Public] Fix `I.evalInAllFrames` executing in closed window context
- [Public] Fix `I.waitForSelectorToExist` not using the default `configuration.runner.selectorTimeout
- [Public] Fix `I.waitForSelectorToNotExist` not using the default `configuration.runner.selectorTimeout
- [Public] Fix `I.waitForSelectorToBeInvisible` not using the default `configuration.runner.selectorTimeout
- [Public] Fix `I.waitForSelectorToBeVisible` not using the default `configuration.runner.selectorTimeout
- [Public] Fix Normalize arguments passed to `ClientFunction` correctly
- [Public] Fix `I.waitForCondition` not showing internal error
- [Public] Fix `I.waitForCondition` should not throw on internal error
- [Public] Fix `I.waitForFrameToLoad` not using the default `configuration.runner.selectorTimeout
- [Public] Fix `Selector.hasAttrbiute` should return false instead of undefined
- [Public] Fix `expect().toBeOk()` should fail on `undefined` value
- [Public] Fix Diffing circular objects
- [Public] Fix Diffing for string showing wrong results if empty string is passed
- [Public] Fix `I.expect` Error location
- [Public] Fix `expectSelector().toHaveCssClass()` not resolving `Selector` correctly
- [Public] Fix remove `file:/` from `Stack Trace` lines
- [Public] Fix CLI `filter-scenario` not applying correct values
- [Public] Fix CLI arguments not overriding config file
- [Public] Fix CLI `ketm generate feature` not exiting
- [Public] Fix CLI not exiting on `ketm --version`
- [Public] Fix CLI not exiting on `ketm --help`
- [Public] Fix `Allure` report faviocn.ico was corrupted
- [Public] Fix `AssertThat` plugin failing on uploading large content
- [Public] Fix Showing Typescript check errors if typeCheck is enabled
- [Public] Fix `mssage undefined` by adding default `DetailedError` values if error parsing fails
- [Public] Fix `Terminal` reporter logging in spite of a step timeout was reached
- [Public] Fix `Terminal` reporter wrong percentage calculations
- [Public] Fix `Terminal` reporter hooks duration
- [Public] Fix watching `Test Maker Config` only if `Live Mode` is used
- [Internal] Fix retrier rogue promise
- [Internal] Fix retrier appending condition body error message to final message
- [Internal] Fix Term-size being called on every request causing some Docker based envs to slow down

## [2.3.2] - 2020-10-27

### Features

### Changes

- [Public] Show Timeout time in Selector Error message
- [Public] `Selector.exists` now returns ture or false even if the chain fails
- [Internal] Don't Return Adapter Selector if last Action returns a value
- [Internal] add `overrideMessage` option to `waitUntil` helper
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

## [2.3.1] - 2020-10-27

- [Public] Show correct name of Selector.expect().toExist() method

### Features

### Changes

- [Internal] Don't Return Adapter Selector if last Action returns a value
- [Internal] Don't clear `Selector` actions if last action returns a value
- [Internal] add `returnValue` to action in `SelectorProxy`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix Client side Error `sandbox of undefined` when using `TestCafe` Adapter
- [Public] Fix Logging Selector instead of Actual value in Asserter
- [Public] Fix `configuration.build.ouput.path` not resolved correctly if custom path is passed

## [2.3.0] - 2020-10-26

### Features

- [Public] New `Install On Demand` for `Adapters`, and adapter won't be installed unless it is used. This minimizes Test Maker installation footprint by large
- [Public] Improve build performance of specs files by utilizing caching
- [Public] Add `Excel` Reporter
- [Public] Add `Excel` Reporter to the `Eye`
- [Public] Add `Export As Excel` to the `Eye's` Dashboard
- [Public] Add `--override` to `KETM run` which allows for overriding any Test Maker Config from command line
- [Public] Expose Controller Actions related to Selector on the Selector itself for improved user experience
- [Public] Ability to extend the `Controller` with `Custom` `Actions`
- [Public] Selectors are re-executable now, which means that the Selector will be fully re-evaluated on each call unless it is re-assigned to a previous state
- [Public] `Controller` actions like `I.openWindow()` can now be chained to previous none returning actions
- [Public] Show Exact line of Error source when `Controller` Actions are chained
- [Public] Show Exact line of Error source when `Selector` Actions are chained
- [Public] Show Exact line of Error source when `Asserter` Actions are chained
- [Public] Automatically use `waitForFrameToLoad` in `I.switchToFrame`
- [Public] Add `store` option to `I.cut` to store cut value into a variable
- [Public] Add `store` option to `I.copy` to store cut value into a variable
- [Public] Add `store` option to `I.paste` to store cut value into a variable
- [Public] Add `toBeEnabled` `Selector` `Assertion` matcher
- [Public] Add `toBeDisabled` `Selector` `Assertion` matcher
- [Public] Add `toBeRuired` `Selector` `Assertion` matcher
- [Public] Add `toHaveValue` `Selector` `Assertion` matcher
- [Public] Add `maxDepth` option to `Assertion` to optionally truncate long objects Log
- [Public] Add `Keys` list to select pre-made keyboard keys
- [Public] Add All `Permissions` like `clipboard`, etc... to `Playwright` `Adapter`
- [Public] Add `pressKey` Action to `Playwright` `Controller`
- [Public] Add `setCookie` Action to `Playwright` `Controller`
- [Public] Add `getCookie` Action to `Playwright` `Controller`
- [Public] Add `clearCookie` Action to `Playwright` `Controller`
- [Public] Add `deleteCookie` Action to `Playwright` `Controller`
- [Public] Add `updateInfobar` Action to `ControllerProxy`, now each adapter can choose how to handle updates of test phases
- [Public] Automatically disable Parallelism in `liveMode`
- [Public] prevent having `Steps` with the same name under the same `Scenario`

### Changes

- [Public] [Breaking] Default Adapter is now `Playwirght`
- [Public] [Breaking] Change `waitForElementToExist` to  `I.waitForSelectorToExist`
- [Public] [Breaking] Change `waitForElementToBeVisible` to  `I.waitForSelectorToBeVisible`
- [Public] [Breaking] Change `waitForElementToBeInvisible` to  `I.waitForSelectorToBeInvisible`
- [Public] Add `Features` to `Severity` Chart title in the `Eye`
- [Public] Add `Features` to `Status` Chart title in the `Eye`
- [Public] Change `ketm generate` `test-machine.local.ts` to `test-maker.local.ts`
- [Public] Change `ketm generate` `test-machine.ci.ts` to `test-maker.ci.ts`
- [Public] Change `ketm generate` `test:local: ketm run -c test-machine.local.ts` to `ketm run -c test-maker.local.ts`
- [Public] Change `ketm generate` `test:ci: ketm run -c test-machine.ci.ts` to `ketm run -c test-maker.ci.ts`
- [Internal] Make `Playwright` Adapter installed on Demand
- [Internal] Make `Testcafe` Adapter installed on Demand
- [Internal] Remove `Appium` Adapter until it is stabilized
- [Internal] Remove `FlaUI` Adapter until it is stabilized
- [Internal] Inject default scripts only if `Adapter` type is `web`
- [Internal] Enable `Babel` caching for `Specs Compiler`
- [Internal] Enable `Babel` caching for `Compile To String`
- [Internal] Add Source Map Support to `Specs Compiler`
- [Internal] Update `Webpack` to version 5
- [Internal] Update `Webpack` to version 5
- [Internal] Remove `Webpack` `library` option for Features compiler
- [Internal] Remove `Webpack` `library` option for `Test Maker`
- [Internal] Replace `Uglifyjs` with `TerserPlugin` in `Webpack` config for `Test Maker`
- [Internal] Initialize new  `ConrollerProxy`  on each consecutive call of the Selector
- [Internal] Auto inject default assets before each Controller Action if not injected
- [Internal] Resolve `Playwright` Selector once
- [Internal] add`selectorAction Decorator to `Playwright` `Selector`
- [Internal] Correctly resolve `Selector` in `ConrollerProxy`
- [Internal] Conditional constants values based on client / server environment
- [Internal] add `installOnDemand` helper
- [Internal] add `jsonTruncate` helper
- [Internal] add `formUrlEncoded` helper
- [Internal] Remove dependency on `superagnet`
- [Internal] Remove dependency on `superagnet-proxy`
- [Internal] Remove `globalAPI`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix Long log Object in `Controller` Action
- [Public] Fix `I.expect` executing before waiting for Controller previous actions
- [Public] Fix `I.expectSelector` executing before waiting for Controller previous actions
- [Public] Fix `Can't read property constructor of undefined` with `TestCafe` `Selector`
- [Public] Fix Long log Object in `Selector` Action
- [Public] Fix Long log Object in `Assertion`
- [Public] Fix Long log Object in `File Logger` Action
- [Public] Fix `CopyPasteManager` Error
- [Public] Fix `Allure Reporter` file lock
- [Public] Fix imports/exports not working for `client-scripts` in browser

## [2.2.5] - 2020-10-09

### Features

- [Public] A Solid new `Selector` results that is based on evaluating the whole chain of the `Selector's` actions instead of just the first match, regardless of the used `Adapter`

### Changes

- [Public] `Selector` now evaluates the whole chain until we reach a stable result
- [Internal] Keep retrying within the timeout frame until we get at least one element in the `SelectorProxy` to stabilize the `Selector` whole chain
- [Internal] add `__VALID__CHAIN__` Property to the stable resolved `Selector`
- [Internal] add __NORMALIZED__SELECTOR__ Property to the stable resolved `Selector` to prevent re-evaluating
- [Internal] Append the result elements of `Playwright` `Selector` actions instead of resetting on re-resolve
- [Internal] Get the `ElementHandle` Directly in `Playwright` `Controller` instead of re-evaluating the Selector
- [Internal] Remove `filters` list from `Playwright` `Selector`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix not able to call `Selector` methods after first evaluation
- [Internal] Fix `Playwright` `Selector` not evaluating the correct elements
- [Internal] Fix `ControllerProxy` normalization of Selector was not evaluated correctly to the target `Adapter's Selector ` if a string as a Selector was passed

## [2.2.4] - 2020-10-09

### Features

- [Public] A Solid new `Selector` results that is based on evaluating the whole chain of the `Selector's` actions instead of just the first match, regardless of the used `Adapter`

### Changes

- [Public] `Selector` now evaluates the whole chain until we reach a stable result
- [Internal] Keep retrying within the timeout frame until we get at least one element in the `SelectorProxy` to stabilize the `Selector` whole chain
- [Internal] add `__VALID__CHAIN__` Property to the stable resolved `Selector`
- [Internal] Append the result elements of `Playwright` `Selector` actions instead of resetting on re-resolve
- [Internal] Get the `ElementHandle` Directly in `Playwright` `Controller` instead of re-evaluating the Selector
- [Internal] Remove `filters` list from `Playwright` `Selector`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix not able to call `Selector` methods after first evaluation
- [Internal] Fix `Playwright` `Selector` not evaluating the correct elements
- [Internal] Fix `ControllerProxy` normalization of Selector was not evaluated correctly to the target `Adapter's Selector ` if a string as a Selector was passed

## [2.2.3] - 2020-10-09

### Features

- [Public] A Solid new `Selector` results that is based on evaluating the whole chain of the `Selector's` actions instead of just the first match, regardless of the used `Adapter`

### Changes

- [Public] `Selector` now evaluates the whole chain until we reach a stable result
- [Internal] Keep retrying within the timeout frame until we get at least one element in the `SelectorProxy` to stabilize the `Selector` whole chain
- [Internal] add `__VALID__CHAIN__` Property to the stable resolved `Selector`
- [Internal] Append the result elements of `Playwright` `Selector` actions instead of resetting on re-resolve
- [Internal] Get the `ElementHandle` Directly in `Playwright` `Controller` instead of re-evaluating the Selector
- [Internal] Remove `filters` list from `Playwright` `Selector`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Internal] Fix `Playwright` `Selector` not evaluating the correct elements
- [Internal] Fix `ControllerProxy` normalization of Selector was not evaluated correctly to te target `Adapter's Selector ` if a string as a Selector was passed

## [2.2.2] - 2020-10-07

### Features

### Changes

- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix `Playwright` Adapter `I.appendField` prepending instead of appending
- [Public] Fix Remove Development Logging artifacts

## [2.2.1] - 2020-10-06

### Features

### Changes

- [Internal] Assign Session to Selector from Controller if available
- [Internal] Add `AsyncContextPolyfill` helper
- [Internal] Normalize string `Selector` to `selector` function instead of `SelectorProxy` instead in `ControllerProxy`
- [Internal] Validate ElementHandle in `Playwright Selector` before checking for visibility
- [Internal] Add `filters` to `PlayWright Selector`
- [Internal] Execute previous filters in `PlayWright Selector` on re-resolving
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix resolving `Session` not working in `NodeJs` less than version 14.0.0
- [Public] Fix not able to fetch the `Session` for `Selector` if the passed init is a string
- [Public] Fix `Playwright Selector` visibilityCheck
- [Public] Fix `Playwright Controller hover` Action
- [Public] Fix waiting for load state in `Playwright Selector` to wait until the page is loaded before querying selectors

## [2.2.0] - 2020-10-05

### Features

- [Public] [Beta] `Playwright` Adapter
- [Public] `Unit Test` Adapter
- [Public] `ketm init` to initialize A `Test Maker` project
- [Public] Add `ketm generate Feature From Gherkin` to Auto create `Typescript` code file from `Gherkin` file
- [Public] Add ability to set Files and upload in one action if files are passed to `I.upload` Controller Action
- [Public] Add `I.middleClick` `Controller` Action
- [Public] Add `I.expectSelector()` for `Selector` based `Assertions`
- [Public] Add `I.expectSelector().toBeVisible` `Assertion` `Matcher`
- [Public] Add `I.expectSelector().toBeInvisible` `Assertion` `Matcher`
- [Public] Add `I.expectSelector().toExist` `Assertion` `Matcher`
- [Public] Add `I.expectSelector().toHaveCssClass` `Assertion` `Matcher`
- [Public] Warn and exist the process if no defined `Feature` keywords found in files
- [Public] Warn and exist the process if duplicate `Feature` keywords with the same name found
- [Public] Fail if `Input` based action like `I.fillField` are performed on none editable element
- [Public] Add File Log `test-maker-eye-.....` for `Test Maker Eye`
- [Public] Auto adjust parallelism amount if the specified number is bigger than files count
- [Public] Add Attachment `Phase` name in `Allure` reporter to make it easy to understand to which phase the attachment belongs to
- [Public] Add `configuration.reporting.screenshots.BeforeFeature` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.BeforeEachScenario` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.BeforeScenario` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.BeforeEachStep` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.AfterFeature` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.AfterEachScenario` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.AfterScenario` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.AfterEachStep` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.Feature` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.Scenario` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.Step` for conditional taking of screenshot in this `Phase`
- [Public] Add `configuration.reporting.screenshots.SupStep` for conditional taking of screenshot in this `Phase`

### Changes

- [Public] [Breaking] move `ketm generate` for generating project to `ketm init`
- [Public] [Breaking] Minimum supported `NodeJs` version `12.7.0`
- [Public] Dont take screenshots on `beforeAll` hook
- [Public] Dont take screenshots on `afterAll` hook
- [Public] Add `phase` property to `run.embedding`
- [Internal] Add Playwright `Adapter`
- [Internal] Add Playwright `Controller` API
- [Internal] Add Playwright `Selector` API
- [Internal] Add Playwright `ClientFunction` API
- [Internal] Add `Unit` `Adapter`
- [Internal] Add `Unit` `Adapter` `Controller` API
- [Internal] Add `Built in Runner`
- [Internal] Fully remove the dependency on any `TestCafe` code
- [Internal] Add `LiveMode KeyboardEvent Observer`
- [Internal] Add `LiveMode FileWatcher`
- [Internal] Add `LiveMode ModulesGraph`
- [Internal] Update `Feature Analyser Loader` to detect duplicate and number of `Feature` keyword used
- [Internal] Update PhaseManger to handle conditional ScreenShots taking
- [Internal] Set waitForElementToExist to start 0 as timeout
- [Internal] Set waitForElementToBeVisible to start 0 as timeout
- [Internal] Set waitForElementToBeInvisible to start 0 as timeout
- [Internal] Set waitForFrameToLoad to start 0 as timeout
- [Internal] Normalize args in ClientFunction to be compatible with all clients
- [Internal] Disable Screenshot for `Unit` Test mode
- [Internal] Move `CLI Generate` templates to `./dist/templates` to separate it from source
- [Internal] Update `CLI Generate` to generate code Files from Gherkin
- [Internal] Update `writeLogFile` to accept file prefix
- [Internal] Improve `CLS` `Session` to use node built-in `AsyncLocalStorage
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix The `Eye` not auto opening the url correctly on `Linux` OS
- [Public] Fix The `Eye` output is Piped into `Test Maker process`
- [Public] Fix not all next `Scenarios` are skipped when `configuration.runner.skipNextScenarioOnFail` is enabled
- [Public] Fix not all next `Steps` are skipped when `configuration.runner.skipNextStepOnFail` is enabled
- [Public] Fix Negated Assertion not logging "not" keyword
- [Public] Fix Specs Compiler not downgrading results when using latest EcmaScript features
- [Public] Fix normalization of file Path and removing "file:///" in Error Parser on Linux
- [Public] Fix `waitForElementToBeInvisible` not returning correct Result
- [Public] Fix `I.cut`, `I.copy`, `I.paste`not being chainable
- [Public] Fix Passing `Selector` to `Selector` as init argument
- [Public] Fix Process is freezing on complex long deep objects log
- [Public] Fix `process` is freezing on long complex objects logging
- [Internal] Fix `Selector` not resolved to correct value in `Controller Proxy`

## [2.1.0] - 2020-09-14

### Features

- [Public] New `Test Maker Eye` `Realtime` `Dashboard`
- [Public] New `Test Maker Eye` `RealTime` Dashboard module with Charts and Run status
- [Public] New `Test Maker Eye` `Configurator` Module for configuring Test Maker config file visually
- [Public] New `Test Maker Eye` `WorkSpace` Module for Browsing project files from the browser
- [Public] New `Test Maker Eye` `Specs` Module for listing Spec files and view their respective Gherkin files
- [Public] New `Test Maker Eye` `Reporter-Terminal` for viewing terminal report from the browser
- [Public] New `Test Maker Eye` `Reporter-Allure` for viewing Allure report from the browser
- [Public] New `Test Maker Eye` `Reporter-Text` for viewing text report from the browser
- [Public] New `Test Maker Eye` `Reporter-JSON` for viewing JSON report from the browser
- [Public] New `--eye` argument for `ketm` run
- [Public] New Text Reporter
- [Public] The Log file now records everything outputted to the console
- [Public] Make `Selector` methods lazy and evaluate them on demand
- [Public] Add `I.waitForElementToBeVisible` controller action to wait until the Element is Visible
- [Public] Add `I.waitForElementToBeInvisible` controller action to wait until the Element is Invisible
- [Public] Add `I.waitForElementToExist` controller action to wait until the Element Exists
- [Public] Add `I.waitForIframeToLoad` controller action to wait until the Iframe Element is Loaded
- [Public] Add `I.getCurrentUrl` controller action to get the current `Client` `URL`
- [Public] Add `I.getPageSource` controller action to get the current `Client` `Source`
- [Public] Add `I.getTitle` controller action to get the current `Client` `Title`
- [Public] Add `I.getPageScrollPosition` controller action to get the current `Client` `ScrollPosition`
- [Public] Accept string as selector in `toBeVisible` Assertion Matcher
- [Public] Add custom message option to `waitFor*` Actions
- [Public] Automatically disable `configuration.runner.runnerPerFeature ` and `configuration.runner.clientPerFeature` in `liveMode and log a warning instead of an Error
- [Public] Enable `Filtering.glob`

### Changes

- [Public] Remove `Feature`, `Scenario`, `Step` and `Sub Step` from `Selector` action logger if not found
- [Public] Remove `Feature`, `Scenario`, `Step` and `Sub Step` from `Controller` action logger if not found
- [Public] Prefix run process log file with `test-maker`
- [Public] Remove `switchToMainFrame` By Default when starting a new Phase or Step
- [Public] `Filtering` takes priority over `source` when defined
- [Public] `Log` file is prefixed with `test-maker`
- [Public] Change `waitForCondition` timeout to 3000ms
- [Public] [Breaking] Move `configuration.adapter` to ``configuration.runner.adapter`
- [Public] [Breaking] Change `I.waitForCondition` signature
- [Internal] Add `Eye` Server
- [Internal] Add `Socket ` Server and Events for `Eye`
- [Internal] Serve Static Files from `Eye` server
- [Internal] Update `taskStart` to work with `Eye` Dashboard
- [Internal] Update `taskDone` to work with `Eye` Dashboard
- [Internal] Remove `souceLabs` from `Clients`
- [Internal] Add `Dashboard` Reporter
- [Internal] Add `serializeSpecs` Helper
- [Internal] Add `treeKill` Helper
- [Internal] Add `gherkinSource` property to `BasicSpec`
- [Internal] Add `stripAnsi` property to `Logger`
- [Internal] Add `hookStdout` Helper
- [Internal] Create `Engine.state.dashboar` property
- [Internal] Split `eye` bundle in Webpack
- [Internal] Add new Actions to `COntrollerProxy`
- [Internal] Add `hasAnsi ` helper
- [Internal] Add `AppLogger ` To intercept `STDOUT`
- [Internal] Add `textReporter ` To `Terminal` Reporter
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix `CLI` args was missing from test function runnerInfo
- [Public] Fix Double logging of `Allure` report server start.
- [Public] Fix double `Log` File written
- [Public] Fix `Selector` was not normalized in `I.checkOption` `ControllerProxy` action
- [Public] Fix `TestCafe` `scrollPageTo` action was executed incorrectly

## [2.0.2] - 2020-09-02

### Features

### Changes

- [Internal] get a unique set of `engine.state.runner.featuresToRun`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix `Finished {N} of {N} Defiend Features` count in `Terminal` reporter
- [Public] Fix `definedFeaturesCount` is wrong when file is commented
- [Internal] Fix TC runner not throwing error if not awaited

## [2.0.1] - 2020-09-02

### Features

### Changes

- [Public] rounding numbers in percentage in`Terminal` Reporter
- [Internal] Removed definedFeaturesCount from `SpecFn`
- [Internal] Update `InfoBar` in ControllerProxy `goto` action
- [Internal] Remove `Engine.state.runner.totalRuns`
- [Internal] Remove `Engine.state.runner.featuresToRun`
- [Internal] Add `Engine.state.runner.pendingRuns`
- [Internal] Add `Engine.state.runner.batches`
- [Internal] Parse `Feature` keywords in `Feature-Analyzer-Loader` and store them
- [Internal] Add `getFunctionParams` helper
- [Internal] Add `RunnerInfo.id`
- [Internal] Add `RunnerInfo.didRunCount`
- [Internal] Add `RunnerInfo.clientsCount`
- [Internal] Remove `RunnerInfo.pendingRuns`
- [Internal] Wait correctly for batches in `parrallel` mode
- [Internal] Use `TC` reporter `startTask` to init `runnerInfo` values
- [Internal] Don't reset `Engine.state.runner.pendingRuns` on cleanup
- [Internal] Don't reset `Engine.state.runner.toResolve` on cleanup
- [Internal] Remove calling `taskStart` from `FeatureFn`
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix `process` should exist on uncaught errors`
- [Public] Fix Log file not written on `process.exit`
- [Public] Fix plugins not imported in `Engine`
- [Public] Fix `InfoBar` was not displaying current running step after `I.goto`
- [Public] Fix `definedFeaturesCount` in `parallel` mode
- [Internal] Fix Batch is not resolved when stopping the runner manually

## [2.0.0-beta] - 2020-08-31

### Features

- [Public] 50%-70% Improve in speed of `CLI` startup, i.e `ketm run` starts in `3s` compared to `10s` before, `ketm generate` start in `2.5s`  compared to `5` seconds before
- [Public] Full Debugging experience in IDE like VS Code, WebStorm, IntelliJ Idea or any other IDE
- [Public] Allow to pass a static port when using `--inspect` in `ketm run`
- [Public] Log unknown and internal Test-Maker errors to a File to help to investigate and solving bugs Faster
- [Public] Log `Node` Generic Errors
- [Public] Run`ketm run` without providing config file ( will run with default conventions)
- [Public] Add `timeout` API method to `Feature` to set the max timeout before failing
- [Public] Improved Page Load Performance by `20-30`%
- [Public] Stop `Runner` on `Feature` timeout
- [Public] Add `configuration.runner.disableMultipleWindows` to disable multi window support
- [Public] Add `configuration.build.cleanUp.tests` to control wither to delete the `dist/tests` folder or not
- [Public] Add `configuration.build.cleanUp.reports` to control wither to delete the `dist/reports` folder or not
- [Public] Add `configuration.runner.disableMultipleWindows` Error when enabled while using multi window
- [Public] Add `configuration.runner.featureTimeout` to set globally the max timeout before `Feature` is considered failed
- [Public] Add `configuration.runner.runnerPerFeature` to spin a `Runner` per `Feature`
- [Public] Add `configuration.runner.clientPerFeature` to spin a `Runner` per `Client` per `Feature`
- [Public] Show total number of finished `Features` after each `Features` is finished in `Terminal` reporter
- [Public] Add `engine.instance.defendFeaturesCount` property
- [Public] Add `Adapter.type` property to accept "web" | "desktop" | "mobile"
- [Public] Skip the next `Scenario` if previous one fails using(`configuration.runner.skipNextScenarioOnFail`)
- [Public] Skip the next `Step` if previous one fails using(`configuration.runner.skipNextStepOnFail`)
- [Public] Skip remaining `Controller` and `Selector` actions from executing on feature timeout
- [Public] Add `toBeVisible()` element visibility assertion matcher
- [Public] Add `--disable-infobars` `Chromium` based clients shared args
- [Public] Improve Performance by Caching the Page resources
- [Public] Add `Weeks, Days, Hours, Minutes, Seconds, Millisecons` to `Terminal` reporter Task Duration
- [Public] Add `Stack Trace` to `Allure` Reporter
- [Public] Add `Stack Trace` to `Cucumber` Reporter
- [Public] Add `Stack Trace` to `AssertThat` Reporter
- [Public] Add `Stack Trace` to `JSON` Reporter
- [Public] add `Feature`, `Scenarion`, `Step` and `SubStep` to `Controller` action log
- [Public] add `Feature`, `Scenarion`, `Step` and `SubStep` to `Selector` action log
- [Public] Add `merge` and `mergeAndConcat` utility to merge objects and config
- [Public] Add `I.cut` `Controller` Action
- [Public] Add `I.copy` `Controller` Action
- [Public] Add `I.paste` `Controller` Action
- [Public] Add `I.select` `Controller` Action
- [Public] Add `I.focus` `Controller` Action
- [Public] [Beta] `I.switchToParentWindow()` `Controller` Action
- [Public] [Beta] `I.switchToPreviousWindow()` `Controller` Action
- [Public] `I.goForward()` `Controller` Action
- [Public] `I.goBack()` `Controller` Action
- [Public] `I.go()` `Controller` Action

### Changes

- [Public] [Breaking] move `configuration.liveMode` to `configuration.runner.liveMode`
- [Public] [Breaking] move `configuration.headless` to `configuration.runner.headless`
- [Public] [Breaking] move `configuration.parallel` to `configuration.runner.parallel`
- [Public] [Breaking] move `configuration.adapter` to `configuration.runner.adapter`
- [Public] [Breaking] move `configuration.clients` to `configuration.runner.clients`
- [Public] `configuration.build.compiler.typescript.typeCheck` is set to be false by default now so that it wont slow compilation if not needed
- [Public] `configuration.runner.disablePageCaching` is now disabled by default
- [Public] Add `adapterType` to `Adapter`
- [Public] Update `ketm generate `template-example-spec` template
- [Public] Update `ketm generate `template-feature` template
- [Public] Update `ketm generate `template-test-machine.ci` template
- [Public] Update `ketm generate `template-test-machine.local` template
- [Internal] Add `session.startTime` property
- [Internal] Add `session.endTime` property
- [Internal] Add `session.timeout` property
- [Internal] Add `session.canceled` property
- [Internal] Change `Runner` logic to accept only one `Adapter`
- [Internal] Update `Cucumber` Report creator to accept option to allow `HTML` in error
- [Internal] Remove `asyncAction` re-write from `features-analyzer-loader`
- [Internal] Add `switchToMainFrame` in `commonBeforeHook`
- [Internal] Remove `AsyncAction`
- [Internal] update `ClI` to use the new version
- [Internal] Cancel Phase promise on timeout
- [Internal] Stopped using `testcafe` reporter methods and move logic to `Runner`
- [Internal] Change `Runner` logic to allow multi `Runners`
- [Internal] Cleanup `taskStart` and `taskDone` logic in `Engine`
- [Internal] Conditionally injecting client scripts
- [Internal] Add `copyPasteManger` client script
- [Internal] Develop `Babel` plugin to re-write `await` calls in spec files to catch stack trace
- [Internal] Update `ErrorParser` to find Spec File source with the new `Babel` plugin
- [Internal] Guard against opening debugger twice when `--inspect` is passed manually
- [Internal] Lazy Import resources in `Engine` to improve `CLI` speed
- [Internal] Change resources import paths dynamically based on `Production` vs `Development` env
- [Internal] Convert Methods to `async` in `Engine
- [Internal] Handle uncaught `Promise` errors and errors
- [Internal] Add global Logger helper
- [Internal] Add `globalTestMakerLoggerName` constant
- [Internal] Add `chunkArray` helper
- [Internal] Add `getCodeFrame` helper
- [Internal] Add `hrTimeFormat` helper
- [Internal] Add `delayedPromise` helper
- [Internal] Add `createGenericLog` helper
- [Internal] Add `findLinkedModules` helper
- [Internal] Add `resolveLinkedModule` helper
- [Internal] Add `FeatureTimeOutError` Error Type
- [Internal] Redirect General Errors log to `Logger`
- [Internal] Log `unhandledRejection` to Log file
- [Internal] Log `uncaughtException` to Log file
- [Internal] Improve `Async Context`
- [Internal] Use custom `webpack` hook to delete ist folder instead of `clean` `webpack` plugin
- [Internal] Get Number of defined Features
- [Internal] Update Deps
- [Internal] Update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix Attempt to fix `EPERM: operation not permitted, mkdir` error when re-running `ketm` on some Machines
- [Public] Fix `ketm run` throwing error when not providing config file argument
- [Public] Fix `ketm generate` throwing error when providing custom generated `feature` name
- [Public] Fix `CallSite Manager` error on parsing standard errors
- [Public] Fix `Terminal` reporter is showing wrong skipped `Features` percentage
- [Public] Fix `axe-core` Needed to be installed separately
- [Public] Fix Error Stack Trace not added to `DetailedError` Object
- [Public] Fix `Allure` Reporter server not opening on local host
- [Public] Fix `Undefiend` Phase in `Selector` action Logger
- [Public] Fix `Undefiend Message` Error due to failing updating Test Info Bar in the browser
- [Public] Fix wrong Error source location
- [Public] Fix `filePath` missing in `runnerInfo` in `featureDone`, `scenarioDone` `stepDone` `substepDone` Reporting events
- [Internal] Fix `Error Parser` trying to get `SpecError` for wrong locations
- [Internal] Fix double executing reporter's `TsskDone`
- [Internal] Fix Get Stack trace from `CallSiteRecord` in `ErrorParser`
- [Internal] Fix `ClientFunction` Api Error not added causing `Undefined Message`

## [1.7.2-beta] - 2020-07-09

### Features

### Changes

- [Internal] Update `Cucumber` Report creator to accept option to allow `HTML` in error

### Fixes

- [Public] Fix `AssertThat` report showing Raw HTML in Jira

## [1.7.1-beta] - 2020-07-08

### Features

### Changes

- [Internal] Update `TS Checker` config

### Fixes

- [Public] Fix `Typescript Checker` throwing Error

## [1.7.0-beta] - 2020-07-07

### Features

- [Public] [Beta] Add multi windows support (Not in live mode)
- [Public] [Beta] `I.openWindow()`
- [Public] [Beta] `I.closeWindow()`
- [Public] [Beta] `I.getCurrentWindow()`
- [Public] [Beta] `I.switchToWindow()`
- [Public] Add `JSON` reporter
- [Public] Add`beforeAll` hook to execute code before starting of all tests
- [Public] Add`afterAll` hook to execute code after ending of all tests
- [Public] Ability to make HTTP Requests with `Controller`
- [Public] Add `I.sendGetRequest` to make `HTTP GET` request
- [Public] Add `I.sendPostRequest` to make `HTTP POST` request
- [Public] Add `I.sendPutRequest` to make `HTTP PUT` request
- [Public] Add `I.sendPatchRequest` to make `HTTP PATCH` request
- [Public] Add `I.sendHeadRequest` to make `HTTP HEAD` request
- [Public] Add `I.injectCss` to inject `css` code or css file and executed in the browser
- [Public] Add `I.injectJs` to inject `js` code or css file and executed in the browser
- [Public] Add `I.triggerClientEvent` to trigger realtime Socket Event on the client
- [Public] Add `I.handleClientEvent` to handle realtime Socket Event on the client
- [Public] Add `I.triggerServerEvent` to trigger realtime Socket Event on the client
- [Public] Add `I.handleServerEvent` to handle realtime Socket Event on the client
- [Public] Add `I.waitForCondition` To wait until a condition is true
- [Public] Add `I.getClientLogs` to getClientLogs history
- [Public] Add `I.getCookie` to get `cookie` value
- [Public] Add `I.getLocalStorage` to get `localstorage`
- [Public] Add `I.setLocalStorage` to set `localstorage`
- [Public] Add `I.removeLocalStorage` to delete `localstorage`
- [Public] Add `I.getSessionStorage` to get `localstorage`
- [Public] Add `I.setSessionStorage` to set `localstorage`
- [Public] Add `I.removeSessionStorage` to delete `localstorage`
- [Public] Add `I.expect` Assertion to controller
- [Public] Add `Selector` action name to `Error.type`
- [Public] Add `Controller` action name to `Error.type`
- [Public] Add `compileToString` on the fly compiler

### Changes

- [Public] show only `retry once` if no retries count passed to retry method
- [Internal] Add `compileOnTheFly` for in memory scripts compilation
- [Internal] Load `axecore.min` for `Axe-core`
- [Internal] Add ability to pass filter function to `CallSiteManager.createRecord`
- [Internal] More ignore Filters `CallSiteManager.createRecord`
- [Internal] Add  `--disable-setuid-sandbox`,`--disable-accelerated-2d-canvas`,`--no-zygote`,`--disable-gpu` to `chromiumSharedArgs`
- [Internal] Add `Babel` loader for client scripts
- [Internal] Add `client-test-maker` object `client script`
- [Internal] Add `IE11 polyfills` `client script`
- [Internal] Add `eventManager` `client script`
- [Internal] Add `client-socket` `client script`
- [Internal] Add `nonePromise` option to `ControllerProxy` action decorator
- [Internal] Add `clientInjector` to `ControllerProxy`
- [Internal] Add `HTTP Client` to `ControllerProxy`
- [Internal] Add `Multi Windows` support to `TestCafe` adapter
- [Internal] Use `adapter` property as string in `Cucumber` reporter
- [Internal] Use `allure` property as string in `Cucumber` reporter
- [Internal] Add `message` title to `allure` reporter
- [Internal] Add `filterFn` to `ErrorParser`
- [Internal] Add `ClientSocket` to `Engine`
- [Internal] Handle `beforeAll` hook start and errors on `Engine`
- [Internal] Add `beforeAll` error to first `Feature`
- [Internal] Handle `afterAll` hook start and errors on `Engine`
- [Internal] Add `afterAll` error to last `Feature`
- [Internal] Add `errorSerializer` helper function
- [Internal] Add `logDetailedError` helper function
- [Internal] Add `parseFunction` helper function
- [Internal] Add `renderCodeFrame` helper function
- [Internal] Add `uid` Property to `Session` object
- [Internal] Add `socket` Property to `Session` object
- [Internal] Add `socketEvents` Property to `Session` object
- [Internal] Update filtering of asyncAction in `features-analyzer-loader`
- [Internal] Change `globalTestMachineName` from `__TEST_MACHINE__` to `__TEST_MAKER__`
- [Internal] Compile `Test Maker Config` file to a temp folder
- [Internal] Update Deps
- [Internal] update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix `ansi` code frame source escaping of html entities
- [Public] Fix `inspect` not connecting to debuggers
- [Public] Fix `CLientFunction` not showing correct Error Details
- [Public] Fix double quotes in reporter
- [Public] Fix Error details not pointing to correct line and column if originating from `Test Maker Config` file
- [Public] `Controller Action` not showing correct Error Details if it returns a value

## [1.6.0-beta] - 2020-06-08

### Features

- [Public] [Alpha] `Windows` Desktop Testing using `FlaUI`
- [Public] Add `FlaUI` `Server`
- [Public] Add `FlaUI` `Adapter`
- [Public] Add `FlaUI` `Selector`
- [Public] Add `FlaUI` `Controller`
- [Public] Beautiful `Test Maker` Banner when `CLI` Starts
- [Public] Ability to pass port for `inspect`
- [Public] Add `launchApp` action to `Controller`
- [Public] Add `switchApp` action to `Controller`
- [Public] Add `closeApp` action to `Controller`
- [Public] Add `Node` version to `Terminal` Error Log
- [Public] Add `Node` version to `Allure` Error Log
- [Public] Add `Node` version to `Cucumber` Error Log
- [Public] Add `Node` version to `Assert That` Error Log
- [Public] Add Colors to `Terminal` reporter statistics
- [Public] Add percentage to `Terminal` reporter statistics

### Changes

- [Public] Remove `inspect-brk` from `Cli` `run` options
- [Internal] Update Cli to parse `inspect-brk`
- [Internal] Update Deps
- [Internal] update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Public] Fix `getSession` file path url on linux
- [Public] Fix `Appium Server` Shutdown
- [Public] Fix `TestCafe` Version comparability with `PEGA` 8.4
- [Public] Fix empty `Error Type` for `Selector` action
- [Public] Fix empty `Error Type` for `Controller` action

## [1.5.1-beta] - 2020-05-26

### Features

### Changes

- [Internal] Use `testCafe erroMSG` if it exists

### Fixes

- [Public] Add missing `socket.io-client` dependency
- [Internal] Fix file path in `getSession`
- [Internal] Fix `Error.message` in `SelectorProxy`

## [1.5.0-beta] - 2020-05-26

### Features

- [Beta] Native Mobile Application Testing for `IOS` and `Android`
- [Beta] `Appium` Adapter
- [Beta] `Code Obfusication` to protect `Test Maker` source code
- Chrome Dev Tools Live Debugging
- Measure `Controller Action` time
- Measure `Selector Action` time
- Add `current Phase` to `Controller Action` Log
- Add `current Phase` to `Selector Action` Log
- Throw an Error if `Controller Action` Does not exist
- Throw an Error if `Selector Action` Does not exist
- `handleAlertDialog` `Controller Action`
- `handleConfirmDialog` `Controller Action`
- `handlePromptDialog` `Controller Action`
- Add `Error Code` to `Terminal` reporter
- Add `Error Code` to `Cucumber` reporter
- Add `Error Code` to `Allure` reporter
- Add `Error Code` to `AssertThat` reporter

### Changes

- [Internal] Add `WebDriverIO`
- [Internal] Add `Appium` Adapter
- [Internal] Add `Appium` Controller
- [Internal] Add `Appium` Selector
- [Internal] Add `Appium` Reporter
- [Internal] Execute `Selector Action` resolved value if it is a method
- [Internal] Execute `Action Action` resolved value if it is a method
- [Internal] Add `--indpect-brk` to `CLI`
- [Internal] Auto Run `Node Inspector`
- [Internal] Auto Open `Chrome Dev Tools` for debugging
- [Internal] Add `--no-sandbo` to `Chromium` browser `sharedArgs`
- [Internal] New `CallSite Record` Manager
- [Internal] New `CodeFrame` Manager
- [Internal] New `CodeFrame` Highlighter
- [Internal] New `CodeFrame` Multi languages `Highlighter`
- [Internal] New `HTMML` `Error` and `CodeFrame` renderer
- [Internal] New `ANSI` `Error` and `CodeFrame` renderer
- [Internal] New `No Color` `Error` and `CodeFrame` renderer
- [Internal] Rename `ClientFunction` to `clientFunction`
- [Internal] Add `fileFullPath` to `SpecFileInfo`
- [Internal] Add `fileName` to `CallSite Record`
- [Internal] Add `filePath` to `CallSite Record`
- [Internal] Add `fileFullPath` to `CallSite Record`
- [Internal] Add `stack` to `CallSite Record`
- [Internal] Update `ErrorParser` to use the new `CallSite Record`
- [Internal] Update `ErrorParser` to use the new `CodeFrame`
- [Internal] Update `ErrorParser` to use the new `CodeFrame Renderer`
- [Internal] use global to get `AsyncAction` in `Feature Analyzer Loader`
- [Internal] Add `native Require`
- [Internal] Use absolute path with `file:/` prefix in compiler `source maps` to be recognized by external debuggers
- [Internal] Add `JavaScriptObfuscator` to `Webback` for obfuscating the source code
- [Internal] Update Deps
- [Internal] update interfaces
- [Internal] code refactoring
- [Internal] code cleanup

### Fixes

- [Internal] Strip `file//` from `callsite` `Frame` `FilePath`
- Fix Error `Source File Path`
- Fix Error `lineNumber`
- Fix Error `columnNumber`
- Fix `Cucumber` reporter `Error` color and styling in the browser
- Fix `Allure` reporter `Error` color and styling in the browser
- Fix `AssertThat` reporter `Error` color and styling in the browser
- Fix `Adapter` options not passed correctly to the `Engine`

## [1.2.4-beta] - 2020-05-12

### Features

- [Experimental] Add `Studio` Socket Connection
- [Experimental] Add `Studio` `Terminal` Reporting
- [Experimental] Add `Studio` `Allure` Reporting
- [Experimental] Add `Studio` `Controller` Actions Reporting
- [Experimental] Add `Studio` `CLI` run command parameter

### Changes

- [Internal] `optional` skip Controller action log
- [Internal] Fix `test maker` config path resolving in compiler
- Update `KETM generate` spec file template
- Update configuration paths to use `build.path` as base
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.2.3-beta] - 2020-05-08

### Features

### Changes

- Update to latest `Testcafe`
- Serialize `Configuration` when passed to `runInfo` to avoid modification of its values by the user
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix `CLI` `--extra` option not keeping string case
- Fix `CLI Generatrs` specs path

## [1.2.2-beta] - 2020-05-04

### Features

### Changes

- Update CLI version

### Fixes

## [1.2.1-beta] - 2020-05-04

### Features

### Changes

### Fixes

- Fix missing `cli.js`

## [1.2.0-beta] - 2020-05-04

### Features

- `ketm generate` with the following generators:
    - `init express` initialize whole project with one command
    - `init custom` initialize whole project with one command while choosing what to generate
    - `feature` interactively generate a feature spec file
- OS `notification` on process done, with a message of success or failures
- `Allure` reporter auto open report in browser option
- `Allure` reporter show Spec file Error source and File name
- `Table` view in `Terminal` reporter with the following details
    - `Feature` name
    - `Feature` file path
    - `Feature` status
    - Passed, Failed, Skipped and undefined `Scenarios` count
    - Passed, Failed, Skipped and undefined `Steps` count
- Log `Controller` action and its arguments
- Log `Selector` action and its arguments
- Add `projectName` property to `Configuration`
- Show the column number for Spec Error Source in the log
- `Extra` config property, to define custom configuration like env, credentials, etc...
- `--extra` `KETM` CLI argument to override the config `extra` properties values
- Add `ctx` to `Controller` for shared context in all steps and hooks
- `runInfo` argument passed to all steps, and hooks methods with the following details:
    - `configuration` the configuration file used
    - `cliArgs` the arguments passed to `KETM` CLI
- `retry` function with ability to define:
    - number of retried
    - timeout
    - interval
    - message
    - condition
- Async `expect`, auto resolve actual value if promise
- `expect` Custom error message
- `expect` retry options:
    - number of retried
    - timeout
    - interval
    - message
    - condition

### Changes

- `cli.js` is a separate file now
- Add `open` option to `Allure` reporter
- Add a static server for `Allure` report
- Add `generate` CLI command
- Add files templates for `generate` CLI command
- Add `--extra` CLI argument to `run` CLI command
- Run the process as separate Process
- Add `runInfo` to all stpes and hooks methods
- Add `propertyAccessor` to dynamically get/set object properties
- Create `Controller` Proxy to delegate actions to adapters
- Create `Selector` Proxy to delegate actions to adapters
- Change `appRoot` to `projectRoot`
- Correct sourcemap paths in features compiler
- Coerce ClI arguments to real data type
- Add `filePath` property to all Specs
- Add `reset` method to all Specs
- Add `AsyncContext` to correctly resolve `Session`
- Create custom Stack Trace for `ClientFunction`
- Convert `expect` methods to Async
- Auto Resolve `expect` actual values
- Auto Retry `expect` methods
- Update to latest `Testcafe`
- Serialize `Configuration` when passed to `runInfo` to avoid modification of its values by the user
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix Session not resolved for `Selector` and `Controller` when nest `Page Model` calls are made
- Fix `Configuration` typescript interface
- Fix cloning Specs
- Fix `COnfiguration` hooks not resolving `Session`
- Fix correct `lineNumber` for `asyncAction` in `feature-analyzer-loader`
- Fix `TestCafe` Adapter parallel value not set correctly

## [1.1.23-beta] - 2020-04-15

### Features

### Changes

- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix stack files paths On Linux for `error-parser`

## [1.1.22-beta] - 2020-04-15

### Features

### Changes

- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix path for `error-parser` on jenkins

## [1.1.21-beta] - 2020-04-15

### Features

### Changes

- Add extra log in `error-parser`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.20-beta] - 2020-04-14

### Features

- On `Fail` exist the process with code other than 0 to trigger that we Failed. useful for CI like (Jenkins)

### Changes

- Added `status` property to `Engine`
- [Breaking] Renamed `Profile` to `Client`
- [Breaking] Renamed `standard` reporter to `terminal`
- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix `Allure Reporter` folder path error

## [1.1.19-beta] - 2020-04-10

### Features

- `ketm` `--filter-feature` to filter multiple `Features`
- `ketm` `--filter-scenario` to filter multiple `Scenarios`
- `ketm` `--filter-step` to filter multiple `Steps`
- `ketm` `--suites` takes multiple suites
- Detect and warn the developer about Duplicate `Features`
- Auto resolve files upload paths

### Changes

- Update `Specs` parser to detect Duplicates
- Update `FeatureFN`  to detect Duplicates
- Update Controller to auto resolve files
- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- `Features` not skipped correctly
- `Scenarios` not skipped correctly
- `Steps` not skipped correctly

## [1.1.18-beta] - 2020-04-09

### Features

### Changes

- Update `getSession` to get `Session` more accuratly
- Update `Controller` actions execution logic
- Update resolve `Controller` error message
- Update resolve `Selector` error message
- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix `Step` choking on `Controller` or `Selector` calls

## [1.1.17-beta] - 2020-04-07

### Features

### Changes

- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix `Selector` choking on merging options

## [1.1.16-beta] - 2020-04-07

### Features

- `I.goto()` throws an error if the `url` is empty

### Changes

- Update `Controller` `goto` action to throw error on empty `url`
- Update `Feature` to navigate to Page when it starts
- Update `Scenario` to navigate to Page when it starts
- Update `Step` to navigate to Page when it starts
- Relax the rules for `tsCompilerOptions` in `Compiler`
- Exclude `I` and `Selector` from `feature-analyzer-loader` transformation
- Enable Update `info Bar` with current test step
- Improve `Controller` `error stack`
- Improve `selector` `error` formatting
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.15-beta] - 2020-04-06

### Features

- Show Spec file name and original line of error for both `Selector`
- Show Spec file name and original line of error for both `Controller`

### Changes

- Move away from `async_hooks` to custom stack capture. the requirement for showing spec file original error details requires extra effort, this is due to the nature of `async` stack in `nodejs
  `. one way to make it work, is using `async_hooks`, but this degrades performance by an order of magnitude. the other way, is to try to capture the stack before it being switched by `v8` engine.
- Update `Specs Compiler` `Typescript` config to target `ES2018`
- Update `feature-analyzer-loader` to transform `await` calls to capture `stack trace` correctly
- Update `Controller` to capture `Spec` `stack trace`
- Update `Selector` to capture `Spec` `stack trace`
- Add `api` property to `Controller` & `Selector` errors
- Add `spec` property to `Controller` & `Selector` errors
- Update `error parser` to parse `Controller` & `Selector` errors
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- `Selector` `hasClass` not returning correct value
- `Selector` `hasAttribute` not returning correct value

## [1.1.14-beta] - 2020-04-02

### Features

### Changes

- Update `nanoid` typing
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- `Selector` `hasClass` not returning correct value
- `Selector` `hasAttribute` not returning correct value

## [1.1.13-beta] - 2020-04-01

### Features

- A more enhanced Error reporting, by showing developer the `Spec` file name and line of error in the `Spec` file in addition to the already detailed Error. this allows the developer to navigate
  quickly to both the original source of error and the `Spec` file itself.
- `Selector` can now be defined outside the `Spec` file. this allows for greater code abstraction, especially in `Page Model`
- `Controller` can now be Used openly outside the `Spec` file. this allows for greater code abstraction, especially in `Page Model`

### Changes

- Selector can be resolved without calling it as a function. example:
  before

```js
const html = await (Selector("input")).outerHTML;
```

after

```js
const html = await Selector("input").outerHTML;
```

- Add `sourcePath` property to `DetailedError`
- Add `distPath` property to `DetailedError`
- Add `spec` property to `DetailedError` to get info about the `Spec` file itself
- Use `async_hooks` to capture Error context to get original `Spec` file
- Update `Standard` reporter to use `DetailedError`'s `spec` property
- Add `BaseError`
- Add `Selector` proxy
- Update `ControllerAction` to resolve proxy `Selector`
- Enhance `Error` capture for `Selector`
- Enhance `Error` capture for `Controller`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.12-beta] - 2020-03-22

### Features

### Changes

- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.11-beta] - 2020-03-22

### Features

- Add options to `Allure` reporter
- Add `options.open` to `Allure` reporter to auto open the reporter in browser
- `standard` reporter now shows extra result info:
  `Task Stauts`
  `Total Features`
  `Passed Features`
  `Failed Features`
  `Skipped Features`

### Changes

- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.10-beta] - 2020-03-20

### Features

- Integration with [Axe](https://www.deque.com/axe) for accessibility check

### Changes

- Added `axeCheck` function to check accessibility errors with Axe
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.9-beta] - 2020-03-19

### Features

- Use `tsconfig.json` for `typescript`'s type checking rules

### Changes

- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- `String` values were unnecessarily quoted

## [1.1.8-beta] - 2020-03-17

### Features

- Accepts `string | number` in controller actions `fillField`m `appendField`, `selectOption`, `deselectOption`
- `Typescript` analyses and type checking
- Exit the process on Compilation errors (optional and true by default)
- Exit the process on Compilation warnings (optional and false by default)
- Added new `configuration.build.compiler.failOnError` option
- Added new `configuration.build.compiler.failOnWarning` option
- Added new `configuration.build.compiler.typescript` option
- Added new `configuration.build.compiler.typescript.typeCheck` option

### Changes

- Added `fork-ts-checker-webpack-plugin` `webpack` plugin
- Update `testcafe` controller actions to accept `number | string`
- Update the compiler to do analyses and type checking
- Update the compiler to do exist on warnings or errors
- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.7-beta] - 2020-03-17

### Features

### Changes

- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix selector not accepting function methods

## [1.1.6-beta] - 2020-03-17

### Features

### Changes

- Update `hover` action
- Move source-map support to `feature-analyzer-loader`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.5-beta] - 2020-03-13

### Features

### Changes

### Fixes

- Fix jenkins not accepting params in `ketm`

## [1.1.4-beta] - 2020-03-13

### Features

### Changes

- Remove `source-map-support/register` from `ketm` file
- Inject `source-map-support/register` to test files

### Fixes

## [1.1.3-beta] - 2020-03-12

### Features

### Changes

- Update `Controller` `actions` to expect selector types
- Add type-script declaration file
- Rename `cli` to `ketm`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [1.1.2-beta] - 2020-03-11

### Features

### Changes

- Update `feature-analyzer-loader` to include `distPath` to be used in session allocation
- Update `getSession` to use `distPath`
- Add `type` property to `BaseSpec`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix `instanceof` in phase manager
- Fix Finding `session`
- Fix `Selector` not resolved in `Session`

## [1.1.1-beta] - 2020-03-10

### Features

### Changes

- AssertThat auto upload disabled by default
- Config file options override CLI options
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix taking screenshots when option is set to disabled
- Fix parsing Plugins Options
- Fix assert that plugin options
- Fix `TestCafe` `ClientFunction` not being `bound` to current controller

## [1.1.0-beta] - 2020-03-09

### Features

- New `Human-readable` `Controller` `API` with more than 45 built in `actions`, which simplifies understanding the `actions` much better. the new `API` can be implemented by any `adapter` easily. an
  example of the ew `API`:
  instead of:

```js
await typeText("selector", " text to type")
``` 

we can now use

```js
await I.fillField("selector", " text to type")
``` 

- Added new `actions` to the `controller` like: `getCookie`, `setCookie`, `clearCookie`, `refreshPage`, `pressTabKey`, `goto`, etc...
- New `BDD` beautiful, chainable concise `Assertion` `API` with `25` built in assertions and detailed fail log feedback that shows:
    * Assertion Method
    * Assertion expected value
    * Assertion received value
    * Assertion diff value
    * Assertion error location in code
- New `Unlimited` `Sub Steps` which can be used inside `Gherkin` steps. `Sub steps` can be nested infinitely. this allows for better reporting. an example:

```js
        await step(`A`, async (I) => {
    await I.fillField(`input`, `some text`);

    await step(`B`, async (I) => {
        await I.scrollPageToBottom();

        await step(`C`, async (I) => {
            await I.click(`button`);
        })
    })
})
```

- New `Retry` ability for `Feature`, `Scenario` and `Step`. with this new feature, the developer can specify how many times the step should be retried until it succeeds. this aid greatly in
  decreasing `Flaky Tests`. the example below will run the `Scenario` 3 times until it succeeds, but if the scenario succeeds on the second retry, we will skip the 3rd retry as it is considered
  passed. this will save time!

```js
Feature(`feature A`)
    .page(`google.com`)
    .Scenario(`Scenario B`)
    .retry(3)
    .Given(`Submitted value is 3`, async (I) => {
        expect({actual: count}).toEqual(3);
    })
```  

- Added `--reporters` `CLI` `parameter` to pass reporters to be used. example:

```bash
npx ketm run --reporters allure,standard
```

- `CLI` `--filter-feature` is active now. the developer can use it multiple times to filter more than one `feature`. assuming we have 10 `Features` the example below will only run `Feature A`
  and `Feature B`

```bash
npx ketm run --filter-feature "Feature A" --filter-feature "Feature B" 
```

- `CLI` `--filter-scenario` is active now. the developer can use it multiple times to filter more than one `Scenario`
- `CLI` `--filter-step` is active now. the developer can use it multiple times to filter more than one `Step`
- `Allure` reporter now has `Error` attachment per `step` or `testcase` step. this is useful, especially in the case of multi browsers or hooks errors. as opposed to showing single error large message
  at the top
- `Allure` reporter now shows unlimited nested steps with screenshots, error attachments and duration.

### Changes

- `Feature Analyzer Loader` now creates `analyzerInfo` object with `path`, `isLast` and `isOnly` properties and pass it as the last parameter to the Fluent `API`
- New `Assertion` `Error` class
- Abstracted most of `Gherkin` functions to `BaseFn`
- Rename some hooks
- Remove `Ansi` colors from error when used in reporters other than standard
- Added `SubStepSpec`
- Added `subSteps` property to `StepSpec`
- Added `retries` property to `BaseSpec`
- Added `retries` property to `Result.run`
- Added `Sub Step` tracker to detect parent `Sub Step`
- Added `Diff` mechanism with coloring
- Added `compare` mechanism for many values types
- Added `Assert That` report creator
- Added new properties to `Session`
- Updated `Gherkin` `API` to use the `Feature Analyzer Loader` `analyzerInfo` parameter
- Updated `Test Status` values
- Updated `Test Phases` values
- Updated `Allure` reporter to use `Sub Steps`
- Updated `Cucumber` reporter to use `Sub Steps`
- Updated `Standard` reporter to use `Sub Steps`
- optimized run of `Phase Manager`
- optimized run of `Feature` with reties
- optimized run of `Scenario` with reties
- optimized run of `Step` with reties
- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix `global` `Engine` not being initialized correctly
- Fix `skipped` `Feature` still running despite being skipped
- Fix `skipped` `Scenario` still running despite being skipped
- Fix `skipped` `Step` still running despite being skipped
- Fix capture `path`
- Fix `Session` not resolving API
- Fix `Engine` state not reseting on subsequent runs
- Fix `Array` option coercing in `CLI`
- Fix `startTime` and `endTime` in specs

## [1.0.1-beta] - 2020-02-10

### Features

### Changes

### Fixes

- `features-analyzer-loader.js` was not included in release

## [1.0.0-beta] - 2020-02-10

### Features

- New `Adapter` architecture. with this new architecture, we are not restricted to testcafe anymore! this allows us to implement other frameworks like `puppeteer
  `, `webdriver-io` as drivers for browsers. we will keep supporting `testcafe` and it is the default `Adapter` in the framework, but with this new architecture, we have more options.
- New `Profile` architecture. with this new architecture, we abstract the profiles used to allow `Adapters` to have their own implementation of the `profile`. We included common profiles in the
  framework. but the developer can add his own. an example of a `profile` :

 ```js
const chromeProfile: Profile = {
    name: `chrome`,
    headless: false,
    args: [],
    options: {},
    profiles: []
};

``` 

- New `Plugin` Architecture. with this new architecture developers can extend the framework with many extensibility end points to cater to their requirements. below is `Plugin` interface:

```js
interface
Plugin
{
    name: string;
    version: string;
    description: string;

    init({serverPort: configuration}
:
    Configuration, options ? : TestMakerPluginOptions
):
    Promise < void >;
    onStart ? (engine:Engine) : Promise < void >;
    onRestart ? (engine:Engine) : Promise < void >;
    onStop ? (engine:Engine) : Promise < void >;
    onTaskStart ? (engine:Engine) : Promise < void >;
    onTaskDone ? (engine:Engine) : Promise < void >;
}
```

- With the new architecture, developer can pass options to `Adapters`, `Reporters`,`Profiles` and `Plugins`
- New Simpler `config` format with more control over the behaviour of the framework. developer just has to have a file with default export. an example of the new config:

```js
export default {
    source: [`./src/specs/**/*-spec.ts`],
    profiles: [clients.chrome],
    headless: true,
    liveMode: true,
    reporting: {
        reporters: [reporters.terminal, reporters.cucumber, reporters.allure]
    }
}
as
Configuration;
```

but the best part is that `Test-Machine` operates by the principle of `convention over configuration, which means that the above configuration is not necessary. we already initialize the default
config for you.

- New enhanced CLI with new options, validation of options and automatic help. for example, now you can run `Test-Machine` using the following command

```shell script
npx ketm run
```

here is a list of the available options:
![](https://i.imgur.com/njmDrRW.png)

- `AssertThat` is now a plugin
- New experimental Filtering mechanism which includes filtering by `Suite Name`,`Glob`, `Feature name`, `Scenario name`, a function with the following params `Feature name`, `Feature meta`
  , `Scenario name
  `, `Scenario Meta`
- `Selector` now can work with `xpath` selectors. no need for a separate `xPathSelector` method! behind the scenes, we use the native Browser implementation for `xpath` which means results will be
  accurate. unfortunately, this means it will work with green browsers only, this does not include `internet explore 11` and below. make sure to start the path with `//` otherwise it won't be detected
  as`xpath`.

example:

 ```js
await t.typeText(Selector('//input[contains(@placeholder,'
Username
)]
'),"this is new text")
```

- Chrome Browsers start `Maximized` by default
- Run `Test Machine` on a different process to isolate it
- Watch config file for changes then exit and warn the user to restart `Test Machine` again.
- Watch source files on 'add' | 'addDir' | 'change' | 'unlink' | 'unlinkDir' event and auto restart `test machine` to avoid stale files
- Improve speed of bundling by 30%
- `t.browser` Provide the capability to access browser information from test code
- `Scenario` keywords can't have another `Scenario` keyword chained to it if no steps are defined
- Add `tags` to `Feature`, `Scenario` and `Steps` API
- Add `ffmpeg` library by default, which will not require the user to install it
- Add `--dev` option to CLI `engine start` command
- Add more important `chromium` browser flags which lead to 100-150% increase in the speed of running tests in many cases
- Add `beforeAll` to `config.hooks` to run code before all `Features` start
- Add `afterAll` to `config.hooks` to run code after all `Features` start
- Add support for the new `edge (chromium)` based browser
- Highlight the column in the error source
- Status bar in the browser shows the current running `Feature => Scenario => step`
- Add `{PHASE}` to screen capture path pattern;
- Add `{PLATFORM}` to screen capture path pattern;
- Add `{OS_NAME}` to screen capture path pattern;
- Add `{ENGINE_NAME}` to screen capture path pattern;
- Add `{ENGINE_VERSION}` to screen capture path pattern;
- Add `{BROWSER_NAME}` to screen capture path pattern;
- Add `{BROWSER_NAME}` to screen capture path pattern;
- Add `{PRETTY_USERAGENT}` to screen capture path pattern;
- Add more options to `Allure` reporter

### Changes

- Added `feature-analyzer-loader` to analyze the code and infer information like `only()` method for example
- Add `build` to `config`
- Add `specs` to `config`
- Move `specsParser` to `config.specs`
- Rename `config.runner.baseUrl` to `config.startPage`
- Rename `sourceFiles` in `config` to `source`
- Rename `sourceFiles` in `CLI` to `specs`
- Remove `compiler` Setting
- Remove `xPathSelector` as we can use default `Selector` for that now
- Add  `config.runner.outputPath`
- `compiler` source now uses parsed source with filtering and suites.
- `compiler` output now uses `config.build.outputPath`
- Move `currentStep` from `window` object to `local storage`
- Add `CodeHighlighter` with ability to create custom renderers
- Add `CodeHighlighter` `color` renderer
- Add `engine.restart()` method
- Add `engine.setupReporters()` method
- Add `--experimental-worker` to CLI
- Add `classToObject` helper
- Add `mode:"production` to compiler config
- Add `devtools:"source-map"` to compiler config for better sourcemaps
- Add ` devtoolModuleFilenameTemplate: [absolute-resource-path]` to bundler config for better sourcemaps location
- Add `PhaseRunner` to control the flow of the code execution
- Add `engineInstance` with fewer data to pass to `Adapters`, `Reporters`,`Profiles` and `Plugins`
- Add `engine.state` to handle the lifecycle of the execution.
- Make reporter methods optional
- Rename `browser.flags` to `browser.args`
- Removed the global object and replaced it with the `engine`
- Improve browsers options handling
- Update to latest `Testcafe`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- When an error happens in `scenario` before hook reporters are corrupted
- Remove webpack `fix` module o fix npm packages
- Fix `page` property in `Feature` causing issues with latest `testcafe`
- Fix `page` property in `Scenario` causing issues with latest `testcafe`
- Fix `page` property in `Step` causing issues with latest `testcafe`
- Fix process not exciting on `ctrl-c`
- Fix `detailed-error` looking at wrong source files
- Fix proper process exit on exception
- Fix setting not updating on `test-machine` library update during development in `liveMode`
- Fix reporters correct execution time
- Fix async issues with `testcafe`
- Fix caching of specs

## [0.0.26-alpha] - 2019-11-11

### Features

- Watch config file for changes and auto stop `test machine`
- Add `subStep` function to be used for reporting
- Add `executor` to `Allure` reporter
- Add `Scenario` `parent_suite` label to `Allure` reporter
- Add `step` `parent_suite` label to `Allure` reporter
- Group `Scenarios` by `Features` to `Allure` reporter
- Group `Steps` by `Scenarios` to `Allure` reporter
- Add `status` text to `Scenario` in `Allure` reporter
- Add `stage` text to `Scenario` in `Allure` reporter
- Add screenshots when enabled to each step to `Allure` reporter
- Add error `Step Name`  in `Allure` reporter
- Add error `Step Keyword`  in `Allure` reporter
- Add error `Message`  in `Allure` reporter
- Add error `File Name`  in `Allure` reporter
- Add error `User Agent`  in `Allure` reporter
- Add error `source code`  in `Allure` reporter

### Changes

- Compile `test-machine` config into memory instead of disk
- Add `eval` typescript declaration
- Add `webpack-mem-compile` typescript declaration
- Add `wrapper-webpack-plugin` typescript declaration
- Remove Events from `engine` constructor
- Remove Events from `engine` constructor
- Add `AllureState` store
- Moved `compilerConfig` to separate file
- Add `settings` property to global `__TEST_MACHINE__`
- Add `specs` property to global `__TEST_MACHINE__`
- Add `started` property to global `__TEST_MACHINE__`
- Update to latest `Testcafe`
- Use `webpack` memory compilation for `test machine` config
- Set current step on window `__TEST_MACHINE__` object
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix steps error list not clearing on subsequent runs
- Fix Error message not working
- Update Error parsing to work with latest `testcafe`
- Add red color to error message
- Fix detailed Error `frame.filename` path for none project files
- Fix detailed Error message when no stack is available
- Fix `Specs` are not store on subsequent runs
- Fix reporters not added to `reportManager` on subsequent runs
- Fix all globals store

## [0.0.25-alpha] - 2019-11-01

### Features

- Add Beta `Allure` reporter
- Add `generateReport` option to `Allure` reporter
- Add `resultsFolder` option to `Allure` reporter
- Add `reportFolder` option to `Allure` reporter
- Add `Feature` `name` to `Allure` reporter
- Add `Feature` `duration` to `Allure` reporter
- Add `Scenario` `name` to `Allure` reporter
- Add `Scenario` `keyword` parameter to `Allure` reporter
- Add `Scenario` `duration` to `Allure` reporter
- Add `Scenario` `status` to `Allure` reporter
- Add `Scenario` `Thread` label to `Allure` reporter
- Add `Scenario` `Feature` label to `Allure` reporter
- Add `Step` `name` to `Allure` reporter
- Add `Step` `status` to `Allure` reporter
- Add `Step` `duration` to `Allure` reporter
- Add `Step` `keyword` parameter to `Allure` reporter

### Changes

- Update to latest Testcafe
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [0.0.23-alpha] - 2019-10-15

## [0.0.24-alpha] - 2019-10-18

### Features

### Changes

- Update to latest Testcafe
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fixed `specs parser` hanging on empty specs

## [0.0.23-alpha] - 2019-10-15

### Features

- Add ability to inject client scripts, this allows us to utilize `javascript` libraries in code like ``jquery`
- Add `disablePageCaching` to `engine.settings.runner`
- Add `disablePageCaching` to `Feature`
- Add `disablePageCaching` to `Scenario`
- Add `clientScripts` to `engine.settings.runner`
- Add `clientScripts` to `Feature`
- Add Logging option to disable showing log for `feature`, `scenario`, `step`
- Add `engine.settings.reporting.logging.feature`
- Add `engine.settings.reporting.logging.scenario`
- Add `engine.settings.reporting.logging.step`

### Changes

- Update to latest Testcafe
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- LiveRunner.stop() now closes the browsers
- Fixed a bug when client scripts were not injected in live mode when it re-executed tests
- Working with servers that use JSZip to unpack uploaded files
- Live Mode no longer fails when it restarts tests that import other modules on Node.js v12
- `Scenario.clientScripts` no longer override `Feature.clientScripts`
- Live Mode no longer fails when it restarts tests that import other modules on Node.js v12

## [0.0.22-alpha] - 2019-08-09

### Features

- Add installing `test-machine-pega-model` for demo purpose in `ketm generate project init`
- Add installing `src/data/user.ts` for demo purpose in `ketm generate project init`

## [0.0.21-alpha] - 2019-08-08

### Features

- Add our custom `ClientFunction`
- Add ketm generate `project init` option
- Add NPM init in `ketm project init`
- Add .gitIgnore in `ketm project init`
- Add tsconfig.json in `ketm project init`
- Add .eslintrc.js in `ketm project init`
- Add .prettierrc.js in `ketm project init`
- Add test-machine.local.ts in `ketm project init`
- Add test-machine.ci.ts in `ketm project init`
- Add Specs folder in `ketm project init`
- Add example-spec.ts in `ketm project init`
- Initializing Git Repo in `ketm project init`

### Changes

- Add `ignored: /node_modules/`  option to `bundler`
- Expose `bunldeWatcher` as `engine` property
- stop `bundler` watch on `engine` `stop()`
- use the passed browserController in `StepFn` as is
- Renamed `specsParser.path` to `specsParser.jsonPath`
- `engine.settings.runner.liveMode` is now true by default
- `engine.settings.specsParser.enabled` is now false by default
- Rename `url` property on `Feature` keyword to `page`
- Rename `url` property on `Scenario` keyword to `page`
- Rename `url` property on `Step` to keyword `page`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

## [0.0.20-alpha] - 2019-07-28

### Features

- Add warning to developer if there are no test files have been added
- Generate `features.json` in feature folder after downloading from `AssertThat` to have a json representation of the features

### Changes

- `settings.reporting.screenshots.enabled` is set to false by default
- Moved default browser to `settings`
- Update Deps
- update interfaces
- code refactoring
- code cleanup
- No need for new controller in step

### Fixes

- Gherkin `When` step was not added
- `beforeAll` hook was called instead of `afterAll` in `taskDone` reporter step
- Undefined step status is not set in `cucumber` reporter
- Fix error object for each step is mutated

## [0.0.19.alpha] - 2019-07-25

### Features

### Changes

- Remove `postinstall` to fix `gherkin` lib
- Temporally create local `gherkin` parser code until they fix it
- Bring back `ExtendedTestController`
- Bring back `ExtendedSelector`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Fix the need to pass `t` to `Selector`
- Fix ability to use `TestController` in external libs and PageModels
- Fix gherkin lib

## [0.0.18.alpha] - 2019-07-15

### Features

- Add `disable-dev-shm-usage` to `chromium` based browsers to improve memory usage
- Add `Assert` and `Expect` style assertion utilities
- Add `sourceHtml` to `DetailedError`
- Add `sourceRaw` to `DetailedError`
- Add passed/failed icons to `standard` reporter
- Enhanced reporting formatting

### Changes

- Update `DetailedError`
- Create proper `callsite` if error is not coming from `testcafe`
- Use `callsite-record` to get highlighted source instead of `cardinal`
- Create `extendedController` object
- Update `cucumber` reporter `specsTransformer` to use `sourceRaw` for error messages
- update `tsconfig.json`
- Update Deps
- update interfaces
- code refactoring
- code cleanup

### Fixes

- Test Controller not resolving on first run
- Reporters not available in live mode after first run
- `StepDone` hook was running twice
- Temporally fix `gherkin` lib wrong exports until they fix it
- Sanitize `AssertThat` downloaded filenames

## [0.0.17.alpha] - 2019-07-15

### Features

- Improved Hooks setup
- Step Reporting info now includes each browser run.
- `StepSpec.arguments` now contains {placeHolders, dataTable, dataTableRaw,docString}`
- If not using `live` mode, the process exists automatically after completion
- Add `text`, `errors`, `info` to reporter `IRunInfo` argument
- Optimize `Background` keyword execution

### Changes

- Add `RunState` global class to store all framework's state during runs
- Remove `ApiTracker` in favor of `RunState` class
- Remove `specsMap` in favor of `RunState` class
- Dont bootstrap `Scenario` `test` function if `engine.settings.runner.disablePageReload` is false
- Add `IRunInfo` param to reporter `FeatureStart`
- `FeatureSpec` result is now array of each browser run
- `ScenarioSpec` result is now array of each browser run
- `StepSpec` result is now array of each browser run
- `Cucumber` reporter error message is now colored with `CSS`
- `AssertThat` is not enabled by default
- Remove `implementation` property from `FeatureSpec`
- Remove `implementation` property from `ScenarioSpec`
- Remove `implementation` property from `StepSpec`
- Update methods to use our extended `BrowserController` instead of `testcafe` default controller

### Fixes

- `Feature` `url` was not set correctly
- Fix `embeddings` screen-shot path
- `StepSpec` name property was not always set in `SpecParser`
- Remove illegal characters from screenshot filename
- `Cucumber` reporter was not generating correct `arguments` property structure

## [0.0.16.alpha] - 2019-07-07

### Features

- 200-400% speed improvement by adding `settings.runner.disablePageReload` setting, which is disabled by default. this will bypasses `testcafe` reloading the page on each `Scenario` keyword
  When `Feature` has more than one `Scenario` keyword.
- Add our own `TestController` which extends `testcafe` own `TestController`. this will allow us to add methods in feature if not done by `testcafe` team.
- All keywords Operations are now Asynchronous which are managed by Queue.
- Each Gherkin keyword is a class of it is own now, this allows for inheritance and feature addition of common features.
- Add `keywords` to all `Specs` types.
- Add `httpAuth` method to `Feature`.
- Add `requestHooks` method to `Feature`.
- Add `requestHooks` method to `Scenario` keywords.
- Add `httpAuth` method to `Scenario` keywords.
- Add `tags` to `scenario Outline Examples`.
- Add `hidden` property to `step` in `Cucumber` reporter `SpecsTransformer`.
- Add `dateFormatter` with `format` and `parse` methods and support for `i18n`.
- Add `async/await` compatible `delay` utility.
- Add `xPathSelector` Selector for using xpath instead of css selectors.
- Activated `beforeAll` Hook.
- Activated `afterAll` Hook.
- Activated `beforeEachFeature` Hook.
- Activated `afterEachFeature` Hook.
- Activated `beforeEachScenario` Hook.
- Activated `afterEachScenario` Hook.
- Activated `beforeEachStep` Hook.
- Activated `afterEachStep` Hook.

### Changes

- Wrap all `Scenario` keywords in one `test` when `settings.runner.disablePageReload` is false.
- Created Class for `Feature` keyword.
- Created Class for each `Scenario` keyword.
- Created Class for each `Step` keyword.
- Created `BaseApi` which all keywords inherit from.
- Created `BaseSpec` which all Specs inherit from.
- `FeatureFn`, `ScenarioFn`, `StepFn` all inherit from `BaseFn`.
- Separated Api method from real implementation.
- Add `ApiTrack` to track api methods.
- Add `global declare` for `TestController` to argument `testcafe` implementation.
- `FeatureFn`, `ScenarioFn`, `StepFn` are separated from `API` methods.
- Add Queue manager for asynchronous operations.
- Dont parse `Gherkin` AST if there is no `gherkinDocument`.
- Dont init `examples` property in `ScenarioSpec`.
- Replace `padleft` with native method.
- Add `Omit` type.
- Changed `tags` in `FeatureSpec` to object array instead of string array.
- Changed `tags` in `ScenarioSpec` to object array
- Renamed `settings.runner.startUrl` to `settings.runner.baseUrl`.
- Renamed `skipMe` to `skip` in `Feature`.
- Renamed `onlyMe` to `only` in `Feature`.
- Renamed `skipMe` to `skip` in `Scenario`.
- Renamed `onlyMe` to `only` in `Scenario`.
- Renamed `beforeFeature` to `before` in `Feature`.
- Renamed `afterFeature` to `after` in `Feature`.
- Renamed `beforeScenario` to `before` in `Scenario`.
- Renamed `after` to `after` in `Scenario`.
- Removed `id` property from `FeatureSpec`.
- Removed `duration` property from `FeatureSpec`.
- Removed `id` property from `ScenarioSpec`.
- Replaced spaces with dashes of `Feature` `id` property in `Cucumber` reporter `SpecsTransformer`.
- Add `id` property to `scenario` and replaced spaces with dashes in `Cucumber` reporter `SpecsTransformer`.
- Use string native `padStart` instead of `pad-left` library.
- Add `esModuleInterop` option to `tsconfig.json`*[]:
- Use `dateFormatter` instead of `dateformat`.
- Update Deps.
- update interfaces.
- code refactoring.
- code cleanup.

### Fixes

- Reporters are added again in `live` mode.

## [0.0.15.alpha] - 2019-06-24

### Features

- Add `settings.server.onReady`.
- Add `settings.runner.appStart` to run shell command before start.
- Add `settings.server.proxyHost`.
- Add `settings.server.proxyBypassRules`.
- Add `settings.compiler.sourcePath`.
- Add `argumentStartDelimiter` and  `argumentEndDelimiter`to `SpecsParser` to customize step template placeholder.
- Add property `name` to Reporter.
- Add warning if more than one Gherkin `Background` keyword is used.
- Activated screenshots and videos save path pattern with the following placeholders that will be replaced with their respective values: `${DATE}`, `${TIME}`, `${FEATURE}`, `${SCENARIO}` ,`${BROWSER}`
  , `${BROWSER_VERSION}`, `${OS}`, `${OS_VERSION}`, `${USERAGENT}`.
- Add global `osInfo` with Os name and version.
- Add `path` property to `StepSpec.embeddings`.
- Activated ScreenShot for Gherkin Steps.
- Convert ScreenShot to `base64` for embedding.

### Changes

- Capitalize `feature` keyword.
- Capitalize `scenario` keyword.
- Capitalize `example` keyword.
- Capitalize `scenarioOutline` keyword.
- Capitalize `given` keyword.
- Capitalize `when` keyword.
- Capitalize `and` keyword.
- Capitalize `then` keyword.
- Capitalize `but` keyword.
- Rename `skipMe` to `skip` in `Feature`.
- `settings.reporting.reporters` is now a `Set` type.
- `ReportManger.reporters` is now a `Set` type.
- use `testcafe.close()` if not in `live` mode.
- Use `settings.specsParser.specsPath` in parsing features.
- Use `this.settings.runner.sourceFiles` as glob for watcher.
- Renamed `StepSpec.embeddings.mime_type` to StepSpec.embeddings.mimeType.
- Map `mimeType` to `mime_type` in cucumber reporter `stepTransformer`.
- Update Deps.
- update interfaces.
- code cleanup.

### Fixes

- watcher for new files glob was not correct.

## [0.0.14.alpha] - 2019-06-17

### Features

- Add Support for `Gherkin` `Scenario Outline` keyword.
- Add Support for `Gherkin` `Scenario Outline` `examples` keyword.
- `Gherkin` `Scenario Outline` steps runs as many times as the number of `examples` rows.
- Make `Gherkin` `Scenario Outline` `examples` parameters available to developer.
- Add Support for `Gherkin` `Example`.
- Add Support for `Gherkin` `Background`.
- `Gherkin` `Background` steps run before each Scenario.
- Add Support for `Gherkin` `docString`.
- Add `language` property to `FeatureSpec`.
- Add `location` property to `FeatureSpec`.
- Add `examples` property to `ScenarioSpec`.
- Add `Standard` reporter.
- Add `info` parameter to reporter `StepStart` and `StepDone`.
- Print full stack error in reporter.

### Changes

- update chalk-pipes.
- provide `keyword` property for local `FeatureSpec`.
- provide `keyword` property for local `ScenarioSpec`.
- provide `keyword` property for local `StepSpec`.
- remove `extendedGlobal` from globals.
- `setupDefaults` now detects if we are in `devRun`.
- `runner` now uses `settings` values.
- `settings.runner.pageLoadTimeout` value is now 3000 ms.
- update `SpecsParser` to parse `Scenario Outline`, `Example` and `Background` keywords.
- update `SpecsParser` to parse `Scenario Outline`  `examples` .
- Remove `path.join()` from `settings`.
- use `engine.started` in live mode to avoid creating server.
- Set compiler `watch` property to `true` in live mode.
- Update Deps.
- update interfaces.
- code cleanup.

### Fixes

- losing added reporter on dev reruns.

## [0.0.13.alpha] - 2019-06-10

### Features

- `engine.start()` is now called automatically from **ketm** `engine start` command.
- Add ability to use `datatable` in `feature` files where table can be in 3 formats: left column as key, top row as key and as matrix.
- Add ability to use `placeholders` in `feature` files where `log with user {{mike}}` will result in `parameters.mike` available to developer.
- Add `--filter-by-suites` option to **ketm** `engine start` command.
- Add `--filter-by-glob` option to **ketm** `engine start` command.
- Add ability to define test suites based on globs.
- Add `suites` to `engine.runner.settings`.
- Add ability to do custom filtering with `filter` function based on `featureName, featureMeta, scenarioName, scenarioMeta, stepName, stepMeta` parameters.
- Add ability to filter based on suites.
- Add ability to filter based on globs.
- Add `filterBySuites` to `engine.settings.runner`.
- Add `filterByGlob` to `engine.settings.runner`.
- Add `filter` to `engine.settings.runner`.
- `SpecsParser` now warn user if there is `gherkin` syntax error in `feature` file.

### Changes

- update bundler multiple entries function.
- update `runner.source` to take filtering into account.
- update `Steps` to take filtering into account.
- update `FeatureSpec` properties.
- update `ScenarioSpec` properties.
- update `StepSpec` properties.
- update `SpecsParser` to parse `datatable` and `placeholders`.
- Moved `cucumber reporter` `toJSON()` into transformer function.
- throw error if `engine.start()` is called after engine has already started.
- throw error in  **ketm** `engine start` command if both `--filter-by-glob` and `--filter-by-suites` are used.
- throw error in  `engine.start()` command if both `--filter-by-glob` and `--filter-by-suites` are used.
- update `AssertThat` spinner.
- Update Deps.
- update interfaces.
- code cleanup.

## [0.0.12.alpha] - 2019-06-03

### Features

- Bootstrapping is now 30%-50% faster for `engine start`.
- Update to **Test Cafe** `1.2.0`.
- Config written in typescript is compiled in memory.
- Automatically assign random ports to the server if not provided.
- Add `Chrome Canary` browser support.
- Add `Chromium` browser support.
- Add `Firefox` browser support.
- Add `Microsoft Edge` browser support.
- Add `Microsoft IE` browser support.
- Add `Opera` browser support.
- Add `Safari` browser support.
- Add `SpecsTransformer` to `CucumberReporter`.
- Add `UNDEFINED` to `TestStatus`.
- Add Global Context.
- Add `__TEST_MACHINE__` for consisting values when running in **Live Mode**
- Add Global Events `engine:start`, `engine:dev:Run`, `task:start`, `task:done`.
- Add `Event Aggregator` with `async` and `sync emitting.
- Add  `debugMode: false`, `debugOnFail: false`, `stopOnFirstFail: false`, `skipJsErrors: false`, `skipUncaughtErrors: false`, `speed: 1`, `pageLoadTimeout: 0`, `selectorTimeout: 10000`
  , `assertionTimeout: 3000` new settings to the **Runner*
- Add global `beforeAll` hook to `engine.settings`.
- Add global `afterAll` hook to `engine.settings`.
- Add global `beforeEachFeature` hook to `engine.settings`.
- Add global `afterEachFeature` hook to `engine.settings`.
- Add global `beforeEachScenario` hook to `engine.settings`.
- Add global `afterEachScenario` hook to `engine.settings`.
- Add global `beforeEachStep` hook to `engine.settings`.
- Add global `afterEachStep` hook to `engine.settings`.
- Add `fast`, `aggressive`, `disable-background-timer-throttling`, `no-proxy-server`, `proxy-server='direct://'`, `proxy-bypass-list=*` to **Chromium** based browsers.
- Add Enhanced reporting with styling and layout.
- Add spinner for **step* start and finish phases.
- Add ability to report per browser or single report for **Steps**.
- Even if previous step fails, we can continue testing next step.

### Changes

- Detailed Error is using `file read now`
- Moved `toJSON` from **FeatureSpec** to **SpecsTransformer**
- Moved `toJSON` from **ScenarioSpec** to **SpecsTransformer**
- Moved `toJSON` from **StepSpec** to **SpecsTransformer**
- Feature `BeforeHooks` is now one function instead of Array.
- Feature `AfterHooks` is now one function instead of Array.
- Feature `BeforeEachScenarioHooks` is now one function instead of Array.
- Feature `AfterEachScenarioHooks` is now one function instead of Array.
- Add `firstRun`, `specsMap`, `settings to global settings.
- Add `firstRun`, `specsMap`, `settings to global settings.
- changed `defaultreporter` to `coreReporter`.
- Scenario `BeforeHooks` is now one function instead of Array.
- Scenario `AfterHooks` is now one function instead of Array.
- Scenario `BeforeEachStepHooks` is now one function instead of Array.
- Scenario `AfterEachStepHooks` is now one function instead of Array.
- Moved `sourceFiles` setting to **Runner**.
- Spinner is now more accurate by dumping `Ora`.
- Removed `status`, `runsCount`, `duration` properties from **StepSpec**.
- Errors stored ow are array with full details.
- Update Deps.
- update interfaces.
- code cleanup.

### Fixes

- Reporting steps sometimes dont run in correct Order.
- `SpecsMap` is duplicated.
- `engine.settings` are lost during **Live Mode**.
- Errors were not cleaned up on reruns.

## [0.0.11.alpha] - 2019-05-27

### Features

- Enabled parallelization and Added `concurrency` setting to **Runner**.
- Add `autoDownload`, `autoUpload` setting to **AssertThat**.
- Add `sourcePath` setting to **Compiler**.
- Add `outPath` setting to **Compiler**.
- Add `screenshot` settings to **Runner**.
- Add `videos` settings to **Runner**.
- Add `disabled` settings to **SpecAnalyzer**.
- Color highlighted errors in console.
- Show the line number, browser, and file where the error originated from.
- Show browser the error in console.
- Add `ReportHelpers` utility with `newLine`, `write`, `wordWrap`, `ident` methods.
- Report steps `taskStarted`, `taskDone`, `featureStarted`, `featureDone`, `scenarioStarted`, `scenarioDone`, `stepStarted`, `stepDone` are all active.
- Enabled all Gherkin steps Syntax.
- IDetailedError object:

```js
interface
IDetailedError
{
    code: string;
    type: string;
    lineNumber: number;
    fileName: string;
    userAgent: string;
    screenshotPath: string;
    stack: string;
    message: string;
    source: string;
}
```

- Errors are stored as array on the **StepSpec** object
- New Event Aggregator (pub/sub).
- Enabled `before`, `beforeEach`, `after`, `afterEach` hooks in **Feature**
- Enabled `before`, `beforeEach`, `after`, `afterEach` hooks in **Scenario**

### Changes

- Moved some settings from `server` to `runner` on engine settings property.
- Add `url`,`skipped`, `status`, `only` and `errors` properties to **StepSpec**.
- Add `url`,`skipped`, `status`, `only` and `errors` properties to **ScenarioSpec**.
- renamed feature hooks: `before` to `beforeFeature`, `beforeEach` to `beforeEachScenario`, `after` to `afterFeature`, `beforeEach` to `afterEachScenario`.
- renamed scenario hooks: `before` to `beforeScenario`, `beforeEach` to `beforeEachStep`, `after` to `afterScenario`, `beforeEach` to `afterEachStep`.
- `acAnalyzer` is now `specAnalyzer`.
- Update Deps.
- update interfaces.
- code cleanup.
