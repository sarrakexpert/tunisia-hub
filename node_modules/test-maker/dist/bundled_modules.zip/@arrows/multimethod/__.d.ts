declare const _skip: unique symbol;
declare const _not: unique symbol;
declare const _in: unique symbol;
declare const _notIn: unique symbol;
declare type Skip = {
    type: symbol;
};
declare type Not = {
    type: symbol;
    value: any;
};
declare type In = {
    type: symbol;
    values: any[];
};
declare type NotIn = {
    type: symbol;
    values: any[];
};
declare type Placeholder = Skip & {
    not: (vale: any) => Not;
    in: (...values: any[]) => In;
    notIn: (...values: any[]) => NotIn;
};
/**
 * Wildcard - accepts any value (skips the check).
 *
 * It has helper methods that modify the check:
 *   .not(val)
 *   .in(val1, val2, ..., valN)
 *   .notIn(val1, val2, ..., valN)
 *
 * @example
 *
 * method(__, 'always true')
 *
 * method([__, 'foo'], 'only foo will be checked')
 */
declare const __: Placeholder;
export { _skip, _not, _in, _notIn };
export default __;
