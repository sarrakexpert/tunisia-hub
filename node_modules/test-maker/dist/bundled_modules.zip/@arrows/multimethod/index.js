"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.__ = exports.multi = exports.method = exports.fromMulti = void 0;
const fromMulti_1 = require("./fromMulti");
exports.fromMulti = fromMulti_1.default;
const method_1 = require("./method");
exports.method = method_1.default;
const multi_1 = require("./multi");
exports.multi = multi_1.default;
const __1 = require("./__");
exports.__ = __1.default;
exports.default = {
    fromMulti: fromMulti_1.default,
    method: method_1.default,
    multi: multi_1.default,
    __: __1.default,
};
//# sourceMappingURL=index.js.map