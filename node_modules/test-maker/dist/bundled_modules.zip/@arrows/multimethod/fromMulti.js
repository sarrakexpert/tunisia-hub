"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fromMulti = void 0;
const compose_1 = require("@arrows/composition/compose");
const errors_1 = require("./errors");
const multimethod_1 = require("./internal/multimethod");
/**
 * Creates a new multimethods from the existing ones,
 * convenient for adding multiple methods.
 */
const fromMulti = (...methods) => (multimethod) => {
    if (methods.length === 0) {
        throw new errors_1.NoArgumentsError();
    }
    if (!(0, multimethod_1.areMethodsValid)(methods)) {
        throw new errors_1.NotMethodError();
    }
    if (typeof multimethod !== "function" || !multimethod[multimethod_1.multimethodKey]) {
        throw new errors_1.NotMultimethodError();
    }
    return (0, compose_1.default)(...methods)(multimethod);
};
exports.fromMulti = fromMulti;
exports.default = fromMulti;
//# sourceMappingURL=fromMulti.js.map