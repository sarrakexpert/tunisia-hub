import { MethodFn, Multimethod } from "./internal/types";
declare type FromMulti = (...methods: MethodFn[]) => (multimethod: Multimethod) => Multimethod;
/**
 * Creates a new multimethods from the existing ones,
 * convenient for adding multiple methods.
 */
declare const fromMulti: FromMulti;
export { fromMulti };
export default fromMulti;
