import { MultiFn } from './internal/types';
/**
 * Creates multimethod - a function that can dynamically choose proper implementation,
 * based on arbitrary dispatch of its arguments
 */
declare const multi: MultiFn;
export { multi };
export default multi;
