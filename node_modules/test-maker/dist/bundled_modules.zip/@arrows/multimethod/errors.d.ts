export declare const NoMethodError: new (details?: string | undefined) => any;
export declare const NoArgumentsError: new (details?: string | undefined) => any;
export declare const FirstArgumentError: new (details?: string | undefined) => any;
export declare const NotMethodError: new (details?: string | undefined) => any;
export declare const NotMultimethodError: new (details?: string | undefined) => any;
