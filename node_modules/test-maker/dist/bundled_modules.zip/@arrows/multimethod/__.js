"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports._notIn = exports._in = exports._not = exports._skip = void 0;
const _skip = Symbol('skip');
exports._skip = _skip;
const _not = Symbol('not');
exports._not = _not;
const _in = Symbol('in');
exports._in = _in;
const _notIn = Symbol('notIn');
exports._notIn = _notIn;
const _ = { type: _skip };
/**
 * Wildcard - accepts any value (skips the check).
 *
 * It has helper methods that modify the check:
 *   .not(val)
 *   .in(val1, val2, ..., valN)
 *   .notIn(val1, val2, ..., valN)
 *
 * @example
 *
 * method(__, 'always true')
 *
 * method([__, 'foo'], 'only foo will be checked')
 */
const __ = Object.assign(_, {
    /**
     * Matches argument that does not strict equal (===) to the provided value.
     *
     * @param value any value
     * @returns boolean
     *
     * @example
     *
     * multi(
     *   (a, b) => typeof a,
     *   method(__.not('number'), () => {
     *     throw new Error('Invalid first argument')
     *   }),
     *   method((a, b) => 'OK!'),
     * )
     *
     * multi(
     *   (a, b) => [typeof a, typeof b],
     *   method(['string', __.not('number')], () => {
     *     throw new Error('Invalid second argument')
     *   }),
     *   method((a, b) => 'OK!'),
     * )
     */
    not(value) {
        return { type: _not, value };
    },
    /**
     * Matches argument that is within provided values.
     *
     * @param value any value
     * @returns boolean
     *
     * @example
     *
     * multi(
     *   (a, b) => typeof a,
     *   method(__.in('number', 'bigint'), () => {
     *     throw new Error('Invalid first argument')
     *   }),
     *   method((a, b) => 'OK!'),
     * )
     *
     * multi(
     *   (a, b) => [typeof a, typeof b],
     *   method(['string', __.in('number', 'bigint')], () => {
     *     throw new Error('Invalid second argument')
     *   }),
     *   method((a, b) => 'OK!'),
     * )
     */
    in(...values) {
        return { type: _in, values };
    },
    /**
     * Matches argument that is not within provided values.
     *
     * @param value any value
     * @returns boolean
     *
     * @example
     *
     * multi(
     *   (a, b) => typeof a,
     *   method(__.notIn('string', 'number'), () => {
     *     throw new Error('Invalid first argument')
     *   }),
     *   method((a, b) => 'OK!'),
     * )
     *
     * multi(
     *   (a, b) => [typeof a, typeof b],
     *   method(['string', __.notIn('string', 'number')], () => {
     *     throw new Error('Invalid second argument')
     *   }),
     *   method((a, b) => 'OK!'),
     * )
     */
    notIn(...values) {
        return { type: _notIn, values };
    },
});
exports.default = __;
//# sourceMappingURL=__.js.map