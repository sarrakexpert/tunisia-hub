"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotMultimethodError = exports.NotMethodError = exports.FirstArgumentError = exports.NoArgumentsError = exports.NoMethodError = void 0;
const createErrorClass_1 = require("@arrows/error/createErrorClass");
exports.NoMethodError = (0, createErrorClass_1.default)('NoMethodError', 'No method specified for provided arguments.');
exports.NoArgumentsError = (0, createErrorClass_1.default)('NoArgumentsError', 'You have to provide at least one argument.');
exports.FirstArgumentError = (0, createErrorClass_1.default)('FirstArgumentError', 'First argument of multi must be either dispatch function or partially applied method.');
exports.NotMethodError = (0, createErrorClass_1.default)('NotMethodError', 'Argument is not a method');
exports.NotMultimethodError = (0, createErrorClass_1.default)('NotMultimethodError', 'Argument is not a multimethod.');
//# sourceMappingURL=errors.js.map