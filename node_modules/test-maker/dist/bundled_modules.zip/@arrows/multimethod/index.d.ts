import fromMulti from './fromMulti';
import { Multi } from './internal/types';
import method from './method';
import multi from './multi';
import __ from './__';
export { fromMulti, method, multi, __, Multi };
declare const _default: {
    fromMulti: (...methods: import("./internal/types").MethodFn[]) => (multimethod: import("./internal/types").Multimethod) => import("./internal/types").Multimethod;
    method: import("./internal/types").MethodFn;
    multi: import("./internal/types").MultiFn;
    __: {
        type: symbol;
    } & {
        not: (vale: any) => {
            type: symbol;
            value: any;
        };
        in: (...values: any[]) => {
            type: symbol;
            values: any[];
        };
        notIn: (...values: any[]) => {
            type: symbol;
            values: any[];
        };
    };
};
export default _default;
