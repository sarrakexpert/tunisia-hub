"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.method = void 0;
const errors_1 = require("./errors");
const addEntry_1 = require("./internal/addEntry");
const multimethod_1 = require("./internal/multimethod");
/**
 * Adds method to a multimethod
 */
const method = (caseValue, correspondingValue) => {
    const partialMethod = (multimethod) => {
        if (!multimethod[multimethod_1.multimethodKey]) {
            throw new errors_1.NotMultimethodError();
        }
        const first = caseValue;
        const second = correspondingValue;
        const isNotDefault = second !== undefined;
        const fn = isNotDefault ? second : first;
        const dispatchValues = isNotDefault ? first : null;
        const { methodEntries, defaultMethod, dispatch } = multimethod[multimethod_1.multimethodKey];
        if (isNotDefault) {
            const newMethodEntries = (0, addEntry_1.default)(methodEntries, dispatchValues, fn);
            return (0, multimethod_1.createMultimethod)(newMethodEntries)(defaultMethod)(dispatch);
        }
        return (0, multimethod_1.createMultimethod)(methodEntries)(fn)(dispatch);
    };
    // @ts-ignore
    partialMethod[multimethod_1.methodKey] = true;
    return partialMethod;
};
exports.method = method;
exports.default = method;
//# sourceMappingURL=method.js.map