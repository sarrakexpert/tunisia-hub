import { MethodFn } from './internal/types';
/**
 * Adds method to a multimethod
 */
declare const method: MethodFn;
export { method };
export default method;
