import { MethodEntries } from './types';
declare type AddEntry = (methodEntries: MethodEntries, caseValue: any, caseCorrespondingValue: any) => MethodEntries;
declare const addEntry: AddEntry;
export default addEntry;
