declare type IsConstructor = (value: any) => boolean;
declare const isConstructor: IsConstructor;
export default isConstructor;
