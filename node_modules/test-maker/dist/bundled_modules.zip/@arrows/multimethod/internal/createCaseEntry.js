"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const isConstructor_1 = require("./isConstructor");
const __1 = require("../__");
const createCaseEntry = (caseValue) => {
    if (caseValue.type === __1._skip) {
        return { type: 'skip' };
    }
    if (caseValue.type === __1._not) {
        return { type: 'not', value: caseValue.value };
    }
    if (caseValue.type === __1._in) {
        return { type: 'in', value: caseValue.values };
    }
    if (caseValue.type === __1._notIn) {
        return { type: 'notIn', value: caseValue.values };
    }
    if ((0, isConstructor_1.default)(caseValue)) {
        return { type: 'constructor', value: caseValue };
    }
    if (caseValue instanceof RegExp) {
        return { type: 'regexp', value: caseValue };
    }
    if (typeof caseValue === 'function') {
        return { type: 'function', value: caseValue };
    }
    if (Array.isArray(caseValue) &&
        caseValue.some((item) => (0, isConstructor_1.default)(item) || item === __1.default || item instanceof RegExp)) {
        return {
            type: 'mixed',
            values: caseValue.map((item) => {
                return item.type === __1._skip
                    ? { type: 'skip' }
                    : item.type === __1._not
                        ? { type: 'not', value: item.value }
                        : item.type === __1._in
                            ? { type: 'in', value: item.values }
                            : item.type === __1._notIn
                                ? { type: 'notIn', value: item.values }
                                : {
                                    type: (0, isConstructor_1.default)(item)
                                        ? 'constructor'
                                        : item instanceof RegExp
                                            ? 'regexp'
                                            : 'value',
                                    value: item,
                                };
            }),
        };
    }
    return {
        type: 'value',
        value: caseValue,
    };
};
exports.default = createCaseEntry;
//# sourceMappingURL=createCaseEntry.js.map