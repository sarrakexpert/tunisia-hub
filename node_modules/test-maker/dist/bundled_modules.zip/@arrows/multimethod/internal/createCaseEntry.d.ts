import { CaseEntry } from './types';
declare type CreateCaseEntry = (caseValue: any) => CaseEntry;
declare const createCaseEntry: CreateCaseEntry;
export { CaseEntry };
export default createCaseEntry;
