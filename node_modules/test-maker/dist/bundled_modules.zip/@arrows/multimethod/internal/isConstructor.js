"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const isConstructor = (value) => {
    return (typeof value === 'function' &&
        value.name &&
        value.name[0] === value.name[0].toUpperCase());
};
exports.default = isConstructor;
//# sourceMappingURL=isConstructor.js.map