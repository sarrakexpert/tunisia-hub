import { multimethodKey } from './multimethod';
declare type Class<T> = new (...args: any[]) => T;
export declare type Dispatch = (...args: any[]) => any;
export declare type MethodEntry = [any, any];
export declare type MethodEntries = MethodEntry[];
export declare type DefaultMethod = ((arg0: any, arg1?: any) => any) | null;
export declare type SkipCaseEntry = {
    type: 'skip';
};
export declare type NotCaseEntry = {
    type: 'not';
    value: any;
};
export declare type InCaseEntry = {
    type: 'in';
    value: any[];
};
export declare type NotInCaseEntry = {
    type: 'notIn';
    value: any[];
};
export declare type ValueCaseEntry = {
    type: 'value';
    value: any;
};
export declare type ConstructorCaseEntry = {
    type: 'constructor';
    value: new (...args: any[]) => Class<any>;
};
export declare type RegExpCaseEntry = {
    type: 'regexp';
    value: RegExp;
};
export declare type FunctionCaseEntry = {
    type: 'function';
    value: (...args: any[]) => boolean;
};
export declare type MixedCaseTypes = ConstructorCaseEntry | ValueCaseEntry | RegExpCaseEntry | SkipCaseEntry | NotCaseEntry | InCaseEntry | NotInCaseEntry;
export declare type MixedCaseEntry = {
    type: 'mixed';
    values: Array<MixedCaseTypes>;
};
export declare type CaseEntry = ValueCaseEntry | ConstructorCaseEntry | RegExpCaseEntry | FunctionCaseEntry | MixedCaseEntry | SkipCaseEntry | NotCaseEntry | InCaseEntry | NotInCaseEntry;
export declare type Internals = {
    methodEntries: MethodEntries;
    defaultMethod: DefaultMethod;
    dispatch: Dispatch;
};
export declare type Multi = {
    [multimethodKey]: Internals;
};
export declare type Multimethod = ((...args: any[]) => any) & Multi;
export declare type MethodFn = (arg0: any, arg1?: any) => (multimethod: Multimethod) => Multimethod;
export declare type MultiFn = (arg0?: Dispatch | MethodFn, ...methods: MethodFn[]) => Multimethod;
export {};
