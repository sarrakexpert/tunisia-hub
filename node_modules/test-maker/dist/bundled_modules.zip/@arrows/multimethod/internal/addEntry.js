"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const equal = require("fast-deep-equal");
const createCaseEntry_1 = require("./createCaseEntry");
const addEntry = (methodEntries, caseValue, caseCorrespondingValue) => {
    const caseEntry = (0, createCaseEntry_1.default)(caseValue);
    const index = methodEntries.findIndex((entry) => equal(entry[0], caseEntry));
    const newMethodEntry = [caseEntry, caseCorrespondingValue];
    if (index === -1) {
        return [newMethodEntry, ...methodEntries];
    }
    const newMethodEntries = [...methodEntries];
    newMethodEntries[index] = newMethodEntry;
    return newMethodEntries;
};
exports.default = addEntry;
//# sourceMappingURL=addEntry.js.map