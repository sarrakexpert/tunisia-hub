import { DefaultMethod, MethodEntries, MultiFn } from './types';
declare const multimethodKey: unique symbol;
declare const methodKey: unique symbol;
declare const areMethodsValid: (args: any[]) => boolean;
declare type CreateMultimethod = (methodEntries?: MethodEntries) => (defaultMethod?: DefaultMethod) => MultiFn;
declare const createMultimethod: CreateMultimethod;
export { createMultimethod, multimethodKey, methodKey, areMethodsValid };
