"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.areMethodsValid = exports.methodKey = exports.multimethodKey = exports.createMultimethod = void 0;
const compose_1 = require("@arrows/composition/compose");
const equal = require("fast-deep-equal");
const errors_1 = require("../errors");
const multimethodKey = Symbol('multimethod');
exports.multimethodKey = multimethodKey;
const methodKey = Symbol('method');
exports.methodKey = methodKey;
const implicitDispatch = (...args) => args.length > 1 ? [...args] : args[0];
const countSegments = (dispatch) => {
    let count = 1;
    let current = dispatch;
    try {
        while (typeof current === 'function') {
            const next = current();
            if (typeof next === 'function') {
                count++;
                current = next;
            }
            else {
                return count;
            }
        }
    }
    catch (_a) { } // tslint:disable-line
    return count;
};
const findTarget = (methodEntries, currentDispatchValue, args, defaultMethod) => {
    const entry = methodEntries.find(([dispatchEntry]) => {
        switch (dispatchEntry.type) {
            case 'skip':
                return true;
            case 'not':
                return dispatchEntry.value !== currentDispatchValue;
            case 'in':
                return dispatchEntry.value.includes(currentDispatchValue);
            case 'notIn':
                return !dispatchEntry.value.includes(currentDispatchValue);
            case 'value':
                return equal(dispatchEntry.value, currentDispatchValue);
            case 'function':
                return dispatchEntry.value(...args);
            case 'constructor':
                return (currentDispatchValue === dispatchEntry.value ||
                    currentDispatchValue instanceof dispatchEntry.value);
            case 'regexp':
                return dispatchEntry.value.test(currentDispatchValue);
            case 'mixed':
                return dispatchEntry.values.every((item, index) => {
                    switch (item.type) {
                        case 'skip':
                            return true;
                        case 'not':
                            return item.value !== currentDispatchValue[index];
                        case 'in':
                            return item.value.includes(currentDispatchValue[index]);
                        case 'notIn':
                            return !item.value.includes(currentDispatchValue[index]);
                        case 'constructor':
                            return (currentDispatchValue[index] === item.value ||
                                currentDispatchValue[index] instanceof item.value);
                        case 'value':
                            return equal(item.value, currentDispatchValue[index]);
                        case 'regexp':
                            return item.value.test(currentDispatchValue[index]);
                    }
                });
        }
    });
    const target = entry ? entry[1] : defaultMethod;
    if (!entry && target === null) {
        throw new errors_1.NoMethodError(`Args: ${args}`);
    }
    return target;
};
const createSimpleTarget = (methodEntries, defaultMethod, dispatch) => {
    const fn = (...args) => {
        const currentDispatchValue = dispatch(...args);
        const target = findTarget(methodEntries, currentDispatchValue, args, defaultMethod);
        if (typeof target !== 'function') {
            return target;
        }
        return target(...args);
    };
    Object.defineProperty(fn, 'length', { value: dispatch.length });
    return fn;
};
const createSegmentedTarget = (methodEntries, defaultMethod, dispatch, segmentsCount) => {
    const recur = (counter, previousSegmentsArgs = []) => {
        if (counter === 1) {
            return (...args) => {
                const segmentsArgs = [...previousSegmentsArgs, args];
                const count = segmentsArgs.length;
                let currentDispatchValue = dispatch(...segmentsArgs[0]);
                for (let i = 1; i < count; i++) {
                    currentDispatchValue = currentDispatchValue(...segmentsArgs[i]);
                }
                const target = findTarget(methodEntries, currentDispatchValue, [].concat(...segmentsArgs), defaultMethod);
                if (typeof target !== 'function') {
                    return target;
                }
                let result = target;
                for (let i = 0; i < count; i++) {
                    result = result(...segmentsArgs[i]);
                }
                return result;
            };
        }
        const fn = (...args) => {
            return recur(counter - 1, [...previousSegmentsArgs, args]);
        };
        Object.defineProperty(fn, 'length', { value: dispatch.length });
        return fn;
    };
    return recur(segmentsCount);
};
const areMethodsValid = (args) => {
    return args.every((item) => typeof item === 'function' && item[methodKey] === true);
};
exports.areMethodsValid = areMethodsValid;
const getFirstArgumentType = (arg) => {
    if (typeof arg !== 'function') {
        throw new errors_1.FirstArgumentError();
    }
    return arg[methodKey] ? 'method' : 'dispatch';
};
const createMultimethod = (methodEntries = []) => (defaultMethod = null) => (arg0, ...methods) => {
    if (arg0 === undefined) {
        throw new errors_1.NoArgumentsError();
    }
    if (methods.length > 0 && !areMethodsValid(methods)) {
        throw new errors_1.NotMethodError('Second or further argument of multi must be a partially applied method.');
    }
    const firstArgumentType = getFirstArgumentType(arg0);
    const allMethods = (firstArgumentType !== 'method'
        ? methods
        : [arg0, ...methods]);
    const dispatch = (firstArgumentType === 'dispatch'
        ? arg0
        : implicitDispatch);
    const segmentsCount = countSegments(dispatch);
    const multimethod = segmentsCount === 1
        ? createSimpleTarget(methodEntries, defaultMethod, dispatch)
        : createSegmentedTarget(methodEntries, defaultMethod, dispatch, segmentsCount);
    // @ts-ignore
    multimethod[multimethodKey] = {
        defaultMethod,
        dispatch,
        methodEntries,
    };
    if (allMethods.length !== 0) {
        return (0, compose_1.default)(...allMethods)(multimethod);
    }
    return multimethod;
};
exports.createMultimethod = createMultimethod;
//# sourceMappingURL=multimethod.js.map