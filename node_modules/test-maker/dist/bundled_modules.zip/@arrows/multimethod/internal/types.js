"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const multimethod_1 = require("./multimethod");
//# sourceMappingURL=types.js.map