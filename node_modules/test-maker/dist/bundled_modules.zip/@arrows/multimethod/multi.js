"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.multi = void 0;
const multimethod_1 = require("./internal/multimethod");
/**
 * Creates multimethod - a function that can dynamically choose proper implementation,
 * based on arbitrary dispatch of its arguments
 */
const multi = (0, multimethod_1.createMultimethod)()();
exports.multi = multi;
exports.default = multi;
//# sourceMappingURL=multi.js.map