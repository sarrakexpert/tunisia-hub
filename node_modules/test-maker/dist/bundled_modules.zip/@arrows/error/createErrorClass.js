"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const createErrorClass = (name, message, serializeStacktrace = false) => {
    return class extends Error {
        constructor(details = null) {
            const fullMessage = `${message}${details ? ` ${details}` : ''}`;
            super(fullMessage);
            this.name = name;
            this.message = fullMessage;
        }
        toJSON() {
            return JSON.stringify({
                error: Object.assign({ name: this.name, message: this.message }, (serializeStacktrace && { stacktrace: this.stack })),
            });
        }
    };
};
exports.createErrorClass = createErrorClass;
exports.default = createErrorClass;
