export declare type ArityOneFn = (arg: any) => any;
export declare type ReducingFn = (acc: any, next: any) => any;
export declare type ReduceFn = (fn: ReducingFn, initial: any) => (arr: any[]) => any;
export declare type WrappingFn = (fn: ArityOneFn, arg: any, isLast: boolean) => any;
export declare type Pipe = (...fns: ArityOneFn[]) => (initialArg: any) => any;
export declare type Compose = Pipe;
