"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const wrap = (fn, input) => {
    if (input instanceof Error) {
        return input;
    }
    let result;
    try {
        result = fn(input);
    }
    catch (error) {
        result = error;
    }
    if (result === undefined) {
        return input;
    }
    return result;
};
exports.wrap = wrap;
exports.default = wrap;
