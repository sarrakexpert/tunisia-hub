"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const wrap_1 = require("./wrap");
const wrapAsync = (fn, input, isLast) => {
    if (input instanceof Promise) {
        return input.then((rawInput) => {
            return wrap_1.default(fn, rawInput);
        });
    }
    return isLast ? Promise.resolve(wrap_1.default(fn, input)) : wrap_1.default(fn, input);
};
exports.wrapAsync = wrapAsync;
exports.default = wrapAsync;
