declare const wrap: <T, R>(fn: (arg: T) => R, input: T) => T | Exclude<R, void>;
export { wrap };
export default wrap;
