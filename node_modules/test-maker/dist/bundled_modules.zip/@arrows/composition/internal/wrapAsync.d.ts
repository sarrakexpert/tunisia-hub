declare type WrapAsync = <T, R>(fn: (arg: T) => R, input: T, isLast: boolean) => R | Error | T | Promise<T | R | Error>;
declare const wrapAsync: WrapAsync;
export { wrapAsync };
export default wrapAsync;
