"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chain_1 = require("./chain");
exports.chain = chain_1.default;
const chainRight_1 = require("./chainRight");
exports.chainRight = chainRight_1.default;
const compose_1 = require("./compose");
exports.compose = compose_1.default;
const curry_1 = require("./curry");
exports.curry = curry_1.default;
const pipe_1 = require("./pipe");
exports.pipe = pipe_1.default;
const rail_1 = require("./rail");
exports.rail = rail_1.default;
const railAsync_1 = require("./railAsync");
exports.railAsync = railAsync_1.default;
const railRight_1 = require("./railRight");
exports.railRight = railRight_1.default;
const railRightAsync_1 = require("./railRightAsync");
exports.railRightAsync = railRightAsync_1.default;
const tap_1 = require("./tap");
exports.tap = tap_1.default;
exports.default = {
    chain: chain_1.default,
    chainRight: chainRight_1.default,
    compose: compose_1.default,
    curry: curry_1.default,
    pipe: pipe_1.default,
    rail: rail_1.default,
    railAsync: railAsync_1.default,
    railRight: railRight_1.default,
    railRightAsync: railRightAsync_1.default,
    tap: tap_1.default,
};
