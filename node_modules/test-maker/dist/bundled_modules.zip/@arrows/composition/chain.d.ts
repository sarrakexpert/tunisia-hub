import { Pipe, WrappingFn } from './internal/common-types';
declare type Chain = (wrappingFn: WrappingFn) => Pipe;
declare const chain: Chain;
export { chain };
export default chain;
