"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chain_1 = require("./chain");
const wrapAsync_1 = require("./internal/wrapAsync");
const railAsync = chain_1.default(wrapAsync_1.default);
exports.railAsync = railAsync;
exports.default = railAsync;
