import { Compose } from './internal/common-types';
declare type RailRight = Compose & {
    async: Compose;
};
declare const railRight: RailRight;
export { railRight };
export default railRight;
