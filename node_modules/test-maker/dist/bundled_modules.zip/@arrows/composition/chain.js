"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chain = (wrappingFn) => (...fns) => (initialArg) => fns.reduce((arg, fn, index) => wrappingFn(fn, arg, index === fns.length - 1), initialArg);
exports.chain = chain;
exports.default = chain;
