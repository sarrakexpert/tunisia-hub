"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chain_1 = require("./chain");
const wrap_1 = require("./internal/wrap");
const railAsync_1 = require("./railAsync");
const rail = Object.assign(chain_1.default(wrap_1.default), {
    async: railAsync_1.default,
});
exports.rail = rail;
exports.default = rail;
