"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const curry_1 = require("./curry");
const rawTap = (fn, arg) => {
    if (arg instanceof Promise) {
        arg.then((result) => fn(result));
    }
    else {
        fn(arg);
    }
    return arg;
};
const tap = curry_1.default(rawTap);
exports.tap = tap;
exports.default = tap;
