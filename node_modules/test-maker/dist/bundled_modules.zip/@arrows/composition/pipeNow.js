"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pipeNow = (initialArg, ...fns) => fns.reduce((arg, fn) => fn(arg), initialArg);
exports.pipeNow = pipeNow;
exports.default = pipeNow;
