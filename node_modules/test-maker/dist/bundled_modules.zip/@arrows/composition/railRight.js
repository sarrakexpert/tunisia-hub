"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chainRight_1 = require("./chainRight");
const wrap_1 = require("./internal/wrap");
const railRightAsync_1 = require("./railRightAsync");
const railRight = Object.assign(chainRight_1.default(wrap_1.default), {
    async: railRightAsync_1.default,
});
exports.railRight = railRight;
exports.default = railRight;
