"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pipeNow_1 = require("./pipeNow");
const curriedPipe = (...fns) => (initialArg) => fns.reduce((arg, fn) => fn(arg), initialArg);
const pipe = Object.assign(curriedPipe, {
    now: pipeNow_1.default,
});
exports.pipe = pipe;
exports.default = pipe;
