"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chainRight = (wrappingFn) => (...fns) => (initialArg) => fns.reduceRight((arg, fn, index) => wrappingFn(fn, arg, index === fns.length - 1), initialArg);
exports.chainRight = chainRight;
exports.default = chainRight;
