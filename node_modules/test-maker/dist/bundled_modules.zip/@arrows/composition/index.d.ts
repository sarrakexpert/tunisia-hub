import chain from './chain';
import chainRight from './chainRight';
import compose from './compose';
import curry from './curry';
import pipe from './pipe';
import rail from './rail';
import railAsync from './railAsync';
import railRight from './railRight';
import railRightAsync from './railRightAsync';
import tap from './tap';
export { chain, chainRight, compose, curry, pipe, rail, railAsync, railRight, railRightAsync, tap, };
declare const _default: {
    chain: (wrappingFn: import("./internal/common-types").WrappingFn) => import("./internal/common-types").Pipe;
    chainRight: (wrappingFn: import("./internal/common-types").WrappingFn) => import("./internal/common-types").Pipe;
    compose: import("./compose.types").Compose20;
    curry: (fn: (...x: any[]) => any, args?: any[]) => (...x: any[]) => any;
    pipe: import("./pipe.types").Pipe20 & {
        now: import("./pipeNow.types").PipeNow20;
    };
    rail: import("./internal/common-types").Pipe & {
        async: import("./internal/common-types").Pipe;
    };
    railAsync: import("./internal/common-types").Pipe;
    railRight: import("./internal/common-types").Pipe & {
        async: import("./internal/common-types").Pipe;
    };
    railRightAsync: import("./internal/common-types").Pipe;
    tap: (...x: any[]) => any;
};
export default _default;
