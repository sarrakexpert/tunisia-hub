declare const curry: (fn: (...x: any[]) => any, args?: any[]) => (...x: any[]) => any;
export { curry };
export default curry;
