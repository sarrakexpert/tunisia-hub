import { PipeNow20 } from './pipeNow.types';
declare const pipeNow: PipeNow20;
export { pipeNow };
export default pipeNow;
