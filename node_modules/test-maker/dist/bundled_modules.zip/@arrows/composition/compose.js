"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const compose = (...fns) => (initialArg) => fns.reduceRight((arg, fn) => fn(arg), initialArg);
exports.compose = compose;
exports.default = compose;
