import { Compose } from './internal/common-types';
declare const railRightAsync: Compose;
export { railRightAsync };
export default railRightAsync;
