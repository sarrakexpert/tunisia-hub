"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const curry = (fn, args = []) => {
    if (fn.length < 2) {
        return fn;
    }
    return (...newArgs) => ((rest) => (rest.length >= fn.length ? fn(...rest) : curry(fn, rest)))([
        ...args,
        ...newArgs,
    ]);
};
exports.curry = curry;
exports.default = curry;
