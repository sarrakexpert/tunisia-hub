import { Compose20 } from './compose.types';
declare const compose: Compose20;
export { compose };
export default compose;
