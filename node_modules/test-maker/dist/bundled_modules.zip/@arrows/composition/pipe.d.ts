import { Pipe20 } from './pipe.types';
import { PipeNow20 } from './pipeNow.types';
declare type Pipe = Pipe20 & {
    now: PipeNow20;
};
declare const pipe: Pipe;
export { pipe };
export default pipe;
