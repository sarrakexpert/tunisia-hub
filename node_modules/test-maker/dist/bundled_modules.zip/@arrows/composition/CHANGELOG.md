# CHANGELOG

## 1.0.0

First stable release.

## 1.1.0

- Added `.async` methods to `rail` and `railRight`.
- Fixed bug: async functions now always return a promise.

## 1.1.1

- Updated README.

## 1.1.2 - 1.1.3

- Improved typings (generic overloads) fro pipe and compose.

## 1.2.0

- Added `pipe.now` method for instant evaluation of the pipe.

## 1.2.1

- Improved README.

## 1.2.2

- Updated dependencies
