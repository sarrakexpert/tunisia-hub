import { Pipe } from './internal/common-types';
declare const railAsync: Pipe;
export { railAsync };
export default railAsync;
