import { Compose, WrappingFn } from './internal/common-types';
declare type ChainRight = (wrappingFn: WrappingFn) => Compose;
declare const chainRight: ChainRight;
export { chainRight };
export default chainRight;
