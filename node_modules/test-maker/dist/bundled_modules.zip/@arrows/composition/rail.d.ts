import { Pipe } from './internal/common-types';
declare type Rail = Pipe & {
    async: Pipe;
};
declare const rail: Rail;
export { rail };
export default rail;
