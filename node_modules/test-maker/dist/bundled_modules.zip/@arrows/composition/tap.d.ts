declare const tap: (...x: any[]) => any;
export { tap };
export default tap;
