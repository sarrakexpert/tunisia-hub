"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chainRight_1 = require("./chainRight");
const wrapAsync_1 = require("./internal/wrapAsync");
const railRightAsync = chainRight_1.default(wrapAsync_1.default);
exports.railRightAsync = railRightAsync;
exports.default = railRightAsync;
