import {AbstractValue} from './abstractValue';

export class DescribedValue extends AbstractValue {
    public toString(): string {
        return this.describe() + ' - ' + this.get();
    }
}

export function booleanValue(key: string, value: boolean): DescribedValue {
    return new DescribedValue(key, String(value));
}

export function numberValue(key: string, value: number): DescribedValue {
    return new DescribedValue(key, String(value));
}