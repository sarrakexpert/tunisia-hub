export interface Value {
    get(): string;
    getAsBoolean(): boolean;
    getAsNumber(): number;
    describe(): string;
    toString();
}
