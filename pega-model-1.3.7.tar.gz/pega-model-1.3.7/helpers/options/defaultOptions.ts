// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

export class DefaultOptions {

    private static instance: DefaultOptions;

    constructor() {
        if (DefaultOptions.instance) {
            throw new Error("Error - use Singleton.getInstance()");
        }
        this._selector = 0;
        this._assertion = 0;
    }

    static getInstance(): DefaultOptions {
        DefaultOptions.instance = DefaultOptions.instance || new DefaultOptions();
        return DefaultOptions.instance;
    }

    _selector: number;
    _assertion: number;

    public setSelector(value: number): void {
        this._selector = value;
    }

    public getSelector(): number {
        return this._selector;
    }

    public setAssertion(value: number): void {
        this._assertion = value;
    }

    public getAssertion(): number {
        return this._assertion;
    }
}

export const defaultOptions = new DefaultOptions();


