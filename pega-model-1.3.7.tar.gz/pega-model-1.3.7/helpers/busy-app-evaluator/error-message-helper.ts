const warnMessages = [
    'Execution context was destroyed, most likely because of a navigation',
    'Target page, context or browser has been closed',
    'Session closed. Most likely the page has been closed',
];

export const isWarnMessage = async (message: string) => {
    return warnMessages.filter((warnMessage) => message.includes(warnMessage)).length > 0;
};
