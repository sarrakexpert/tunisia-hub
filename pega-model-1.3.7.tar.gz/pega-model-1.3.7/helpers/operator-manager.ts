// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import PQueue, { DefaultAddOptions } from "p-queue";
import PriorityQueue from "p-queue/dist/priority-queue";
import {logger} from 'test-maker';

export interface AltOperator {
    username: string;
    password: string;
}

export interface OperatorGroup {
    id: string;
    alt: AltOperator[];
}

// @ts-ignore
export class OperatorsManager {
    private queue: PQueue<PriorityQueue, DefaultAddOptions> = new PQueue({ concurrency: 1 });
    private operatorsGroups: Map<string, AltOperator[]> = new Map();
    private operatorsGroupsInUse: Map<string, Set<string>> = new Map();

    public async SetOperatorsSource(operators: OperatorGroup[]): Promise<void> {
        for (let operatorGroup of operators) {
            this.operatorsGroups.set(operatorGroup.id, operatorGroup.alt);
            this.operatorsGroupsInUse.set(operatorGroup.id, new Set());
        }
    }


   // @ts-ignore
    async assignOperator(groupId: string): Promise<AltOperator | undefined> {
        return this.queue.add(async (): Promise<AltOperator | undefined> => {
            if (!this.operatorsGroups.size) throw new Error("No operators Source has been set yet");

            const alternatives: AltOperator[] | undefined = this.operatorsGroups.get(groupId);
            let freeOperator: { username: string, password: string } | undefined;

            if (!alternatives) throw new Error(`Operator Id: ${groupId} does not exist`);

            const inUseGroup: Set<string> | undefined = this.operatorsGroupsInUse.get(groupId);

            if (inUseGroup) {
                for (let altOperator of alternatives) {
                    if (!inUseGroup.has(altOperator.username)) {

                        inUseGroup.add(altOperator.username);
                        freeOperator = altOperator;

                        break;
                    }
                }
            }

            if (!freeOperator) throw new Error(`Could not find free operator for Group:${groupId}`);

            await logger.info(`The operator "${freeOperator.username}" with the password "${freeOperator.password}" of the usergroup "${groupId}" was successfully assigned`);
            return freeOperator;
        });
    }

    async assignOperatorWithoutLocking(groupId: string): Promise<AltOperator | undefined> {
        return this.queue.add(async (): Promise<AltOperator | undefined> => {
            if (!this.operatorsGroups.size) throw new Error("No operators Source has been set yet");

            const alternatives: AltOperator[] | undefined = this.operatorsGroups.get(groupId);
            let freeOperator: { username: string, password: string } | undefined;

            if (!alternatives) throw new Error(`Operator Id: ${groupId} does not exist`);
            let randomIndex = Math.floor(Math.random() * (alternatives.length));
            freeOperator = alternatives[randomIndex];

            await logger.info(`The operator "${freeOperator.username}" with the password "${freeOperator.password}" of the usergroup "${groupId}" was successfully assigned`);
            return freeOperator;
        });
    }


    public async unAssignOperator(groupId: string, username: string): Promise<void> {
        await this.queue.add(async (): Promise<void> => {
            if (!this.operatorsGroups.size) throw new Error("No operators Source has been set yet");

            const inUseGroup: Set<string> | undefined = this.operatorsGroupsInUse.get(groupId);

            if (!inUseGroup) throw new Error(`Operator Id: ${groupId} does not exist`);

            await logger.info(`The operator "${username}" of the usergroup "${groupId}" was successfully unassigned`);
            if (inUseGroup?.has(username)) inUseGroup?.delete(username);
        });
    }
}