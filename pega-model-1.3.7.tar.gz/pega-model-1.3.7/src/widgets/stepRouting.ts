// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {Selector, I} from 'test-maker';
import {pega} from '../pega';
import {methodOptions, Options} from '../../helpers/options/methodOptions';
import {controlsCommonActions} from './controls/controlsCommonActions';

export class StepRouting {

    public readonly element = `.heading_5_dataLabelRead`;

    private actualOptions;

    async shouldHaveText(text: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await pega.progressBar.assertDone(this.actualOptions);
        await I.expect(Selector('.heading_5_dataLabelRead', this.actualOptions).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toEqual(text);
    }

    async getText() {
        await controlsCommonActions.getText(this.element);
    }
}