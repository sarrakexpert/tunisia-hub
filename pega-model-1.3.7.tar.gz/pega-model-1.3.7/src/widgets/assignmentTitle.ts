import {Selector, I} from 'test-maker';
import {methodOptions, Options} from '../../helpers/options/methodOptions';
import {controlsCommonActions} from './controls/controlsCommonActions';


export class AssignmentTitle {
    public readonly element: string = '.heading_2';

    async shouldHaveText(text: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        let actualOptions;
        actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToExist(Selector('.heading_2', actualOptions));
        if (actualOptions.isCaseSensitive==false) {
            await I.expect(async () => {
                return ((await Selector('.heading_2', actualOptions).filterVisible().innerText).toLowerCase());
            }, {
                timeout: actualOptions.assertionTimeout,
                interval: actualOptions.interval,
                retries: actualOptions.retries
            }).toEqual(text.toLowerCase());
        }
        else {
            await I.expect(Selector(this.element, actualOptions).innerText, {
                timeout: actualOptions.assertionTimeout,
                interval: actualOptions.interval,
                retries: actualOptions.retries
            }).toEqual(text);
        }
    }

    async getText() {
        await controlsCommonActions.getText(this.element);
    }

}
