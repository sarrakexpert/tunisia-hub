import {I, Selector} from "test-maker";
import {methodOptions, Options} from '../../helpers/options/methodOptions';

export class LoginForm {

    private actualOptions;

    async login(username: string, password: string, options?: { timeout: number, interval?: number, retries?: number }): Promise<void> {
        this.actualOptions = methodOptions.setOptions(options);
        await this.setLogin(username);
        await this.setPassword(password);
        await this.submit();
    }

    async setLogin(username: string, options?: { timeout: number, interval?: number, retries?: number }): Promise<void> {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector('#txtUserID', this.actualOptions))
            .fillField(Selector('#txtUserID'), username);
    }


    async setPassword(password: string, options?: { timeout: number, interval?: number, retries?: number }): Promise<void> {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector('#txtPassword', this.actualOptions))
            .fillField(Selector('#txtPassword'), password);
    }


    async submit(options?: { timeout: number, interval?: number, retries?: number }): Promise<void> {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector('#sub', this.actualOptions));
    }

    async assertLogInButtonIsVisible(options?: { timeout: number, interval?: number, retries?: number }): Promise<void> {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector('#sub',this.actualOptions).visible, {
            timeout: this.actualOptions.timeout + 1,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }
}

//export const loginForm = new LoginForm();
