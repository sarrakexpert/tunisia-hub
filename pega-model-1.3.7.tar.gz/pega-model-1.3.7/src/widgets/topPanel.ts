// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {pega} from '../pega';
import {methodOptions, Options} from '../../helpers/options/methodOptions';

export class TopPanel {

    private actualOptions;

    async createNewCase(caseName: string, options?: { timeout: number, interval?: number, retries?: number }){
        this.actualOptions = methodOptions.setOptions(options);
        let newCaseElement =
            `//span[contains(@class, "menu-item-title") and normalize-space(text()) = "${caseName}"]`;
        await I.click(Selector('[title="Create a case"]', this.actualOptions))
            .hover(Selector('//span[contains(@class, "menu-item-title") and normalize-space(text()) = "New"]'), this.actualOptions)
            .hover(Selector(newCaseElement, this.actualOptions))
            .click(newCaseElement, this.actualOptions);
    }

    async assertProfileIsLoaded(value: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await pega.frame.switchToFormFactoriFrame(); //for PegaExpress
        await I.expect(Selector(`[title="${value}"]`, this.actualOptions).visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }
}