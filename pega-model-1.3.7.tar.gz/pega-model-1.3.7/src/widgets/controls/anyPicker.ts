// Copyright 2021 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {controlsCommonActions} from './controlsCommonActions';

export class AnyPicker {
    public readonly element: string;
    public readonly container: string;
    private readonly attributeName: string;
    private readonly attributeValue: string;
    public readonly resultsList: string = `.anypicker-results`;
    public readonly selectedItem: string = `span[data-ctl='["Anypicker"]']`;


    constructor(attributeName: string, attributeValue: string, container: string = '') {
        this.container = container;
        this.attributeName = attributeName;
        this.attributeValue = attributeValue;
        if(this.attributeName === 'data-test-id') {
            this.element = `${container}//div[@${this.attributeName}="${this.attributeValue}"]`;
        }
        if(this.attributeName === 'id') {
            this.element = `${container}//input[@${this.attributeName}="${this.attributeValue}"]/parent::div[@class="anypicker"]`;
        }
    }

    private actualOptions;

    async click(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.click(this.element, options);
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.focus(this.element, options);
    }

    async pressTab() {
        await controlsCommonActions.pressTab();
    }

    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async shouldExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async resultsListShouldBeVisible() {
        await I.expectSelector(this.resultsList).toBeVisible();
    }

    async resultsListShouldNotBeVisible() {
        if(await Selector(this.resultsList).exists) {
            await I.expectSelector(this.resultsList).not.toBeVisible();
        }
        await I.expectSelector(this.resultsList).not.toExist();
    }

    async openList() {
        await I.click(Selector(this.element).find(`//i[@class="pi pi-caret-down"]`));
    }

    async selectValue(value: string) {
        await I.click(Selector(this.resultsList).find(`li span`).withExactText(value));
    }

    async shouldHaveValue(value: string) {
        await I.expectSelector(Selector(this.element).find(`input[data-ctl='["Anypicker"]']`)).toHaveValue(value);
    }

    async shouldNotHaveValue(value: string) {
        await I.expectSelector(Selector(this.element).find(`input[data-ctl='["Anypicker"]']`)).not.toHaveValue(value);
    }

    async deleteSelectedResult(value: string) {
        await I.hover(Selector(this.element).find(this.selectedItem).withExactText(`TestAppl:User4`))
            .click(Selector(this.element).find(this.selectedItem).find(`.ap-clear`));
    }
}