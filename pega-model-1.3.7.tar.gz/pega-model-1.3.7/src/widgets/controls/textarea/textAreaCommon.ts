// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {Selector, I} from 'test-maker';
import {controlsCommonActions} from '../controlsCommonActions';
import {methodOptions} from '../../../../helpers/options/methodOptions';
import {PegaErrorMessages} from '../pega-error-messages/pegaErrorMessages';
import {CustomDate} from '../../../../helpers/customDate';

export class TextAreaCommon {

    public readonly element: string;

    constructor(element: string) {
        this.element = element;
    }

    private actualOptions;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.element, checks, isFilterByVisibility = true);
    }

    async shouldExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async click(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.click(this.element, options);
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.focus(this.element, options);
    }

    async pressTab() {
        await controlsCommonActions.pressTab();
    }

    async set(value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.set(this.element, value, options);
    }

    async paste(value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.paste(this.element, value, options);
    }

    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async shouldHaveText(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        if (value === undefined) {
            return;
        }
        this.actualOptions = methodOptions.setOptions(options);
        value = value + "";
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).value, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toContain(value);
    }

    async shouldNotHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        if (value === undefined) {
            return;
        }
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).value, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toContain(value);
    }

    async shouldHaveExactText(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        if (value === undefined) {
            return;
        }
        this.actualOptions = methodOptions.setOptions(options);
        value = value + "";
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).value, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toEqual(value);
    }

    async shouldNotHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        if (value === undefined) {
            return;
        }
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).value, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toEqual(value);
    }


    async shouldNotBeBlank(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).value, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toEqual("");
    }

    async shouldHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveValue(this.element, value, options);
    }

    async shouldNotHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveValue(this.element, value, options);
    }

    async shouldBeEnabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.element, options);
    }

    async shouldBeDisabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.element, options);
    }

    async shouldBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeRequired(this.element, options);
    }

    async shouldNotBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeRequired(this.element, options);
    }

    async shouldHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveValidationType(this.element, validationType, options);
    }

    async shouldNotHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveValidationType(this.element, validationType, options);
    }

    async getValue() {
        return await controlsCommonActions.getValue(this.element);
    }

    async getText() {
        let text = await Selector(this.element).filterVisible().value;
        return text;
    }

    error() {
        return new PegaErrorMessages(this.element);
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.element, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.element, options);
    }
}
