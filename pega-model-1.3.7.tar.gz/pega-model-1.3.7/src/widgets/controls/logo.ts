// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {controlsCommonActions} from './controlsCommonActions';
import {methodOptions} from '../../../helpers/options/methodOptions';
import {I, Selector} from 'test-maker';

export class Logo {
    public readonly element: string;
    private readonly attributeName: string;
    private readonly attributeValue: string;

    constructor(attributeName = `data-test-id`, attributeValue = `2019032707440904433327`) {
        this.attributeName = attributeName;
        this.attributeValue = attributeValue;
        this.element = `//img[@data-ctl='Icon' and contains (@${this.attributeName}, "${this.attributeValue}")]`;
    }

    private actualOptions;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }


    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.element, checks, isFilterByVisibility = true);
    }

    async shouldExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async shouldHaveSourceFile(sourceFileName: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await I.expect(Selector(this.element, options).getAttribute('src')).toContain(sourceFileName);
    }

    async shouldNotHaveSourceFile(sourceFileName: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await I.expect(Selector(this.element, options).getAttribute('src')).not.toContain(sourceFileName);
    }

    toString() {
        return `(Logo with ${this.attributeName}='${this.attributeValue}')`;
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.element, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.element, options);
    }
}