// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


import {controlsCommonActions} from '../controlsCommonActions';
import {CustomDate, forCurrentDate, today} from '../../../../helpers/customDate';
import {PegaErrorMessages} from '../pega-error-messages/pegaErrorMessages';

export class DatePickerCommon {

    public readonly element: string;

    constructor(element: string) {
        this.element = element;
    }

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async click(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.click(this.element, options);
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.focus(this.element, options);
    }

    async pressTab() {
        await controlsCommonActions.pressTab();
    }

    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.element, checks, isFilterByVisibility = true);
    }

    async shouldExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async shouldHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveText(this.element, value, options);
    }

    async shouldNotHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveText(this.element, value, options);
    }

    async shouldHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveExactText(this.element, value, options);
    }

    async shouldNotHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveExactText(this.element, value, options);
    }

    async shouldHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveValue(this.element, value, options);
    }

    async shouldNotHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveValue(this.element, value, options);
    }

    async shouldBeEnabled(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.element, options);
    }

    async shouldBeDisabled(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.element, options);
    }

    async shouldNotBeBlank(index?: number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeBlank(this.element, options);
    }

    async set(value: string | number | CustomDate, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (value === undefined) { return; }
        let date;
        if (value instanceof CustomDate) {
            date = value.toStringBySlash();
        } else {
            date = value + "";
        }
        await controlsCommonActions.set(this.element, date, options);
    }

    async paste(value: string | number | CustomDate, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (value === undefined) { return; }
        let date;
        if (value instanceof CustomDate) {
            date = value.toStringBySlash();
        } else {
            date = value + "";
        }
        await controlsCommonActions.paste(this.element, date, options);
    }

    async setTodayPlusDays(days: number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }){
        if (days === undefined) { return; }
        let date = today().plusDays(days).toString('/',['d','m','y']);
        await controlsCommonActions.set(this.element, date, options);
    }

    async setTodayMinusDays(days: number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (days === undefined) { return; }
        let date = today().minusDays(days).toString('/',['d','m','y']);
        await controlsCommonActions.set(this.element, date, options);
    }

    async shouldHaveDateTodayPlusDays(days: number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }){
        if (days === undefined) { return; }
        let date = today().plusDays(days).toString('/',['d','m','y']);
        await controlsCommonActions.shouldHaveValue(this.element, date, options);
    }

    async shouldHaveDateTodayMinusDays(days: number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (days === undefined) { return; }
        let date = today().minusDays(days).toString('/',['d','m','y']);
        await controlsCommonActions.shouldHaveValue(this.element, date, options);
    }

    async shouldBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeRequired(this.element, options);
    }

    async shouldNotBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeRequired(this.element, options);
    }

    async shouldHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveValidationType(this.element, validationType, options);
    }

    async shouldNotHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveValidationType(this.element, validationType, options);
    }

    async getValue() {
        return await controlsCommonActions.getValue(this.element);
    }

    async getText() {
        return await controlsCommonActions.getText(this.element);
    }

    error() {
        return new PegaErrorMessages(this.element);
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.element, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.element, options);
    }
}