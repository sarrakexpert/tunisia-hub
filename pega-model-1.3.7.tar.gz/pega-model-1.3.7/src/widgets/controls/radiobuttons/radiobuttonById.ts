// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {controlsCommonActions} from '../controlsCommonActions';
import {radiobuttonCommon} from './radiobuttonCommon';
import {PegaErrorMessages} from '../pega-error-messages/pegaErrorMessages';

export class RadiobuttonById {

    public readonly container: string;
    private readonly partialId: string;

    constructor(partialId: string, container: string = '') {
        this.partialId = partialId;
        this.container = container;
    }

    public radioButtonElements(): string {
        return `${this.container}//label[contains (@for, "${this.partialId}")]`;
    }

    public radioButtonElement(value: string): string {
        return `${this.container}//label[contains (@for, "${this.partialId}") and contains(text(), "${value}")]`;
    }

    public radioButtonElementToCheck(value: string): string {
        return `${this.container}//label[contains (@for, "${this.partialId}") and contains(text(), "${value}")]/ancestor::span[contains(@class, "col")]/input[contains (@id, "${this.partialId}")]`;
    }

    async waitUntilVisibility(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.radioButtonElement(value), options);
    }

    async waitUntilElementExists(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.radioButtonElement(value), options);
    }

    async waitUntilElementNotExist(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.radioButtonElement(value), options);
    }

    async waitForSelectActionabilityCheck(value: string, checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.radioButtonElement(value), checks, isFilterByVisibility = true);
    }

    async shouldExist(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.radioButtonElement(value), options);
    }

    async shouldNotExist(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.radioButtonElement(value), options);
    }

    async waitUntilVisibilityByAttribute(value: string, attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.radioButtonElement(value), attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(value: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.radioButtonElement(value), index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(value: string, expectedSize: number,
                                                            options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.radioButtonElement(value), expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(value: string, expectedSize: number,
                                                      options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.radioButtonElement(value), expectedSize, options);
    }

    async waitUntilInvisibility(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.radioButtonElement(value), options);
    }

    async waitUntilInvisibilityByIndex(value: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.radioButtonElement(value), index, options);
    }

    async click(value: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        await controlsCommonActions.click(this.radioButtonElement(value), options);
    }

    async select(value: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        await controlsCommonActions.click(this.radioButtonElement(value), options);
    }

    async shouldBeVisible(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.radioButtonElementToCheck(value), options);
    }

    async shouldNotBeVisible(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.radioButtonElementToCheck(value), options);
    }

    async shouldBeChecked(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await radiobuttonCommon.shouldBeChecked(this.radioButtonElementToCheck(value), options);
    }

    async shouldNotBeChecked(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await radiobuttonCommon.shouldNotBeChecked(this.radioButtonElementToCheck(value), options);
    }

    async shouldBeEnabled(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.radioButtonElementToCheck(value), options);
    }

    async shouldBeDisabled(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.radioButtonElementToCheck(value), options);
    }

    toString() {
        return `(Radio Button with partial id ${this.partialId}')`;
    }

    error() {
        return new PegaErrorMessages(this.radioButtonElements());
    }

    async isVisible(value: string, options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.radioButtonElement(value), options);
    }

    async isExists(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.radioButtonElement(value), options);
    }
}
