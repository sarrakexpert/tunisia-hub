// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {Selector, I} from 'test-maker';
import {methodOptions, Options} from '../../../../../helpers/options/methodOptions';

export class TableCheckbox {

    public readonly element: string;
    private readonly attributeName: string;
    private readonly attributeValue: string;
    public readonly container: string;
    public readonly checkBoxElement: string;
    public readonly index: number;

    constructor(container: string, index: number, attributeValue: string = '') {
        this.attributeValue = attributeValue;
        this.container = container;
        this.element =
        `${container}//input[@type="checkbox"]`;
        let checkBoxElementPartialLocator = "";
        attributeValue === ''?
             checkBoxElementPartialLocator = ''
            : checkBoxElementPartialLocator = `/following-sibling::label[@for="${this.attributeValue}"]`;
        this.checkBoxElement =
        `${container}//input[@type="checkbox"]${checkBoxElementPartialLocator}`;
        this.index = index;
    }

    private actualOptions;

    async check(options?: {timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(this.index).checked) {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.index));
        } else {
            throw new Error(`Element ${this.toString()} should be unchecked, but was checked`);
        }
    }

    async checkByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked) {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(index));
        } else {
            throw new Error(`Element ${this.toString()} should be unchecked, but was checked`);
        }
    }

    async checkButton(options?: {timeout?: number, interval?: number, retries?: number }) { //will work only if attribute is id
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.index).checked) {
            await I.click(Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.index));
        } else {
            throw new Error(`Element ${this.toString()} should be unchecked, but was checked`);
        }
    }

    async uncheck(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(this.index).checked) {
            throw new Error(`Element ${this.toString()} should be checked, but was unchecked`);
        } else {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index));
        }
    }

    async uncheckByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(index).checked) {
            throw new Error(`Element ${this.toString()} should be checked, but was unchecked`);
        } else {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(index));
        }
    }

    async uncheckButton(options?: {timeout?: number, interval?: number, retries?: number }) { //will work only if attribute is id
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.index).checked) {
            throw new Error(`Element ${this.toString()} should be checked, but was unchecked`);
        } else {
            await I.click(Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.index));
        }
    }

    async checkIf(toClick: boolean, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (toClick === undefined) {
            return;
        }
        this.actualOptions = methodOptions.setOptions(options);
        if (toClick) {
            await this.check(this.actualOptions);
        }
    }

    async shouldBeChecked(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.index).checked, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    async shouldBeUnChecked(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.index).checked, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
    }

    toString() {
        return `(Checkbox with ${this.attributeName}='${this.attributeValue}')`;
    }
}
