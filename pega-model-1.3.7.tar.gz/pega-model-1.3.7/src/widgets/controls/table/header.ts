// Copyright 2021 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {controlsCommonActions} from '../controlsCommonActions';
import {I, Selector} from 'test-maker';
import {methodOptions} from '../../../../helpers/options/methodOptions';

export class Header {

    public readonly element: string;

    constructor(container: string) {
        this.element = container;
    }

    private actualOptions;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks: []) {
        await I.waitForSelectActionabilityCheck(this.element, checks);
    }

    async hover(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.hover(Selector(`${this.element}//ancestor::th`, this.actualOptions).filterVisible());
    }

    async click(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(`${this.element}//ancestor::th`, this.actualOptions).filterVisible());
    }

    async filter(options?: { timeout?: number, interval?: number, retries?: number }) {
        await this.click(options);
    }

    async sort(options?: { timeout?: number, interval?: number, retries?: number }) {
        await this.click(options);
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.focus(Selector(`${this.element}//ancestor::th`, this.actualOptions).filterVisible());
    }

    async clickTheLink(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(`${this.element}//ancestor::th//a`, this.actualOptions).filterVisible());
    }

    async shouldHaveText(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element).innerText).toContain(value);
    }

    async shouldHaveExactText(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element).innerText).toEqual(value);
    }

    async shouldNotHaveText(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element).innerText).not.toContain(value);
    }

    async shouldNotHaveExactText(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element).innerText).not.toEqual(value);
    }

    async shouldBeVisible(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expectSelector(this.element).toBeVisible();
    }

    async shouldNotBeVisible(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expectSelector(this.element).toBeInvisible();
    }
}