// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {Column} from './column';
import {Row} from './row';
import {Cell} from './cell';
import {methodOptions, Options} from '../../../../helpers/options/methodOptions';
import {controlsCommonActions} from '../controlsCommonActions';
import {Header} from './header';

export class Table {

    readonly tableContainerElement: string = "";
    readonly by: string;
    readonly value: string;
    readonly elementType: string;


    constructor(by: string, value: string, elementType: string, container: string = '') {
        this.value = value;
        this.by = by;
        this.elementType = elementType;
        if (by === 'data-test-id') {
            this.tableContainerElement = `${container}//${elementType}[@data-test-id="${value}"]//tr[@class="cellCont"]/parent::tbody`;
        } else if (by === 'pl_prop') {
            this.tableContainerElement = `${container}//${elementType}[contains(@pl_prop, "${value}")]//tr[@class="cellCont"]/parent::tbody`;
        } else {
            this.tableContainerElement = `${container}//${elementType}[contains(@${by}, "${value}")]//tr[@class="cellCont"]/parent::tbody`;
        }
    }

    private actualOptions;
    numberOfRows: number;
    readonly rowElementSelector: `//tr[contains(@class, "cellCont") and @data-test-id]`;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.tableContainerElement, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.tableContainerElement, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.tableContainerElement, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.tableContainerElement, index, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.tableContainerElement, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.tableContainerElement, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.tableContainerElement, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.tableContainerElement, options);
    }

    async waitForSelectActionabilityCheck(checks: []) {
        await I.waitForSelectActionabilityCheck(this.tableContainerElement, checks);
    }

    async addRow() {
        let addRowItem: string = `${this.tableContainerElement}//a[contains(normalize-space(.), 'Add Item')]`;
        await I.click(Selector(addRowItem));
    }

    async deleteRow() {
        let deleteRowItem: string = `${this.tableContainerElement}//a[contains(normalize-space(.), 'Delete')]`;
        await I.click(Selector(deleteRowItem));
    }

    row(index: number): Row {
        return new Row(`${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id][${index}]`);
    }

    customRow(xpath: string, index?: number): Row {
        if(index === undefined) {
            index = 0;
        }
        return new Row(`${this.tableContainerElement}${xpath}[${index}]`);
    }

    column(indexOrName: number | string): Column {
        if (typeof indexOrName === 'string') {
            return new Column(`${this.tableContainerElement}//td[@data-attribute-name="${indexOrName}"]`);
        }
        return new Column(indexOrName === 1 ? `${this.tableContainerElement}//td[@aria-colindex="1" or not(@headers)]`
            : `${this.body}//td[@aria-colindex="${indexOrName}" or @headers="a${indexOrName}"]`);
    }

    customColumnByIndex(xpath: string, index?: number): Column {
        if(index === undefined) {
            index = 0;
        }
        return new Column(`${this.tableContainerElement}${xpath}[${index}]`)
    }

    cell(coordinates: { rowIndex: number, columnIndex: number }): Cell {
        return new Cell(`${this.tableContainerElement}$//tr[contains(@class, "cellCont") and @data-test-id][${coordinates.rowIndex}]//td[${coordinates.columnIndex}]`);
    }

    header(indexOrName: number | string): Header {
        if (typeof indexOrName === 'string') {
            return new Header(`${this.tableContainerElement}//th[@role="columnheader"]//div[@class="cellIn " and text()="${indexOrName}"]`);
        }
        return new Header(`${this.tableContainerElement}//th[@role="columnheader"][${indexOrName+1}]//div[@class="cellIn " ]`);
    }

    customHeaderByIndex(xpath: string, index?: number) {
        if(index === undefined) {
            index = 0;
        }
        return new Header(`${this.tableContainerElement}${xpath}[${index}]`);
    }

    private get body(): string {
        return `${this.tableContainerElement}`;
    }

    get rowElements(): string {
        return `${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id]`;
    }

    async getNumberOfRows() {
        let elementSelector = `${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id]`;
            if(await Selector(elementSelector).exists) {
                this.numberOfRows = await Selector (elementSelector, this.actualOptions).filterVisible().count;
                return this.numberOfRows;
            }
            return this.numberOfRows = 0;
    }

    async assertNumberOfRows(length: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (length === 0) {
            await I.expect(Selector
            (`${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id]`, this.actualOptions).exists, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toBeTrue();
        } else {
            await I.expect(this.getNumberOfRows(), {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toEqual(length);
        }
    }

    async assertNumberOfRowsIsAtLeast(length: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (length === 0) {
            await I.expect(Selector
            (`${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id]`, this.actualOptions).exists, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toBeTrue();
        } else {
            await I.expect(this.getNumberOfRows(), {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeAtLeast(length);
        }
    }

    async assertNumberOfRowsIsAtMost(length: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (length === 0) {
            await I.expect(Selector
            (`${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id]`, this.actualOptions).exists, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toBeTrue();
        } else {
            await I.expect(Selector
            (`${this.tableContainerElement}//tr[contains(@class, "cellCont") and @data-test-id]`, this.actualOptions).filterVisible().count, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeAtMost(length);
        }
    }

    async shouldContainNumberOfRows(rowsNumber: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await this.assertNumberOfRows(rowsNumber, options);
    }

    async shouldContainAtLeast(rowsNumber: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await this.assertNumberOfRowsIsAtLeast(rowsNumber, options);
    }

    async shouldContainAtMost(rowsNumber: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await this.assertNumberOfRowsIsAtMost(rowsNumber, options);
    }

    async shouldBeVisible(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector
        (`${this.tableContainerElement}`, this.actualOptions).filterVisible().visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    async shouldNotBeVisible(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector
        (`${this.tableContainerElement}`, this.actualOptions).filterVisible().visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
    }

    async shouldExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector
        (`${this.tableContainerElement}`, this.actualOptions).filterVisible().exists, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    async shouldNotExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector
        (`${this.tableContainerElement}`, this.actualOptions).filterVisible().exists, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
    }

    toString() {
        return `(Table by ${this.by}="${this.value}")`;
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.tableContainerElement, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.tableContainerElement, options);
    }


}
