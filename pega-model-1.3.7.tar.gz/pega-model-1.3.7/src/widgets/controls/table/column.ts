// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {Cell} from './cell';
import {I,Selector} from 'test-maker';
import {methodOptions, Options} from '../../../../helpers/options/methodOptions';

export class Column {

    readonly elements: string;

    constructor(elements: string) {
        this.elements = elements;
    }

    private actualOptions;

    async shouldHaveExactTexts(texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        for (let i = 0; i < texts.length; i++) {
            let expectedItem: string = texts[i];
            await I.expect(Selector(this.elements, this.actualOptions).nth(i).innerText,
                {
                    timeout: this.actualOptions.assertionTimeout,
                    interval: this.actualOptions.interval,
                    retries: this.actualOptions.retries
                }).toEqual(expectedItem);
        }
    }

    async shouldHaveExactTextsInAnyOrder(texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        for (let i = 0; i < texts.length; i++) {
            await I.expect(Selector(this.elements, this.actualOptions).withExactText(`${texts[i]}`).visible, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeOk();
        }
    }

    async shouldHaveTexts(texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        for (let i = 0; i < texts.length; i++) {
            let expectedItem: string = texts[i];
            await I.expect(Selector(this.elements, this.actualOptions).nth(i).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(expectedItem);
        }
    }

    async shouldHaveSize(count: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.elements, this.actualOptions).length, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toEqual(count);
    }

    cell(indexStartingFromOne: number): Cell {
        return new Cell(this.elements, indexStartingFromOne-1);
    }
}
