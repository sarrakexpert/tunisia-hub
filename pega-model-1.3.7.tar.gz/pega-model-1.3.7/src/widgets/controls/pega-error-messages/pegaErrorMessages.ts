// Copyright 2021 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
import {I, Selector} from 'test-maker';
import {pega} from '../../../pega';

export class PegaErrorMessages {
    public readonly controlElement: string;
    public readonly errorMessageContainer: string = `//ancestor::div[@class="field-item dataValueWrite"]//div[contains(@class, "icon-error")]/span`;

    constructor(controlElement: string) {
        this.controlElement = controlElement;
    }

    element() {
        return Selector(this.controlElement).find(this.errorMessageContainer).filterVisible();
    }

    async shouldBeVisible() {
        await pega.alert.accept();
        await I.expectSelector(this.element()).toBeVisible();
    }

    async shouldNotBeVisible() {
        await I.expectSelector(this.element()).toBeInvisible();
    }

    async shouldHaveText(text: string) {
        await pega.alert.accept();
        await I.expectSelector(this.element()).toHaveInnerText(text);
    }

    async shouldNotHaveText(text: string) {
        await pega.alert.accept();
        await I.expectSelector(this.element()).not.toHaveInnerText(text);
    }

    async shouldHaveValidEmail(text: string = 'Enter a valid email address') {
        await pega.alert.accept();
        await I.expectSelector(this.element()).toHaveInnerText(text);
    }

    async shouldHaveValidPhoneNumber(text: string = 'Enter a valid phone number') {
        await pega.alert.accept();
        await I.expectSelector(this.element()).toHaveInnerText(text);
    }

    async valueCanNotBeBlank(text: string = 'Value cannot be blank') {
        await pega.alert.accept();
        await I.expectSelector(this.element()).toHaveInnerText(text);
    }


}