// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {Selector, I} from 'test-maker';
import {methodOptions, Options} from '../../../helpers/options/methodOptions';
import {controlsCommonActions} from './controlsCommonActions';
import {PegaErrorMessages} from './pega-error-messages/pegaErrorMessages';

export class CheckBox {

    public readonly element: string;
    private readonly attributeName: string;
    private readonly attributeValue: string;
    public readonly container: string;
    public readonly checkBoxElement: string;
    public checked: boolean;

    constructor(attributeName: string, attributeValue: string, container: string = '') {
        this.container = container;
        this.attributeName = attributeName;
        this.attributeValue = attributeValue;
        this.element = `${container}//input[@type="checkbox" and contains (@${this.attributeName}, "${this.attributeValue}")]`;
        this.checkBoxElement = `${container}//input[@type="checkbox" and contains (@${this.attributeName}, "${this.attributeValue}")]
        /following-sibling::label[@for="${this.attributeValue}"]`;
    }

    private actualOptions;

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.focus(this.element, options);
    }

    async check(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked) {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index));
        } else {
            throw new Error(`Element ${this.toString()} should be unchecked, but was checked`);
        }
    }

    async checkByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(index).checked) {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(index));
        } else {
            throw new Error(`Element ${this.toString()} should be unchecked, but was checked`);
        }
    }

    async checkButton(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) { //will work only if attribute is id
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked) {
            await I.click(Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.actualOptions.index));
        } else {
            throw new Error(`Element ${this.toString()} should be unchecked, but was checked`);
        }
    }

    async uncheck(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked) {
            throw new Error(`Element ${this.toString()} should be checked, but was unchecked`);
        } else {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index));
        }
    }

    async uncheckByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.element, this.actualOptions).filterVisible().nth(index).checked) {
            throw new Error(`Element ${this.toString()} should be checked, but was unchecked`);
        } else {
            await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(index));
        }
    }

    async uncheckButton(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) { //will work only if attribute is id
        this.actualOptions = methodOptions.setOptions(options);
        if (!await Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked) {
            throw new Error(`Element ${this.toString()} should be checked, but was unchecked`);
        } else {
            await I.click(Selector(this.checkBoxElement, this.actualOptions).filterVisible().nth(this.actualOptions.index));
        }
    }

    async checkIf(toClick: boolean, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (toClick === undefined) {
            return;
        }
        this.actualOptions = methodOptions.setOptions(options);
        if (toClick) {
            await this.check(this.actualOptions);
        }
    }

    async shouldBeChecked(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    async shouldBeUnChecked(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.element, this.actualOptions).filterVisible().nth(this.actualOptions.index).checked, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
    }

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.element, checks, isFilterByVisibility = true);
    }

    async shouldExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async shouldBeEnabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.element, options);
    }

    async shouldBeDisabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.element, options);
    }

    async isChecked(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        this.checked = await Selector(this.element, this.actualOptions).nth(this.actualOptions.index).checked;
        return this.checked;
    }

    toString() {
        return `(Checkbox with ${this.attributeName}='${this.attributeValue}')`;
    }

    error() {
        return new PegaErrorMessages(this.element);
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.element, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.element, options);
    }
}
