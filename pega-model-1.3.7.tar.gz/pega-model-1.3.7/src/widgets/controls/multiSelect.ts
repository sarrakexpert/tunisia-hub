// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {methodOptions, Options} from '../../../helpers/options/methodOptions';
import {controlsCommonActions} from './controlsCommonActions';
import {PegaErrorMessages} from './pega-error-messages/pegaErrorMessages';
import {pega} from '../../pega';

export class MultiSelect {

    public readonly element: string;
    private readonly attributeName: string;
    private readonly attributeValue: string;
    public readonly container: string = '';

    constructor(attributeName: string, attributeValue: string, args?: { container?: string, elementType?: string }) {
        if (args?.container) {
            this.container = args.container;
        }
        this.attributeValue = attributeValue;
        this.attributeName = attributeName;
        if (args?.elementType == 'div') {
            this.element = `${this.container}//div[contains(@data-test-id, "${this.attributeValue}")]/input[@data-ctl='["MultiSelect"]']`;
        } else {
            this.element = `${this.container}//input[@data-ctl='["MultiSelect"]' and contains (@${this.attributeName}, "${this.attributeValue}")]`;
        }
    }

    private actualOptions;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.element, checks, isFilterByVisibility = true);
    }

    async click(options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.click(this.element, options);
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.focus(this.element, options);
    }

    async pressTab() {
        await controlsCommonActions.pressTab();
    }

    async set(value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.set(this.element, value, options);
    }

    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async shouldExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async shouldHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveText(this.element, value, options);
    }

    async shouldNotHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveText(this.element, value, options);
    }

    async shouldHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveExactText(this.element, value, options);
    }

    async shouldNotHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveExactText(this.element, value, options);
    }

    async shouldHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveValue(this.element, value, options);
    }

    async shouldNotHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveValue(this.element, value, options);
    }

    async shouldBeEnabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.element, options);
    }

    async shouldBeDisabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.element, options);
    }

    async selectOneValueFromList(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (value === undefined) {
            return;
        }
        await I.hover(Selector(`${this.element}/following-sibling::i[contains (@class, "caret-down")]`, this.actualOptions).filterVisible())
            .click(Selector(`${this.element}/following-sibling::i[contains (@class, "caret-down")]`, this.actualOptions).filterVisible())
            .waitForSelectorToBeVisible(Selector(`//div[@id="msresults-list"]//li[contains(@data-for-row, "${value}")]`, this.actualOptions))
            .click(Selector(`//div[@id="msresults-list"]//li[contains(@data-for-row, "${value}")]`, this.actualOptions));
    }

    async selectValuesFromList(values: string[], options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (values === undefined) {
            return;
        }
        for (let i = 0; i < values.length; i++) {
            await this.selectOneValueFromList(values[i], options);
        }
    }

    async assertListOfSelectedItemsHasValue(value: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
            await I.expect(Selector(`${this.element}/ancestor::div[@class="field-item dataValueWrite"]//span[@title="${value}"]`, this.actualOptions).visible, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeTrue();
    }

    async assertListOfSelectedItemsHasValues(values: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        for (let i = 0; i < values.length; i++) {
           await this.assertListOfSelectedItemsHasValue(values[i], this.actualOptions);
        }
    }

    async assertListOfSelectedItemsHasNoValue(value: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`${this.element}/ancestor::div[@class="field-item dataValueWrite"]//span[@title="${value}"]`, this.actualOptions).exists, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeTrue();
    }

    async assertListOfSelectedItemsHasNoValues(values: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        for (let i = 0; i < values.length; i++) {
            await this.assertListOfSelectedItemsHasNoValue(values[i], this.actualOptions);
        }
    }

    async assertChoiceOfOfferFieldHasSuggestedValue(value: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.openList(this.actualOptions);
        await I.expect(Selector(`//div[@id="msresults-list"]//li[contains(@data-for-row, "${value}")]`, this.actualOptions).visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
        await this.closeList(this.actualOptions);
    }

    async assertChoiceOfOfferFieldHasSuggestedValues(values: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.openList(this.actualOptions);
        for (let i = 0; i < values.length; i++) {
            await I.expect(Selector(`//div[@id="msresults-list"]//li[contains(@data-for-row, "${values[i]}")]`, this.actualOptions).visible, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeOk();
        }
        await this.closeList(this.actualOptions);
    }

    async assertChoiceOfOfferFieldHasNoSuggestedValue(value: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.openList(this.actualOptions);
        await I.expect(Selector(`//div[@id="msresults-list"]//li[contains(@data-for-row, "${value}")]`, this.actualOptions).exists, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
        await this.closeList(this.actualOptions);
    }

    async assertChoiceOfOfferFieldHasNoSuggestedValues(values: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.openList(this.actualOptions);
        for (let i = 0; i < values.length; i++) {
            await I.expect(Selector(`//div[@id="msresults-list"]//li[contains(@data-for-row, "${values[i]}")]`, this.actualOptions).exists, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toBeOk();
        }
        await this.closeList(this.actualOptions);
    }

    async deleteItemByTitle(value: string) {
        const itemSelector = `${this.element}/ancestor::div[@class="field-item dataValueWrite"]//span[@title="${value}"]`;
        if (await Selector(itemSelector).exists) {
            await pega.elementByXpath(itemSelector + `//div[@class="token-cancel token-cancel-img"]`).click();
        }
    }


    async openList(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let openListArrow: string =
            `${this.element}/ancestor::div[@class="field-item dataValueWrite"]//i[contains (@class, "caret-down")]`
        await I.hover(Selector(openListArrow).filterVisible(), this.actualOptions)
            .click(Selector(openListArrow, this.actualOptions)
                .filterVisible());
    }

    async closeList(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.click(this.actualOptions);
    }

    async shouldBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeRequired(this.element, options);
    }

    async shouldNotBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeRequired(this.element, options);
    }

    async shouldHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveValidationType(this.element, validationType, options);
    }

    async shouldNotHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveValidationType(this.element, validationType, options);
    }

    async getValue() {
        return await controlsCommonActions.getValue(this.element);
    }

    async getText() {
        return await controlsCommonActions.getText(this.element);
    }

    toString() {
        return `(MultiSelect with ${this.attributeName}='${this.attributeValue}')`;
    }

    error() {
        return new PegaErrorMessages(this.element);
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.element, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.element, options);
    }
}


