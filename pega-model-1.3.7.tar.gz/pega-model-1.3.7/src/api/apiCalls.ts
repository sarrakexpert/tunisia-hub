import {I, HttpResponse, logger} from 'test-maker';
import {ApiVars} from './apiVariables';


//sometimes if actionID is needed and there is no Assignment visible try pyLastFlowStepLabel (without spaces)
// or pxSubscript

export class PegaApi {

    logInfo = "";

    async createCaseViaApi(args: { partialUrl: string, username: string, password: string, workId?: string, body?: any, logInfo?: string, successfulStatus?: number }) {
        let body = "";
        let logInfo = "";
        let successfulStatus: number;

        //https://dev.k-expert.com:8082/prweb/api/v1/cases
        const src = `https://${args.username}:${args.password}@${args.partialUrl}/prweb/api/v1/cases`;
        if (args.body) {
            body = args.body;
        }
        if (!args.successfulStatus) {
            successfulStatus = 201;
        } else {
            successfulStatus = args.successfulStatus;
        }
        try {
            const response: HttpResponse<any> = await I.sendPostRequest(src, body);
            if (args.logInfo) {
                logInfo = args.logInfo;
                await logger.log('Log info: ' + logInfo);
                // console.log(response.status);
                // console.log(response.statusText);
            }
            if (response.status == successfulStatus) {
                if (typeof response.data !== 'undefined') {
                    await logger.log('+++++');
                    await logger.log(response.data);
                    let fullCaseId = response.data.ID;
                    let caseId = fullCaseId.replace(`${args.workId} `, '');
                    ApiVars.caseId = caseId;
                    //console.log(caseId);
                    return caseId;
                }
            }
        } catch (error) {
            await logger.log(error);
            await logger.log(error.response.status);
        }
    }


    async requestPost(args: { partialUrl: string, username: string, password: string, workId: string, actualCaseId: string, assignment: string, actionId: string, body?: any, logInfo?: string, workBasketOrWorkList?: string, timeout?: number, debug?: boolean }) {

        let logInfo = "";
        if (!args.workBasketOrWorkList) {
            args.workBasketOrWorkList = "ASSIGN-WORKLIST";
        }

        const src = `https://${args.username}:${args.password}@${args.partialUrl}/prweb/api/v1/assignments/${args.workBasketOrWorkList}%20${args.workId}%20${args.actualCaseId}!${args.assignment}?actionID=${args.actionId}`;
        await logger.log(src);

        if (!args.body) {
            args.body = ""
        }

        if (args.debug) {
            await logger.log('Passed body: ' + args.body);
        }
        if (args.logInfo) {
            logInfo = args.logInfo;
            await logger.log('Log info: ' + logInfo);
        }
        try {
            const response: HttpResponse<any> = await I.sendPostRequest(src, args.body);
            if (response.status == 200) {
                await logger.log(response.data);
            } else {
                await logger.log('status Code: ' + response.statusText + ' and status Code ' + response.status);
                if (response.status != 200) {
                    throw new Error('Pega API response includes the error, check the console log');
                }
            }
            if (args.timeout) {
                await I.wait(args.timeout);
            }
        } catch (error) {
            await logger.log(error);
            await logger.log(error.response.status);
        }
    }

    async getChildCase(args: { partialUrl: string, username: string, password: string, workId: string, actualCaseId: string, logInfo?: string }) {
        ApiVars.childCaseId = '';
        let logInfo = "";

        const src = `https://${args.username}:${args.password}@${args.partialUrl}/api/v1/cases/${args.workId}%20${args.actualCaseId}`;
        await logger.log(src);
        if (args.logInfo) {
            logInfo = args.logInfo;
            await logger.log('Log info: ' + logInfo);
        }
        try {
            let response: HttpResponse<any> = await I.sendGetRequest(src);
            if (response.status == 200) {
                if (typeof response.data !== 'undefined') {
                    //console.log('+++++');
                    //console.log(response.data);

                    let firstChildCase = response.data[0].ID;
                    //console.log(firstChildCase);
                    firstChildCase = firstChildCase.replace(`${args.workId} `, '');
                    //console.log(firstChildCase);
                    ApiVars.childCaseId = firstChildCase;
                }
            }
        } catch (error) {
            await logger.log(error);
            await logger.log(error.response.status);
        }
    }

    async getChildCaseByCaseName(args: { partialUrl: string, username: string, password: string, workId: string, actualCaseId: string, childCaseName: string, logInfo?: string }): Promise<void> {
        ApiVars.childCaseId = '';
        let logInfo = "";

        const src = `https://${args.username}:${args.password}@${args.partialUrl}/api/v1/cases/${args.workId}%20${args.actualCaseId}`;
        await logger.log(src);
        if (args.logInfo) {
            logInfo = args.logInfo;
            await logger.log('Log info: ' + logInfo);
        }
        try {
            let response: HttpResponse<any> = await I.sendGetRequest(src);
            if (response.status == 200) {
                if (typeof response.data !== 'undefined') {
                    //console.log('+++++');
                    //console.log(response.data);

                    let childCases = response.data.childCases;
                    let counter = 0;
                    for (let i = 0; i < childCases.length; i++) {
                        let childCase = childCases[i].ID;
                        childCase = childCase.replace(`${args.workId} `, '');
                        if (childCase.includes(args.childCaseName)) {
                            ApiVars.childCaseId = childCase;
                            await logger.log(childCase);
                            counter++;
                        }
                    }
                    if (counter === 0) {
                        await logger.log(`No child case was found by case name "${args.childCaseName}"`);
                        throw new Error(`No child case was found by case name "${args.childCaseName}"`);

                    }
                }
            }
        } catch (error) {
            await logger.log(error);
            await logger.log(error.response.status);
        }

    }


    async checkTheStatusOfTheToggle(args: { partialUrl: string, username: string, password: string, workId: string, toggleIdentifier: string }) {

        let environmentUrl = args.partialUrl;
        let operator = args.username;
        let password = args.password;
        ApiVars.toggleStatus = false;

        const src = `https://${operator}:${password}@${environmentUrl}/api/v1/data/D_pxListOfAvailableToggles`;
        //console.log(src);
        try {

            let response: HttpResponse<any> = await I.sendGetRequest(src);
            if (response.status == 200) {
                if (typeof response.data !== 'undefined') {
                    //console.log('+++++');
                    //console.log(response.data);
                    let pxResults = response.data.pxResults;
                    let counter = 0;
                    for (let i = 0; i < pxResults.length; i++) {
                        if (pxResults[i].pyToggleIdentifier === args.toggleIdentifier) {
                            await logger.log(`Toggle status for "${args.toggleIdentifier}" is ` + pxResults[i].pyToggleStatus);
                            counter++;
                            if (pxResults[i].pyToggleIdentifier === args.toggleIdentifier && pxResults[i].pyToggleStatus === "ON") {
                                ApiVars.toggleStatus = true;
                                return true;
                            }
                        }
                    }
                    if (counter === 0) {
                        await logger.log(`No toggle was found by identifier "${args.toggleIdentifier}"`);
                        return false;
                    }
                }
            }
            return false;
        } catch (error) {
            await logger.log(error);
            await logger.log(error.response.status);
            return false;
        }
    }
}

export const pegaApi = new PegaApi();
