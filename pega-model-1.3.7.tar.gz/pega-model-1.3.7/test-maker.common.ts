// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {reporters, Configuration, TerminalReporterOptions, TestRunInfo} from "test-maker";
import {OperatorsManager} from './helpers/operator-manager';
import {isAppBusyEvaluator} from './helpers/busy-app-evaluator/busy-app-evaluator';


export const operatorsManager = new OperatorsManager();


export const common = {
    //clients: ['edge'],
    extra: {
        env: {
            name: 'dev'
        },

    },
    reporting: {
        reporters: [
            {
                ...reporters.terminal,
                ...{
                    options: <TerminalReporterOptions>{
                        controllerAction: {start: false},
                        feature: {start: false},
                        scenario: {start: false},
                        step: {start: false},
                        subStep: {start: false},
                        hook: {start: false},
                        //selectorAction: {start: false},
                        //assertionAction: {start: false}
                    }
                }
            },
            reporters.allure, reporters.text],
        screenshots: {
            enabledIn: {
                BeforeFeature: true,
                BeforeEachFeature: true,
                BeforeEachScenario: true,
                BeforeScenario: true,
                BeforeEachStep: true,
                AfterFeature: true,
                AfterEachFeature: true,
                AfterEachScenario: true,
                AfterScenario: true,
                AfterEachStep: true,
                Feature: true,
                Scenario: true,
                Step: true,
                SupStep: true,
            }
        },
        logging: {
            level: `all`
        },
    },
    build: {
        compiler: {typescript: {typeCheck: false}}
    },
    runner: {
        //adapter: `testCafe`,
        adapter: `playwright`,
        timeout: {
            feature: 300000,
            selector: 15000,
            assertion: 17000,
            pageLoad: 10000,
        },
        failure: {
            feature: {
                exitProcessOnFirstFail: false,
                skipRemainingScenariosOnScenarioFail: async (runInfo: TestRunInfo) => runInfo.appIsBusy,
                skipRemainingStepsOnStepFail: true,
            },
            process: {
                exitOnUnhandledErrors: false,
            }
        },
        isAppBusyEvaluator
    }
} as Configuration;

