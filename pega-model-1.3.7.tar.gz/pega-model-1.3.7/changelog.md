# Changelog

All notable changes to this project will be documented in this file.

## [1.3.7] - 2022-07-21

### Features

- [Public] added `shouldOnlyHaveSuggestedItems` method to the Dropdown control
