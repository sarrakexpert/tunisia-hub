const path = require(`path`);
const WebpackBar = require(`webpackbar`);
const nodeExternals = require(`webpack-node-externals`);
const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = {
    entry: {
        index: `./src/index.ts`
    },
    devtool: `inline-source-map`,
    target: `node`,
    externalsPresets: { node: true },
    externals: [nodeExternals({
        allowlist:[
            `p-queue`,
            `p-timeout`,
            `p-finally`,
            `eventemitter3`,
        ]
    })],
    output: {
        filename: `[name].js`,
        path: path.resolve(__dirname, `dist`),
        libraryTarget: `umd2`,
        devtoolModuleFilenameTemplate: `../[resource-path]`,
    },
    resolve: {
        extensions: [`.tsx`, `.ts`, `.js`, `.json`],
    },
    plugins: [
        new CleanWebpackPlugin(),
        new WebpackBar(),
    ],
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: {
                    loader: `ts-loader`,
                    options: {
                        transpileOnly: true
                    },
                },
                exclude: /node_modules/,
            },
        ],
    },
};
